if (!document.getElementById("utube-mac-youtube-button")) {
  browser.runtime.sendMessage({ type: "extension-heartbeat" });
  const button = document.createElement("button");
  button.id = "utube-mac-youtube-button";
  button.type = "button";
  button.textContent = "＋ UTUBE MAC";
  button.style.cssText = "position:fixed;right:20px;bottom:20px;z-index:2147483647;border:0;border-radius:999px;padding:12px 16px;background:#2563eb;color:#fff;font:700 14px -apple-system,BlinkMacSystemFont,sans-serif;box-shadow:0 8px 24px #0008;cursor:pointer";
  button.addEventListener("click", async () => {
    const result = await browser.runtime.sendMessage({ type: "add-to-utube-mac" });
    button.textContent = result?.ok ? "✓ Zur Warteschlange hinzugefügt" : (result?.message || "Nicht erreichbar");
    setTimeout(() => { button.textContent = "＋ UTUBE MAC"; }, 2500);
  });
  document.documentElement.appendChild(button);
}
