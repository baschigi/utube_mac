async function addToUtubeMac(tab) {
  const url = tab?.url || "";
  if (!/^https:\/\/(www\.)?youtube\.com\/|^https:\/\/youtu\.be\//.test(url)) {
    return { ok: false, message: "Bitte zuerst eine YouTube-Seite öffnen." };
  }
  try {
    const response = await fetch("http://127.0.0.1:8765/extension-queue", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url, title: tab.title || "YouTube" })
    });
    return response.ok ? { ok: true, message: "Zu UTUBE MAC hinzugefügt." } : { ok: false, message: "UTUBE MAC ist gerade nicht geöffnet." };
  } catch (_) {
    return { ok: false, message: "Die lokale UTUBE-MAC-App ist nicht erreichbar." };
  }
}

browser.action.onClicked.addListener(addToUtubeMac);
browser.runtime.onMessage.addListener(async (message, sender) => {
  if (message?.type === "extension-heartbeat") {
    try { await fetch("http://127.0.0.1:8765/extension-heartbeat", { method: "POST" }); } catch (_) {}
    return { ok: true };
  }
  if (message?.type !== "add-to-utube-mac") return;
  return addToUtubeMac(sender.tab);
});
