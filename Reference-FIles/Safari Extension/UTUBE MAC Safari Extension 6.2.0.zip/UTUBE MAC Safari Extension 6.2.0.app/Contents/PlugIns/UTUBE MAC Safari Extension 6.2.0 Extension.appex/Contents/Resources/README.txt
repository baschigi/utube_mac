UTUBE MAC Safari Extension 6.2.0

Diese Version gehört zu UTUBE MAC 6.2.0.
Die Erweiterung kann auf YouTube-Videos und Playlists den Link an die lokale
UTUBE-MAC-Warteschlange senden. Safari verlangt nach dem Verpacken noch eine
einmalige manuelle Aktivierung in Safari > Einstellungen > Erweiterungen.
