#!/bin/bash
# UTUBE MAC v6
# Setup script version: 6.2.1
# Last updated: 11. September 2026 · 16:19 CEST · versioned UI-package installer

set -Eeuo pipefail

# This script can run from a Shortcuts temporary folder.  Persist every
# UTUBE MAC file in the real Application Support location instead.
support_directory="$HOME/Library/Application Support/UTUBE-MAC"
settings_directory="$support_directory/Settings/General"
history_directory="$support_directory/History"
temp_directory="$support_directory/Temp"
# The embedded Shortcut may be running for the first time.  Create the
# permanent layout before reading any setting or creating recovery files.
mkdir -p "$settings_directory" "$history_directory/Logs" "$history_directory/Download History" "$temp_directory"
# The Shortcut and the app UI have separate version numbers.  The UI version
# is written by the highest UTUBE-MAC-X.Y.Z.zip package during setup.
installer_version="6.2.1"
logs_directory="$support_directory/History/Logs"
log_file="$logs_directory/setup-$(date +%Y%m%d-%H%M%S).log"
exec > >(tee -a "$log_file") 2>&1

# The Shortcut supplies its list in this order:
# download folder, ready message, current message, error message.
current_downloads_directory="${1:-}"
message_ready="${2:-Du kannst loslegen!}"
message_current="${3:-Alles ist aktuell!}"
message_error="${4:-Bei der UTUBE-MAC-Einrichtung ist ein Fehler aufgetreten. Bitte prüfe dieses Terminal-Fenster.}"
setup_terminal_window_id="${5:-}"

reset=$'\033[0m'
bold=$'\033[1m'
dim=$'\033[2m'
red=$'\033[31m'
green=$'\033[32m'
yellow=$'\033[33m'
blue=$'\033[34m'
magenta=$'\033[35m'
cyan=$'\033[36m'
white=$'\033[97m'
orange=$'\033[38;5;208m'
purple=$'\033[38;5;141m'

setup_started_epoch="$(date +%s)"

print_setup_banner() {
  printf '\033]0;UTUBE MAC – Einrichtung\007'
  printf '\033[2J\033[H'
  printf '%s%s╭──────────────────────────────────────────────────────────────╮%s\n' "$bold" "$purple" "$reset"
  printf '%s%s│              🚀  UTUBE MAC – EINRICHTUNG  🚀               │%s\n' "$bold" "$magenta" "$reset"
  printf '%s%s╰──────────────────────────────────────────────────────────────╯%s\n' "$bold" "$purple" "$reset"
  printf '  %s● LIVE%s  %s%s%s  %s•%s  Version %s\n\n' \
    "$cyan" "$reset" "$bold" "$(date '+%H:%M:%S')" "$reset" "$purple" "$reset" "6.2.0"
  printf '  %sDie Einrichtung läuft automatisch Schritt für Schritt.%s\n' "$white" "$reset"
  printf '  %sDieses Fenster bitte bis zur Abschlussmeldung geöffnet lassen.%s\n' "$dim" "$reset"
}

print_stage() {
  local stage_number="$1"
  local stage_text="$2"
  printf '\n%s%s────────────────────────────────────────────────────────────────%s\n' "$dim" "$purple" "$reset"
  printf '%s%s  ◉ SCHRITT %s VON 8%s  %s%s%s\n' \
    "$bold" "$cyan" "$stage_number" "$reset" "$bold" "$stage_text" "$reset"
  printf '%s%s────────────────────────────────────────────────────────────────%s\n\n' "$dim" "$purple" "$reset"
}

print_success() {
  printf '  %s%s✅  %s%s\n' "$bold" "$green" "$1" "$reset"
}

print_info() {
  printf '  %sℹ️   %s%s\n' "$cyan" "$1" "$reset"
}

print_waiting() {
  printf '  %s⠹  %s%s\n' "$yellow" "$1" "$reset"
}

print_warning() {
  printf '  %s%s⚠️   %s%s\n' "$bold" "$yellow" "$1" "$reset"
}

print_path() {
  printf '      %s↳%s %s%s%s\n' "$purple" "$reset" "$dim" "$1" "$reset"
}

print_setup_plan() {
  printf '\n%s%s  HEUTIGER EINRICHTUNGSPLAN%s\n' "$bold" "$white" "$reset"
  printf '  %s①%s  Ordner vorbereiten        %s○ wartet%s\n' "$cyan" "$reset" "$dim" "$reset"
  printf '  %s②%s  Apple-Werkzeuge prüfen     %s○ wartet%s\n' "$cyan" "$reset" "$dim" "$reset"
  printf '  %s③%s  Homebrew vorbereiten        %s○ wartet%s\n' "$cyan" "$reset" "$dim" "$reset"
  printf '  %s④%s  Download-Werkzeuge laden    %s○ wartet%s\n' "$cyan" "$reset" "$dim" "$reset"
  printf '  %s⑤%s  Werkzeuge aktualisieren      %s○ wartet%s\n' "$cyan" "$reset" "$dim" "$reset"
  printf '  %s⑥%s  MusicBrainz vorbereiten      %s○ wartet%s\n' "$cyan" "$reset" "$dim" "$reset"
  printf '  %s⑦%s  Downloadverlauf abgleichen   %s○ wartet%s\n' "$cyan" "$reset" "$dim" "$reset"
  printf '  %s⑧%s  GitHub und Versionen laden   %s○ wartet%s\n' "$cyan" "$reset" "$dim" "$reset"
}

say_status() {
  local message="$1"
  if command -v cowsay >/dev/null 2>&1; then
    cowsay "$message"
  else
    printf '%s\n' "$message"
  fi
}

installation_failed() {
  local exit_code="$?"
  trap - ERR
  printf '\033[?25h'
  printf '\n%s%s❌ Die Einrichtung wurde nicht abgeschlossen.%s\n' "$bold" "$red" "$reset"
  printf 'Das Terminal bleibt geöffnet, damit die Fehlermeldung gelesen werden kann.\n'
  printf 'Bericht: %s\n' "$log_file"
  say_status "$message_error"
  failure_choice="$(osascript - "$log_file" <<'SETUP_FAILED_DIALOG_EOF' || true
on run argv
  display dialog ("Die Einrichtung ist fehlgeschlagen." & return & return & "Das Terminal bleibt geöffnet und zeigt die Ursache." & return & return & "Protokoll:" & return & item 1 of argv) with title "UTUBE MAC – Einrichtung fehlgeschlagen" buttons {"Fenster offen lassen", "Protokoll öffnen"} default button "Fenster offen lassen" with icon stop
end run
SETUP_FAILED_DIALOG_EOF
)"
  if [[ "$failure_choice" == *"Protokoll öffnen"* ]]; then
    open "$log_file" || true
  fi
  exit "$exit_code"
}

trap installation_failed ERR

print_setup_banner
print_setup_plan

# The setup confirmation always opens the normal UTUBE-MAC download folder.
# When Apple Music was selected, this setting still points to Downloads;
# completed MP3 files are moved to Music separately by the downloader.
downloads_location_file="$support_directory/Settings/General/downloads_directory.txt"
current_downloads_directory="${current_downloads_directory%$'\r'}"
current_downloads_directory="${current_downloads_directory#\"}"
current_downloads_directory="${current_downloads_directory%\"}"
# Shortcuts can pass a status message in the fourth input slot. Accept an
# explicit absolute folder only; otherwise retain the saved download folder.
if [[ "$current_downloads_directory" == /* ]]; then
  downloads_directory="$current_downloads_directory"
elif [[ -r "$downloads_location_file" ]]; then
  downloads_directory="$(<"$downloads_location_file")"
else
  downloads_directory="$HOME/Downloads/UTUBE-MAC"
fi
downloads_directory="${downloads_directory%$'\r'}"
downloads_directory="${downloads_directory#\"}"
downloads_directory="${downloads_directory%\"}"
downloads_directory="${downloads_directory/#$HOME\/\$HOME/$HOME}"
downloads_directory="${downloads_directory/#\$HOME/$HOME}"
downloads_directory="${downloads_directory/#\~/$HOME}"

# Repair an old v6.0.0 setting that accidentally stored the Apple Music
# auto-import folder as the folder to display. Setup must always show the
# safe UTUBE-MAC workspace; only completed MP3 files go to Apple Music.
if [[ "$downloads_directory" == "$HOME/Music/Music/Media.localized/Automatically Add to Music.localized" ]]; then
  downloads_directory="$HOME/Downloads/UTUBE-MAC"
fi

# Save the actual folder selected by the Shortcut.  The downloader reads this
# setting later, so it must be written for custom folders as well as defaults.
printf '%s\n' "$downloads_directory" > "$downloads_location_file"

# Make the complete visible workspace during setup, not only after a first
# download.  This is also the exact layout used by the downloader.
mkdir -p \
  "$downloads_directory/MP4/Single" \
  "$downloads_directory/MP4/Playlists" \
  "$downloads_directory/MKV/Single" \
  "$downloads_directory/MKV/Playlists" \
  "$downloads_directory/MP3/Single" \
  "$downloads_directory/MP3/Playlists" \
  "$downloads_directory/MP3/Advanced/Single" \
  "$downloads_directory/MP3/Advanced/Playlists"

find_homebrew() {
  if command -v brew >/dev/null 2>&1; then
    command -v brew
  elif [[ -x /opt/homebrew/bin/brew ]]; then
    printf '%s\n' "/opt/homebrew/bin/brew"
  elif [[ -x /usr/local/bin/brew ]]; then
    printf '%s\n' "/usr/local/bin/brew"
  else
    return 1
  fi
}

wait_for_command_line_tools() {
  local started_epoch
  local elapsed_seconds
  local elapsed_minutes
  local remaining_seconds
  local spinner_index=0
  local spinner_frames=('⠋' '⠙' '⠹' '⠸' '⠼' '⠴' '⠦' '⠧' '⠇' '⠏')

  print_stage 2 "Apple Command Line Tools prüfen"
  if /usr/bin/xcode-select -p >/dev/null 2>&1; then
    print_success "Apple Command Line Tools sind bereit."
    return 0
  fi

  print_warning "Die Apple Command Line Tools fehlen noch."
  print_info "macOS öffnet gleich sein eigenes Installationsfenster."
  print_info "Bitte dort auf „Installieren“ drücken."
  printf '      %sApple liefert keinen zuverlässigen Prozentwert; UTUBE MAC zeigt deshalb die Laufzeit.%s\n\n' "$dim" "$reset"

  osascript <<'COMMAND_LINE_TOOLS_INFO_EOF'
display dialog "Für Homebrew benötigt UTUBE MAC einmalig die Apple Command Line Tools." & return & return & "macOS öffnet gleich das Installationsfenster. Drücke dort bitte auf ‚Installieren‘. UTUBE MAC wartet anschließend automatisch, bis die Installation abgeschlossen ist." with title "UTUBE MAC – Apple-Werkzeuge" buttons {"Fortfahren"} default button "Fortfahren" with icon note
COMMAND_LINE_TOOLS_INFO_EOF

  /usr/bin/xcode-select --install >/dev/null 2>&1 || true
  started_epoch="$(date +%s)"
  printf '\033[?25l'

  while ! /usr/bin/xcode-select -p >/dev/null 2>&1; do
    elapsed_seconds=$(( $(date +%s) - started_epoch ))
    elapsed_minutes=$((elapsed_seconds / 60))
    remaining_seconds=$((elapsed_seconds % 60))
    printf '\r%s %sApple-Werkzeuge werden von macOS geladen/installiert … %02d:%02d%s' \
      "${spinner_frames[$spinner_index]}" "$yellow" "$elapsed_minutes" "$remaining_seconds" "$reset"
    spinner_index=$(( (spinner_index + 1) % ${#spinner_frames[@]} ))

    if [[ "$elapsed_seconds" -ge 3600 ]]; then
      printf '\033[?25h\n'
      printf 'Zeitüberschreitung: Die Apple Command Line Tools wurden nach 60 Minuten nicht erkannt.\n'
      return 1
    fi
    sleep 2
  done

  printf '\r\033[?25h%70s\r' ''
  print_success "Apple Command Line Tools wurden erfolgreich installiert."
}

changed=0

shortcut_history_directory="$support_directory/History/Shortcut Versions"
github_repository_directory="$support_directory/GitHub Repository"
mkdir -p "$shortcut_history_directory" "$github_repository_directory" "$downloads_directory"

print_stage 1 "UTUBE-MAC-Ordnerstruktur prüfen"
print_success "Application-Support-Ordner ist bereit."
print_path "$support_directory"
print_success "Downloadordner ist bereit."
print_path "$downloads_directory"
print_success "Shortcut-Verlauf ist bereit."
print_path "$shortcut_history_directory"
print_success "GitHub-Repository-Ordner ist bereit."
print_path "$github_repository_directory"

wait_for_command_line_tools

print_stage 3 "Homebrew prüfen"
if brew_path="$(find_homebrew)"; then
  print_success "Homebrew ist bereits installiert."
else
  changed=1
  print_waiting "Homebrew wird jetzt sicher von der offiziellen Quelle geladen."
  print_info "Falls Terminal nach dem Passwort fragt, bleibt die Eingabe unsichtbar – das ist normal."
  printf '\n'
  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
  brew_path="$(find_homebrew)" || exit 69
  printf '\n'
  print_success "Homebrew wurde erfolgreich installiert."
fi

eval "$("$brew_path" shellenv)"

profile_file="$HOME/.zprofile"
shellenv_line="eval \"\$($brew_path shellenv)\""

touch "$profile_file"
if ! grep -Fqx "$shellenv_line" "$profile_file"; then
  printf '%s\n' "$shellenv_line" >> "$profile_file"
fi

print_stage 4 "UTUBE-MAC-Werkzeuge installieren"
required_formulae=(yt-dlp ffmpeg beets chromaprint cowsay dockutil mpv)
missing_formulae=()
for formula in "${required_formulae[@]}"; do
  "$brew_path" list --formula "$formula" >/dev/null 2>&1 || missing_formulae+=("$formula")
done

if (( ${#missing_formulae[@]} > 0 )); then
  changed=1
  print_waiting "Folgende Werkzeuge werden installiert: ${missing_formulae[*]}"
  printf '\n'
  "$brew_path" install --no-ask "${missing_formulae[@]}"
  printf '\n'
  print_success "Alle benötigten Download-Werkzeuge sind installiert."
else
  print_success "Alle benötigten Werkzeuge sind bereits installiert."
fi

print_stage 5 "Werkzeuge aktualisieren"
"$brew_path" update
outdated_formulae="$("$brew_path" outdated --formula yt-dlp ffmpeg beets chromaprint cowsay dockutil mpv 2>/dev/null || true)"
if [[ -n "$outdated_formulae" ]]; then
  changed=1
  print_waiting "Vorhandene UTUBE-MAC-Werkzeuge werden aktualisiert."
  "$brew_path" upgrade --formula yt-dlp ffmpeg beets chromaprint cowsay dockutil mpv
  print_success "Die Werkzeuge wurden aktualisiert."
else
  print_success "Alle Werkzeuge sind aktuell."
fi

print_stage 6 "MusicBrainz-Unterstützung prüfen"
beets_python="$("$brew_path" --prefix beets)/libexec/bin/python"
if ! "$beets_python" -c 'import acoustid' >/dev/null 2>&1; then
  changed=1
  print_waiting "MusicBrainz-Erkennung wird eingerichtet."
  "$beets_python" -m pip install --user pyacoustid
  print_success "MusicBrainz-Unterstützung wurde installiert."
else
  print_success "MusicBrainz-Unterstützung ist bereit."
fi

recover_existing_download_history() {
  local readable_history="$support_directory/History/Download History/DOWNLOAD-HISTORY.txt"
  local recovery_manifest="$support_directory/Temp/history-recovery-$$.txt"
  local media_file
  local media_title
  local media_extension
  local media_kind
  local media_size
  local media_modified
  local source_url
  local recovered_index=0

  recovered_history_files=0
  : > "$recovery_manifest"

  # The readable history gained detailed file blocks during version 6.0.0.
  # Recover older files that predate those blocks without modifying the media.
  while IFS= read -r -d '' media_file; do
    if [[ -f "$readable_history" ]] && grep -Fq -- "  File: $media_file" "$readable_history"; then
      continue
    fi
    printf '%s\n' "$media_file" >> "$recovery_manifest"
    recovered_history_files=$((recovered_history_files + 1))
  done < <(find "$downloads_directory" -type f \( \
    -iname '*.mp3' -o -iname '*.m4a' -o -iname '*.aac' -o -iname '*.flac' -o \
    -iname '*.ogg' -o -iname '*.opus' -o -iname '*.wav' -o -iname '*.aiff' -o \
    -iname '*.mp4' -o -iname '*.mkv' -o -iname '*.webm' \
    \) -print0 2>/dev/null)

  if [[ "$recovered_history_files" -eq 0 ]]; then
    rm -f -- "$recovery_manifest"
    return 0
  fi

  {
    printf '%s\n' "------------------------------------------------------------"
    printf 'Date: %s\n' "$(date '+%Y-%m-%d %H:%M:%S %Z')"
    printf 'UTUBE MAC version: 6.1.0\n'
    printf 'Result: Recovered existing media files\n'
    printf 'Mode: history-recovery\n'
    printf 'Title: Automatischer Abgleich des Downloadordners\n'
    printf 'URL: Individuell pro Datei; falls nicht eingebettet: unbekannt\n'
    printf 'Destination: %s\n' "$downloads_directory"
    printf 'Recovered media files: %s\n' "$recovered_history_files"

    while IFS= read -r media_file; do
      [[ -f "$media_file" ]] || continue
      recovered_index=$((recovered_index + 1))
      media_title="$(ffprobe -v error -show_entries format_tags=title -of default=noprint_wrappers=1:nokey=1 "$media_file" 2>/dev/null | head -n 1 | tr -d '\r' || true)"
      [[ -n "$media_title" ]] || media_title="$(basename "${media_file%.*}")"
      media_extension="${media_file##*.}"
      media_extension="$(printf '%s' "$media_extension" | tr '[:lower:]' '[:upper:]')"
      case "$media_extension" in
        MP3|M4A|AAC|FLAC|OGG|OPUS|WAV|AIFF) media_kind="Audio" ;;
        *) media_kind="Video" ;;
      esac
      media_size="$(stat -f '%z' "$media_file" 2>/dev/null || printf '0')"
      media_modified="$(stat -f '%Sm' -t '%Y-%m-%d %H:%M:%S %Z' "$media_file" 2>/dev/null || printf 'Unbekannt')"
      source_url="$(ffprobe -v error -show_entries format_tags=purl,comment \
        -of default=noprint_wrappers=1:nokey=1 "$media_file" 2>/dev/null | \
        /usr/bin/grep -E '^https?://([^/]+\.)?(youtube\.com|youtu\.be)/' | head -n 1 || true)"
      [[ -n "$source_url" ]] || source_url="Unbekannt – in der Mediendatei nicht gespeichert"

      printf '\nMEDIA FILE %s\n' "$recovered_index"
      printf '  File: %s\n' "$media_file"
      printf '  Title: %s\n' "$media_title"
      printf '  URL: %s\n' "$source_url"
      printf '  Type: %s\n' "$media_kind"
      printf '  Format: %s\n' "$media_extension"
      printf '  File size: %s bytes\n' "$media_size"
      printf '  File modified: %s\n' "$media_modified"
      printf '  Recovery note: Datei war vorhanden, aber noch nicht detailliert im Verlauf erfasst.\n'
    done < "$recovery_manifest"
  } >> "$readable_history"

  rm -f -- "$recovery_manifest"
}

print_stage 7 "Downloadverlauf mit vorhandenen Dateien abgleichen"
recover_existing_download_history
if [[ "$recovered_history_files" -gt 0 ]]; then
  print_success "$recovered_history_files ältere Mediendatei(en) wurden im Verlauf nachgetragen."
  print_info "Vorhandene Dateien wurden dabei weder verändert noch erneut heruntergeladen."
else
  print_success "Der Downloadverlauf enthält bereits alle vorhandenen Mediendateien."
fi

count_shortcut_version_directories() {
  local version_folder_name
  local version_count=0

  while IFS= read -r version_folder_name; do
    if [[ "$version_folder_name" =~ ^UTUBE[[:space:]]MAC[[:space:]][0-9]+\.[0-9]+\.[0-9]+$ ]]; then
      version_count=$((version_count + 1))
    fi
  done < <(find "$shortcut_history_directory" -mindepth 1 -maxdepth 1 -type d -exec basename {} \; 2>/dev/null)
  printf '%s' "$version_count"
}

snapshot_current_scripts() {
  local scripts_directory="$support_directory/scripts"
  local script_history_directory="$history_directory/Script History"
  local archive_directory="$script_history_directory/Archive – older script snapshots"
  local version_tag="V${installer_version//./_}"
  local snapshot_directory
  local candidate
  local candidate_name
  local destination

  [[ -d "$scripts_directory" ]] || return 0
  mkdir -p "$script_history_directory" "$archive_directory"

  # Migrate every older folder scheme once, without deleting any history.
  while IFS= read -r -d '' candidate; do
    candidate_name="$(basename "$candidate")"
    [[ "$candidate" == "$archive_directory" ]] && continue
    if [[ ! "$candidate_name" =~ ^V[0-9]+_[0-9]+_[0-9]+__[0-9]{8}__[0-9]{6}$ ]]; then
      destination="$archive_directory/$candidate_name"
      [[ -e "$destination" ]] && destination="$archive_directory/${candidate_name}__migrated-$(date '+%Y%m%d-%H%M%S')"
      mv "$candidate" "$destination"
    fi
  done < <(find "$script_history_directory" -mindepth 1 -maxdepth 1 -type d -print0)

  snapshot_directory="$script_history_directory/${version_tag}__$(date '+%d%m%Y__%H%M%S')"
  mkdir -p "$snapshot_directory"
  find "$scripts_directory" -maxdepth 1 -type f \( -name '*.sh' -o -name '*.py' -o -name '*.swift' \) -print0 | while IFS= read -r -d '' candidate; do
    /usr/bin/ditto "$candidate" "$snapshot_directory/$(basename "$candidate")"
  done
  [[ -d "$support_directory/Settings" ]] && /usr/bin/ditto "$support_directory/Settings" "$snapshot_directory/Settings"
  printf 'UTUBE MAC script snapshot\nShortcut version: %s\nCreated: %s\n' "$installer_version" "$(date '+%d.%m.%Y %H:%M:%S %Z')" > "$snapshot_directory/INFO.txt"
}

sync_shortcut_history_for_setup() {
  local github_repository_archive="https://github.com/baschigi/utube_mac/archive/refs/heads/main.zip"
  local temporary_directory
  local repository_zip
  local extracted_directory
  local repository_root
  local remote_shortcut_versions
  local versions_before
  local versions_after

  versions_before="$(count_shortcut_version_directories)"
  temporary_directory="$(mktemp -d "${TMPDIR:-/tmp}/utube-setup-shortcuts.XXXXXX")" || return 1
  repository_zip="$temporary_directory/utube-mac-main.zip"
  extracted_directory="$temporary_directory/extracted"
  mkdir -p "$extracted_directory"

  if ! curl -fsSL --max-time 60 "$github_repository_archive?check=$(date +%s)" -o "$repository_zip"; then
    rm -rf -- "$temporary_directory"
    return 1
  fi
  if ! /usr/bin/ditto -x -k "$repository_zip" "$extracted_directory"; then
    rm -rf -- "$temporary_directory"
    return 1
  fi

  repository_root="$(find "$extracted_directory" -mindepth 1 -maxdepth 1 -type d -print -quit)"
  remote_shortcut_versions="$repository_root/Shortcut Versions"
  if [[ -z "$repository_root" || ! -d "$remote_shortcut_versions" ]]; then
    rm -rf -- "$temporary_directory"
    return 1
  fi

  # Keep the complete current main-branch contents locally, including
  # Reference-FIles, Shortcut Versions, documentation and future folders.
  if ! /usr/bin/ditto "$repository_root" "$github_repository_directory"; then
    rm -rf -- "$temporary_directory"
    return 1
  fi

  github_files_count="$(find "$github_repository_directory" -type f 2>/dev/null | wc -l | tr -d '[:space:]')"
  [[ "$github_files_count" =~ ^[0-9]+$ ]] || github_files_count=0

  # Additionally merge the Shortcut Versions folder into the cumulative
  # history without deleting older local versions.
  if ! /usr/bin/ditto "$remote_shortcut_versions" "$shortcut_history_directory"; then
    rm -rf -- "$temporary_directory"
    return 1
  fi

  versions_after="$(count_shortcut_version_directories)"
  shortcut_versions_count="$versions_after"
  shortcut_versions_added=$((versions_after - versions_before))
  [[ "$shortcut_versions_added" -ge 0 ]] || shortcut_versions_added=0
  rm -rf -- "$temporary_directory"
  return 0
}

install_dock_app() {
  local builder="$support_directory/scripts/build_utube_mac_app.sh"
  local app_bundle
  [[ -x "$builder" ]] || return 1
  app_bundle="$(/bin/bash "$builder")"
  [[ -d "$app_bundle" ]] || return 1

  # dockutil stores a valid application reference, unlike the old simulated
  # Finder shortcut that occasionally created a question-mark Dock item.
  local dockutil_path
  dockutil_path="$("$brew_path" --prefix dockutil 2>/dev/null)/bin/dockutil"
  [[ -x "$dockutil_path" ]] || return 1
  "$dockutil_path" --remove "UTUBE MAC" --no-restart >/dev/null 2>&1 || true
  "$dockutil_path" --add "$app_bundle" --label "UTUBE MAC" >/dev/null
  /usr/bin/open "$app_bundle"
}

# The Shortcut's setup action is also the app-update action.  Rebuilding here
# means changes to the interface and playback code are applied even when the
# user chooses not to add a second Dock entry.
refresh_current_app() {
  local builder="$support_directory/scripts/build_utube_mac_app.sh"
  local app_bundle
  [[ -x "$builder" ]] || return 1
  app_bundle="$(/bin/bash "$builder")"
  [[ -d "$app_bundle" ]] || return 1

  # Do not leave a former dashboard process serving an older page.
  local old_app_pids old_server_pids
  old_app_pids="$(pgrep -f '/Applications/UTUBE MAC.app/Contents/MacOS/UTUBE MAC' || true)"
  [[ -z "$old_app_pids" ]] || kill $old_app_pids || true
  old_server_pids="$(lsof -tiTCP:8765 -sTCP:LISTEN 2>/dev/null || true)"
  [[ -z "$old_server_pids" ]] || kill $old_server_pids || true
  /usr/bin/open -n "$app_bundle"
}

version_is_newer() {
  local candidate="$1" current="$2" index=0 candidate_part current_part
  local IFS='.'
  local -a candidate_parts=( $candidate ) current_parts=( $current )
  local part_count="${#candidate_parts[@]}"
  [[ "${#current_parts[@]}" -gt "$part_count" ]] && part_count="${#current_parts[@]}"

  for ((index = 0; index < part_count; index++)); do
    candidate_part="${candidate_parts[index]:-0}"
    current_part="${current_parts[index]:-0}"
    ((10#$candidate_part > 10#$current_part)) && return 0
    ((10#$candidate_part < 10#$current_part)) && return 1
  done
  return 1
}

sync_app_sources_from_repository() {
  local package_directory="$github_repository_directory/Reference-FIles/UTUBE MAC APP"
  local selected_package="" package_candidate temporary_package_directory script_name package_name package_version newest_version=""
  local -a required_scripts=(utube_developer_console.py UTUBE-MAC-App.m UTUBE-MAC-App.swift build_utube_mac_app.sh open_utube_dashboard.sh update_utube_tools.sh)
  [[ -d "$package_directory" ]] || return 1

  # Each release is one self-contained ZIP file: UTUBE-MAC-6.2.1.zip.
  # Use Bash only: a fresh macOS installation does not necessarily include
  # Python. Numeric comparison means 1.10.0 correctly wins over 1.9.9.
  for package_candidate in "$package_directory"/UTUBE-MAC-*.zip; do
    [[ -f "$package_candidate" ]] || continue
    package_name="$(basename "$package_candidate")"
    [[ "$package_name" =~ ^UTUBE-MAC-([0-9]+(\.[0-9]+){1,3})\.zip$ ]] || continue
    package_version="${BASH_REMATCH[1]}"
    if [[ -z "$newest_version" ]] || version_is_newer "$package_version" "$newest_version"; then
      newest_version="$package_version"
      selected_package="$package_candidate"
    fi
  done
  [[ -n "$selected_package" && -f "$selected_package" ]] || return 1

  temporary_package_directory="$(mktemp -d)"
  /usr/bin/ditto -x -k "$selected_package" "$temporary_package_directory" || {
    rm -rf -- "$temporary_package_directory"
    return 1
  }

  for script_name in "${required_scripts[@]}"; do
    [[ -f "$temporary_package_directory/$script_name" ]] || {
      rm -rf -- "$temporary_package_directory"
      return 1
    }
  done

  for script_name in "${required_scripts[@]}"; do
    /usr/bin/ditto "$temporary_package_directory/$script_name" "$support_directory/scripts/$script_name"
    chmod 755 "$support_directory/scripts/$script_name" 2>/dev/null || true
  done
  app_package_version="$(basename "$selected_package" .zip | sed -E 's/^UTUBE-MAC-//')"
  printf '%s\n' "$app_package_version" > "$settings_directory/utube-mac-version.txt"
  rm -rf -- "$temporary_package_directory"
  print_success "App-Paket $app_package_version wurde ausgewählt."
}

print_stage 8 "Vollständiges GitHub-Repository synchronisieren"
shortcut_versions_count="$(count_shortcut_version_directories)"
shortcut_versions_added=0
github_files_count="$(find "$github_repository_directory" -type f 2>/dev/null | wc -l | tr -d '[:space:]')"
[[ "$github_files_count" =~ ^[0-9]+$ ]] || github_files_count=0
shortcut_sync_status="Nicht aktualisiert"
if sync_shortcut_history_for_setup; then
  shortcut_sync_status="Erfolgreich synchronisiert"
  print_success "Das vollständige GitHub-Repository wurde heruntergeladen."
  printf '      %s↳%s %s Dateien gespeichert\n' "$purple" "$reset" "$github_files_count"
  print_path "$github_repository_directory"
  print_success "Shortcut-Versionen wurden mit dem Verlauf zusammengeführt."
  printf '      %s↳%s %s Versionen vorhanden · %s neu hinzugefügt\n' \
    "$purple" "$reset" "$shortcut_versions_count" "$shortcut_versions_added"
  print_path "$shortcut_history_directory"
else
  print_warning "GitHub war momentan nicht erreichbar. Die Einrichtung wird trotzdem abgeschlossen."
  printf '      %s↳%s Bereits gespeicherte Versionen bleiben erhalten: %s\n' "$purple" "$reset" "$shortcut_versions_count"
fi

if sync_app_sources_from_repository; then
  print_success "Aktuelle App-Dateien aus GitHub wurden übernommen."
else
  print_info "Keine neueren App-Dateien in GitHub gefunden; die lokale App-Version bleibt erhalten."
fi

say_status "$message_ready"
install_app_choice="$(osascript <<'DOCK_APP_DIALOG_EOF' || true
display dialog "UTUBE MAC kann jetzt als eigene App mit Icon in dein Dock gelegt werden." & return & return & "Sie startet den lokalen Download-Bereich automatisch und öffnet ihn in einem eigenen Fenster." with title "UTUBE MAC – Dock-App" buttons {"Später", "App hinzufügen"} default button "App hinzufügen" with icon note
DOCK_APP_DIALOG_EOF
)"
if [[ "$install_app_choice" == *"App hinzufügen"* ]]; then
  print_info "UTUBE MAC wird als Dock-App eingerichtet."
  if install_dock_app; then
    print_success "UTUBE MAC wurde zum Dock hinzugefügt und geöffnet."
  else
    print_warning "Die Dock-App konnte jetzt nicht erstellt werden. Du kannst es später in UTUBE MAC erneut versuchen."
  fi
else
  print_info "Die Dock-App wurde übersprungen und bleibt später in UTUBE MAC verfügbar."
fi
setup_choice="$(osascript - "$downloads_directory" "$support_directory" "$github_repository_directory" "$github_files_count" "$shortcut_history_directory" "$shortcut_versions_count" "$shortcut_sync_status" "$recovered_history_files" <<'SETUP_COMPLETE_DIALOG_EOF'
on run argv
  set dialogText to "Fertig eingerichtet!" & return & return & "UTUBE MAC ist bereit."
  set dialogText to dialogText & return & return & "📁 Downloadordner:" & return & item 1 of argv
  set dialogText to dialogText & return & return & "⚙️ Programmdaten:" & return & item 2 of argv
  set dialogText to dialogText & return & return & "🌐 GitHub-Repository:" & return & item 3 of argv
  set dialogText to dialogText & return & "Dateien: " & item 4 of argv
  set dialogText to dialogText & return & return & "🕘 Shortcut-Verlauf:" & return & item 5 of argv
  set dialogText to dialogText & return & "Versionen: " & item 6 of argv & " · " & item 7 of argv
  set dialogText to dialogText & return & return & "🧾 Verlauf repariert:" & return & item 8 of argv & " ältere Datei(en) nachgetragen"
  display dialog dialogText with title "UTUBE MAC" buttons {"Fertig", "Downloadordner öffnen"} default button "Fertig" with icon note
end run
SETUP_COMPLETE_DIALOG_EOF
)"

if [[ "$setup_choice" == *"Downloadordner öffnen"* ]]; then
  open "$downloads_directory"
fi

# Safari is never opened or controlled automatically during setup.  The
# extension remains optional and can be enabled manually from the app later.

# Keep the completed setup visible. The Shortcut deliberately opens this
# Terminal window so its progress and final result can be read.
# The launcher closes only this setup window after the command has ended.
setup_elapsed_seconds=$(( $(date +%s) - setup_started_epoch ))
printf '\n%s%s╭──────────────────────────────────────────────────────────────╮%s\n' "$bold" "$green" "$reset"
printf '%s%s│              ✅  EINRICHTUNG ABGESCHLOSSEN                  │%s\n' "$bold" "$green" "$reset"
printf '%s%s╰──────────────────────────────────────────────────────────────╯%s\n' "$bold" "$green" "$reset"
printf '  %s⏱  Dauer:%s %02d:%02d\n' "$cyan" "$reset" "$((setup_elapsed_seconds / 60))" "$((setup_elapsed_seconds % 60))"
printf '  %s📁 Downloads:%s %s\n' "$cyan" "$reset" "$downloads_directory"
printf '  %s⚙️  Programmdaten:%s %s\n' "$cyan" "$reset" "$support_directory"
printf '  %s🐙 GitHub-Dateien:%s %s\n' "$cyan" "$reset" "$github_files_count"
printf '  %s🕘 Shortcut-Versionen:%s %s\n\n' "$cyan" "$reset" "$shortcut_versions_count"
printf '  %s🧾 Verlauf nachgetragen:%s %s ältere Datei(en)\n\n' "$cyan" "$reset" "$recovered_history_files"
printf '  %sℹ️  Dieses Terminal bleibt geöffnet, damit du den Ablauf nachlesen kannst.%s\n' "$cyan" "$reset"
snapshot_current_scripts || true
print_info "Die aktuelle UTUBE-MAC-App wird neu gebaut und geöffnet."
if refresh_current_app; then
  print_success "Aktuelle App-Version wurde eingerichtet und geöffnet."
else
  print_warning "Die App konnte nicht automatisch neu gebaut werden. Öffne sie später erneut über UTUBE MAC."
fi
