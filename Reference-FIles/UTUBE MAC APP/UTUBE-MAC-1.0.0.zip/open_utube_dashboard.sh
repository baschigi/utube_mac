#!/bin/bash
set -euo pipefail
support_directory="$HOME/Library/Application Support/UTUBE-MAC"
console_file="$support_directory/scripts/utube_developer_console.py"
runtime_directory="$support_directory/Runtime"
mkdir -p "$runtime_directory"
if [[ -f "$console_file" ]] && ! /usr/sbin/lsof -nP -iTCP:8765 -sTCP:LISTEN >/dev/null 2>&1; then
  python_bin="/opt/homebrew/bin/python3.14"
  [[ -x "$python_bin" ]] || python_bin="/usr/bin/python3"
  nohup "$python_bin" "$console_file" > "$runtime_directory/ui.log" 2>&1 &
fi
if [[ "${1:-}" != "--serve" ]]; then
  open "http://127.0.0.1:8765/" || true
fi
