UTUBE MAC Full Installer Package
Version: 1.0.66

How to install it on another Mac:

1. Unzip the file.
2. Double-click "Install.command".
3. If macOS shows a security warning: right-click it and choose "Open".

What gets installed:

- UTUBE MAC.app to:
  ~/Applications/UTUBE MAC.app

- Support files to:
  ~/Library/Application Support/UTUBE-MAC

The app alone is only a wrapper. The support files are required too.
