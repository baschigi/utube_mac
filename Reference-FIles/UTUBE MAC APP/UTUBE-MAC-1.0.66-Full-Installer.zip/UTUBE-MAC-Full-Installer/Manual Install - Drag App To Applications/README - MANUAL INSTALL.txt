Manual install option
Version: 1.0.66

Recommended:
Double-click "Install.command" in the main folder.

Manual fallback:
1. Drag "UTUBE MAC.app" onto the "Applications" alias.
2. Then still run "Install.command" once, because the app also needs:
   ~/Library/Application Support/UTUBE-MAC

Important:
The app is a wrapper. If you only copy the app without the support files,
UTUBE MAC may open blank or fail to load.
