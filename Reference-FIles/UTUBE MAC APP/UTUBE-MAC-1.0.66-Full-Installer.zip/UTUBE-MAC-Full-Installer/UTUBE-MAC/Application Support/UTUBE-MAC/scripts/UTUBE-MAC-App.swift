import Cocoa
import WebKit
import AVKit
final class AppDelegate: NSObject, NSApplicationDelegate, WKScriptMessageHandler {
  var window: NSWindow!
  var web: WKWebView!
  var nativePlayer: AVPlayerView?
  var nativeClose: NSButton?
  var escapeMonitor: Any?
  func playerFrame(_ payload: [String: Any]) -> NSRect {
    let contentBounds = window.contentView!.bounds
    let number = { (key: String) -> CGFloat? in (payload[key] as? NSNumber).map { CGFloat($0.doubleValue) } }
    let requestedWidth = number("width") ?? (contentBounds.width - 80)
    let requestedHeight = number("height") ?? (contentBounds.height * 0.62)
    // Keep the native movie inside a clearly embedded 16:9 area. This leaves
    // UTUBE MAC's title, navigation and actions visible around the player.
    let height = min(requestedHeight, contentBounds.height * 0.62)
    let width = min(requestedWidth, min(height * (16.0 / 9.0), contentBounds.width - 80))
    let requestedX = number("x") ?? ((contentBounds.width - width) / 2)
    let x = max(40, min(requestedX + (requestedWidth - width) / 2, contentBounds.width - width - 40))
    let top = max(76, number("y") ?? 76)
    // Browser coordinates start at the upper-left; AppKit view coordinates
    // start at the lower-left.
    let y = contentBounds.height - top - height
    return NSRect(x: x, y: y, width: width, height: height).intersection(contentBounds)
  }
  func applicationDidFinishLaunching(_ notification: Notification) {
    let launcher = (NSHomeDirectory() as NSString).appendingPathComponent("Library/Application Support/UTUBE-MAC/scripts/open_utube_dashboard.sh")
    let process = Process(); process.executableURL = URL(fileURLWithPath: "/bin/bash"); process.arguments = [launcher, "--serve"]; try? process.run()
    let configuration = WKWebViewConfiguration()
    configuration.userContentController.add(self, name: "nativePlayer")
    let web = WKWebView(frame: .zero, configuration: configuration)
    self.web = web
    window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 1180, height: 820), styleMask: [.titled,.closable,.miniaturizable,.resizable], backing: .buffered, defer: false)
    window.title = "UTUBE MAC"; window.titleVisibility = .hidden; window.titlebarAppearsTransparent = true; window.center(); window.contentView = web; window.makeKeyAndOrderFront(nil); NSApp.activate(ignoringOtherApps: true)
    escapeMonitor = NSEvent.addLocalMonitorForEvents(matching: .keyDown) { [weak self] event in
      if event.keyCode == 53, self?.nativePlayer != nil {
        self?.closeNativePlayer()
        return nil
      }
      return event
    }
    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { web.load(URLRequest(url: URL(string: "http://127.0.0.1:8765/")!)) }
  }
  func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
    guard message.name == "nativePlayer", let payload = message.body as? [String: Any], let action = payload["action"] as? String else { return }
    DispatchQueue.main.async {
      if action == "close" { self.closeNativePlayer(); return }
      if action == "layout", let view = self.nativePlayer {
        let frame = self.playerFrame(payload)
        if !frame.isEmpty {
          view.frame = frame
          self.nativeClose?.frame = NSRect(x: frame.maxX - 112, y: frame.maxY + 8, width: 112, height: 30)
        }
        return
      }
      guard action == "play", let path = payload["path"] as? String, FileManager.default.fileExists(atPath: path) else { return }
      self.closeNativePlayer()
      let contentBounds = self.window.contentView!.bounds
      let nativeFrame = self.playerFrame(payload)
      let item = AVPlayerItem(url: URL(fileURLWithPath: path))
      item.preferredForwardBufferDuration = 2
      let player = AVPlayer(playerItem: item)
      player.volume = 1.0
      player.isMuted = false
      player.automaticallyWaitsToMinimizeStalling = true
      let view = AVPlayerView(frame: nativeFrame.isEmpty ? contentBounds.insetBy(dx: 28, dy: 28) : nativeFrame)
      view.player = player; view.controlsStyle = .floating
      let close = NSButton(title: "Schließen ✕", target: self, action: #selector(self.closeNativePlayer))
      close.bezelStyle = .rounded
      close.frame = NSRect(x: view.frame.maxX - 112, y: view.frame.maxY + 8, width: 112, height: 30)
      self.window.contentView!.addSubview(view)
      self.window.contentView!.addSubview(close)
      self.nativePlayer = view
      self.nativeClose = close
      // The player is opened from a deliberate click in UTUBE MAC.  Start as
      // soon as AVFoundation has enough data instead of showing a second play
      // prompt over the movie.
      player.play()
      DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) { player.play() }
    }
  }
  @objc func closeNativePlayer() { nativePlayer?.player?.pause(); nativePlayer?.removeFromSuperview(); nativeClose?.removeFromSuperview(); nativePlayer = nil; nativeClose = nil; web?.evaluateJavaScript("window.utubeNativeClosed&&window.utubeNativeClosed()") }
  func applicationWillTerminate(_ notification: Notification) { if let monitor = escapeMonitor { NSEvent.removeMonitor(monitor) } }
  func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { true }
}
let app = NSApplication.shared; let delegate = AppDelegate(); app.delegate = delegate; app.setActivationPolicy(.regular); app.run()
