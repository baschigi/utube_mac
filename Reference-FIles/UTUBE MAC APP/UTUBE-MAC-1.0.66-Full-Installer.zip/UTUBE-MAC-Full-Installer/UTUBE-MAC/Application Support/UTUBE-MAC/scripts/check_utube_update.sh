#!/bin/bash
set -u

# This lightweight check is designed for the beginning of the Shortcut. Most
# launches return immediately: GitHub is queried at most once per day and the
# same available version is shown at most once every seven days.
support_directory="${UTUBE_MAC_SUPPORT_DIRECTORY:-$HOME/Library/Application Support/UTUBE-MAC}"
update_settings_directory="$support_directory/Settings/Update"
local_version_file="$support_directory/Settings/General/utube-mac-version.txt"
full_updater_file="$support_directory/scripts/update_utube_tools.sh"
last_check_epoch_file="$update_settings_directory/last-check-epoch.txt"
last_reminded_epoch_file="$update_settings_directory/last-reminded-epoch.txt"
last_reminded_version_file="$update_settings_directory/last-reminded-version.txt"
ignored_version_file="$update_settings_directory/ignored-version.txt"
github_versions_api="https://api.github.com/repos/baschigi/utube_mac/contents/Shortcut%20Versions?ref=main"
check_interval_seconds=86400
reminder_interval_seconds=604800

mkdir -p "$update_settings_directory"

read_number_file() {
  local file="$1"
  local value
  value="$(tr -cd '0-9' < "$file" 2>/dev/null || true)"
  [[ "$value" =~ ^[0-9]+$ ]] || value=0
  printf '%s' "$value"
}

version_is_newer() {
  awk -v installed="$1" -v available="$2" '
    BEGIN {
      split(installed, installed_parts, ".")
      split(available, available_parts, ".")
      for (part = 1; part <= 3; part++) {
        old = installed_parts[part] + 0
        new = available_parts[part] + 0
        if (new > old) exit 0
        if (new < old) exit 1
      }
      exit 1
    }
  '
}

current_version="$(tr -d '[:space:]' < "$local_version_file" 2>/dev/null || true)"
[[ "$current_version" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || exit 0

current_epoch="$(date +%s)"
last_check_epoch="$(read_number_file "$last_check_epoch_file")"
if (( current_epoch - last_check_epoch < check_interval_seconds )); then
  exit 0
fi

# Store the attempt time before networking. An offline Mac therefore remains
# quiet instead of retrying and delaying every Shortcut launch.
printf '%s\n' "$current_epoch" > "$last_check_epoch_file"

if ! versions_response="$(curl -fsSL --max-time 10 \
  -H 'Accept: application/vnd.github+json' \
  -H 'User-Agent: UTUBE-MAC' \
  "$github_versions_api" 2>/dev/null)"; then
  exit 0
fi

latest_version=""
while IFS= read -r candidate_version; do
  [[ "$candidate_version" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || continue
  if [[ -z "$latest_version" ]] || version_is_newer "$latest_version" "$candidate_version"; then
    latest_version="$candidate_version"
  fi
done < <(printf '%s\n' "$versions_response" | sed -nE 's/.*"name"[[:space:]]*:[[:space:]]*"UTUBE MAC ([0-9]+\.[0-9]+\.[0-9]+)".*/\1/p')

[[ "$latest_version" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || exit 0
version_is_newer "$current_version" "$latest_version" || exit 0

ignored_version="$(tr -d '[:space:]' < "$ignored_version_file" 2>/dev/null || true)"
[[ "$ignored_version" == "$latest_version" ]] && exit 0

last_reminded_version="$(tr -d '[:space:]' < "$last_reminded_version_file" 2>/dev/null || true)"
last_reminded_epoch="$(read_number_file "$last_reminded_epoch_file")"
if [[ "$last_reminded_version" == "$latest_version" ]] && \
   (( current_epoch - last_reminded_epoch < reminder_interval_seconds )); then
  exit 0
fi

# Record the reminder before showing it. Closing the window with Escape counts
# as "remind later" and cannot interrupt the rest of the Shortcut.
printf '%s\n' "$latest_version" > "$last_reminded_version_file"
printf '%s\n' "$current_epoch" > "$last_reminded_epoch_file"

choice="$(osascript - "$current_version" "$latest_version" <<'UPDATE_REMINDER_DIALOG_EOF' || true
on run argv
  set installedVersion to item 1 of argv
  set availableVersion to item 2 of argv
  set dialogText to "Eine neue UTUBE-MAC-Version ist verfügbar." & return & return & "Installiert: " & installedVersion & return & "Verfügbar: " & availableVersion & return & return & "UTUBE MAC erinnert dich frühestens in sieben Tagen erneut."
  display dialog dialogText with title "UTUBE MAC – Update verfügbar" buttons {"Diese Version ignorieren", "In 7 Tagen erinnern", "Update anzeigen"} default button "Update anzeigen" with icon note
end run
UPDATE_REMINDER_DIALOG_EOF
)"

if [[ "$choice" == *"Diese Version ignorieren"* ]]; then
  printf '%s\n' "$latest_version" > "$ignored_version_file"
elif [[ "$choice" == *"Update anzeigen"* ]] && [[ -x "$full_updater_file" ]]; then
  /bin/bash "$full_updater_file"
fi

exit 0
