#!/bin/bash
# UTUBE MAC Shortcut installer — current app build
# Runs the guided setup, builds this current UI/player version and opens it.
set -Eeuo pipefail
support_directory="$HOME/Library/Application Support/UTUBE-MAC"
scripts_directory="$support_directory/scripts"
installer="$scripts_directory/install_utube_tools.sh"
builder="$scripts_directory/build_utube_mac_app.sh"
app_bundle="$HOME/Applications/UTUBE MAC.app"

if [[ ! -x "$installer" || ! -x "$builder" ]]; then
  echo "Die aktuellen UTUBE-MAC-Skripte wurden nicht gefunden." >&2
  echo "Öffne UTUBE MAC einmal und wähle Einstellungen → Einrichtung starten." >&2
  exit 1
fi

# Keep all existing Shortcut arguments: download folder and localized texts.
"$installer" "$@"

# Rebuild the native app from the current files stored in Application Support.
"$builder" >/dev/null

# A former local web server can otherwise continue serving an old interface.
old_app_pids="$(pgrep -f '/Applications/UTUBE MAC.app/Contents/MacOS/UTUBE MAC' || true)"
[[ -z "$old_app_pids" ]] || kill $old_app_pids || true
old_server_pids="$(lsof -tiTCP:8765 -sTCP:LISTEN 2>/dev/null || true)"
[[ -z "$old_server_pids" ]] || kill $old_server_pids || true

open -n "$app_bundle"
echo "✓ UTUBE MAC wurde mit der aktuellen App-Version eingerichtet und geöffnet."
