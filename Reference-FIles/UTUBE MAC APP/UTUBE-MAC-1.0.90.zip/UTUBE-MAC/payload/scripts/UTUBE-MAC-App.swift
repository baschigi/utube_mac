import Cocoa
import WebKit
import AVKit
import AVFoundation
import UniformTypeIdentifiers
// Match browser coordinates explicitly; never depend on WKWebView's internal
// flipped coordinate system for native overlays.
final class PlayerRootView: NSView {
  override var isFlipped: Bool { true }
}
final class AppDelegate: NSObject, NSApplicationDelegate, WKScriptMessageHandler, WKUIDelegate, WKNavigationDelegate {
  var window: NSWindow!
  var web: WKWebView!
  var root: PlayerRootView!
  var nativePlayer: AVPlayerView?
  var nativeAVPlayer: AVPlayer?
  var nativeClose: NSButton?
  var nativeRestore: NSButton?
  var escapeMonitor: Any?
  var miniPlayer = false
  func showMiniPlayer(canRestore: Bool = false) {
    guard let view = nativePlayer else { return }
    guard !view.isInFullScreenMode else { return }
    miniPlayer = true
    let width = min(360, max(180, root.bounds.width - 32))
    let height = width * 9 / 16
    view.frame = NSRect(x: root.bounds.width-width-16, y: root.bounds.height-height-16, width:width, height:height)
    view.autoresizingMask = [.minXMargin, .minYMargin]
    nativeClose?.frame = NSRect(x:view.frame.maxX-124, y:view.frame.minY-34, width:124, height:30)
    nativeClose?.autoresizingMask = [.minXMargin, .minYMargin]
    nativeClose?.isHidden = false
    nativeRestore?.frame = NSRect(x:view.frame.minX, y:view.frame.minY-34, width:150, height:30)
    nativeRestore?.autoresizingMask = [.minXMargin, .minYMargin]
    nativeRestore?.isHidden = !canRestore
    view.isHidden = false
  }
  func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
    showMiniPlayer()
  }
  func playerFrame(_ payload: [String: Any]) -> NSRect {
    let number = { (key: String) -> CGFloat? in (payload[key] as? NSNumber).map { CGFloat($0.doubleValue) } }
    guard let width = number("width"), let height = number("height"),
          let x = number("x"), let top = number("y"),
          [width, height, x, top].allSatisfy({ $0.isFinite }),
          width > 0, height > 0 else { return .zero }
    return NSRect(x: x, y: top, width: width, height: height)
  }
  func applicationDidFinishLaunching(_ notification: Notification) {
    UTUBESetup.shared.check(force:CommandLine.arguments.contains("--setup-tools")) { ready in
      if ready { self.startDashboard() } else { NSApp.terminate(nil) }
    }
  }
  func startDashboard() {
    let launcher = (NSHomeDirectory() as NSString).appendingPathComponent("Library/Application Support/UTUBE-MAC/scripts/open_utube_dashboard.sh")
    let process = Process(); process.executableURL = URL(fileURLWithPath: "/bin/bash"); process.arguments = [launcher, "--serve"]; try? process.run()
    let configuration = WKWebViewConfiguration()
    configuration.userContentController.add(self, name: "nativePlayer")
    let web = WKWebView(frame: .zero, configuration: configuration)
    self.web = web
    web.uiDelegate = self
    web.navigationDelegate = self
    window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 1180, height: 820), styleMask: [.titled,.closable,.miniaturizable,.resizable], backing: .buffered, defer: false)
    root = PlayerRootView(frame: NSRect(x: 0, y: 0, width: 1180, height: 820))
    root.wantsLayer = true; root.layer?.masksToBounds = true
    web.frame = root.bounds; web.autoresizingMask = [.width, .height]; root.addSubview(web)
    window.title = "UTUBE MAC"; window.titleVisibility = .hidden; window.titlebarAppearsTransparent = true; window.center(); window.contentView = root; window.makeKeyAndOrderFront(nil); NSApp.activate(ignoringOtherApps: true)
    escapeMonitor = NSEvent.addLocalMonitorForEvents(matching: .keyDown) { [weak self] event in
      if event.keyCode == 53, let view = self?.nativePlayer, view.isInFullScreenMode {
        view.exitFullScreenMode(options:nil)
        return nil
      }
      if event.keyCode == 53, self?.nativePlayer != nil {
        self?.closeNativePlayer()
        return nil
      }
      return event
    }
    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { web.load(URLRequest(url: URL(string: "http://127.0.0.1:8765/")!)) }
  }
  func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
    if navigationAction.targetFrame == nil, let url = navigationAction.request.url,
       ["https", "http"].contains(url.scheme ?? "") {
      NSWorkspace.shared.open(url)
    }
    return nil
  }
  func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
    guard message.name == "nativePlayer", let payload = message.body as? [String: Any], let action = payload["action"] as? String else { return }
    DispatchQueue.main.async {
      if action == "setupTools" {
        UTUBESetup.shared.check(force:true) { _ in }
        return
      }
      if action == "exportLibrary", let text = payload["data"] as? String, text.utf8.count <= 20 * 1024 * 1024 {
        let panel = NSSavePanel()
        panel.allowedContentTypes = [.json]; panel.nameFieldStringValue = "UTUBE-MAC-Library.json"
        panel.beginSheetModal(for: self.window) { result in
          guard result == .OK, let url = panel.url else { return }
          do { try Data(text.utf8).write(to: url, options: .atomic) }
          catch { let alert = NSAlert(error: error); alert.runModal() }
        }
        return
      }
      if action == "importLibrary" {
        let panel = NSOpenPanel(); panel.allowedContentTypes = [.json]
        panel.allowsMultipleSelection = false; panel.canChooseDirectories = false
        panel.beginSheetModal(for: self.window) { result in
          guard result == .OK, let url = panel.url else { return }
          do {
            let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
            guard size <= 20 * 1024 * 1024 else { throw NSError(domain:"UTUBE",code:1,userInfo:[NSLocalizedDescriptionKey:"Library export exceeds 20 MB"]) }
            let text = try String(contentsOf: url, encoding: .utf8)
            let quoted = String(data: try JSONSerialization.data(withJSONObject: [text]), encoding:.utf8)!
            self.web.evaluateJavaScript("window.utubeLibraryImport&&window.utubeLibraryImport("+quoted+"[0])")
          } catch { let alert=NSAlert(error:error); alert.runModal() }
        }
        return
      }
      if action == "close" { self.closeNativePlayer(); return }
      if action == "fullscreen", let view = self.nativePlayer, let screen = self.window.screen {
        if view.isInFullScreenMode { view.exitFullScreenMode(options:nil) }
        else { view.enterFullScreenMode(screen, withOptions:[.fullScreenModeAllScreens:false]) }
        return
      }
      if action == "seek", let seconds = payload["time"] as? NSNumber, let player = self.nativeAVPlayer {
        player.seek(to: CMTime(seconds: seconds.doubleValue, preferredTimescale: 600))
        player.play()
        return
      }
      if action == "layout", let view = self.nativePlayer {
        if view.isInFullScreenMode { return }
        if self.miniPlayer { return }
        let frame = self.playerFrame(payload)
        if frame.isEmpty || !frame.intersects(self.web.bounds) { self.showMiniPlayer(canRestore:true); return }
        view.isHidden = frame.isEmpty || !frame.intersects(self.web.bounds)
        if !frame.isEmpty {
          view.frame = frame
        }
        return
      }
      guard action == "play", let path = payload["path"] as? String, FileManager.default.fileExists(atPath: path) else { return }
      self.clearNativePlayer()
      let nativeFrame = self.playerFrame(payload)
      guard !nativeFrame.isEmpty else { return }
      let item = AVPlayerItem(url: URL(fileURLWithPath: path))
      item.preferredForwardBufferDuration = 2
      let player = AVPlayer(playerItem: item)
      player.volume = 1.0
      player.isMuted = false
      player.automaticallyWaitsToMinimizeStalling = true
      let view = AVPlayerView(frame: nativeFrame)
      view.player = player; view.controlsStyle = .floating
      view.showsFullScreenToggleButton = true
      let restore = NSButton(title: "↗ Zurück zum Kino", target:self, action:#selector(self.restoreCinema))
      restore.bezelStyle = .rounded
      restore.isHidden = true
      restore.setAccessibilityLabel("Zurück zur großen Kinoansicht")
      let close = NSButton(title: "Schließen ✕", target: self, action: #selector(self.closeNativePlayer))
      close.bezelStyle = .rounded
      close.isHidden = true // Contained view already has its styled page Close.
      // Always reachable, even when the video's webpage header scrolls away.
      close.frame = NSRect(x: self.root.bounds.width - 136, y: 10, width: 124, height: 32)
      close.autoresizingMask = [.minXMargin, .maxYMargin]
      close.setAccessibilityLabel("Close video")
      self.root.addSubview(view)
      self.root.addSubview(close)
      self.root.addSubview(restore)
      self.nativeRestore = restore
      self.nativePlayer = view
      self.nativeAVPlayer = player
      self.nativeClose = close
      // The player is opened from a deliberate click in UTUBE MAC.  Start as
      // soon as AVFoundation has enough data instead of showing a second play
      // prompt over the movie.
      player.play()
      DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) { player.play() }
    }
  }
  @objc func closeNativePlayer() {
    clearNativePlayer()
    web?.evaluateJavaScript("window.utubeNativeClosed&&window.utubeNativeClosed()")
  }
  @objc func restoreCinema() {
    web.evaluateJavaScript("window.utubeRestoreCinema ? window.utubeRestoreCinema() : null") { result, error in
      guard error == nil, let payload = result as? [String:Any], let view = self.nativePlayer else { return }
      let frame = self.playerFrame(payload)
      guard !frame.isEmpty else { return }
      self.miniPlayer = false
      view.autoresizingMask = []
      view.frame = frame
      self.nativeRestore?.isHidden = true
      self.nativeClose?.isHidden = true
    }
  }
  func clearNativePlayer() {
    if nativePlayer?.isInFullScreenMode == true { nativePlayer?.exitFullScreenMode(options:nil) }
    miniPlayer = false
    nativeAVPlayer?.pause()
    nativeAVPlayer?.replaceCurrentItem(with: nil)
    nativePlayer?.player = nil
    nativePlayer?.removeFromSuperview()
    nativeClose?.removeFromSuperview()
    nativeRestore?.removeFromSuperview()
    nativeRestore = nil
    nativeAVPlayer = nil
    nativePlayer = nil
    nativeClose = nil
  }
  func applicationWillTerminate(_ notification: Notification) { if let monitor = escapeMonitor { NSEvent.removeMonitor(monitor) } }
  func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { true }
}
let app = NSApplication.shared; let delegate = AppDelegate(); app.delegate = delegate; app.setActivationPolicy(.regular); app.run()
