"""Explicit, local library operations. Media is never moved or overwritten."""
import hashlib
import json
import os
import threading
import time
import uuid
from pathlib import Path

LOCK = threading.Lock()
JOBS = {}
PREVIEWS = {}

def fingerprint(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()

def start(api, data):
    action = data.get("action")
    if action not in ("scan", "export", "import-preview", "import-apply"):
        raise ValueError("Unknown library operation")
    with LOCK:
        if any(job["state"] == "running" for job in JOBS.values()):
            raise ValueError("A library operation is already running")
        job_id = uuid.uuid4().hex
        JOBS.clear()
        JOBS[job_id] = {"state": "running", "done": 0, "total": 0}
    def work():
        try:
            if action == "import-apply":
                with LOCK:
                    result = run(api, data, JOBS[job_id])
            else:
                result = run(api, data, JOBS[job_id])
            JOBS[job_id].update(state="complete", result=result)
        except Exception as error:
            JOBS[job_id].update(state="failed", error=str(error)[:300])
    threading.Thread(target=work, daemon=True).start()
    return {"id": job_id}

def status(job_id):
    with LOCK:
        return dict(JOBS.get(job_id, {"state":"failed", "error":"Operation not found"}))

def run(api, data, progress):
    action = data["action"]
    if action == "import-apply":
        preview = PREVIEWS.pop(data.get("token", ""), None)
        if not preview or time.time() - preview["created"] > 900:
            raise ValueError("Import preview expired. Select the export again.")
        metadata_file = api["LIBRARY_METADATA"]
        saved = json.loads(metadata_file.read_text()) if metadata_file.exists() else {}
        if not isinstance(saved, dict):
            raise ValueError("Existing metadata cannot be read safely")
        added = 0
        for entry in preview["matches"]:
            path = api["safe_media"](entry["path"])
            if not path or path.stat().st_size != entry["size"] or path.stat().st_mtime_ns != entry["mtime"]:
                continue
            key = str(path.resolve())
            old = saved.get(key, {})
            if not isinstance(old, dict):
                continue
            merged = dict(old)
            for field in ("title", "channel", "source_url"):
                if not merged.get(field) and entry["metadata"].get(field):
                    merged[field] = entry["metadata"][field]
            if merged != old:
                saved[key] = merged
                added += 1
        if added:
            metadata_file.parent.mkdir(parents=True, exist_ok=True)
            backup = metadata_file.with_name("Library Metadata-before-import-" + uuid.uuid4().hex + ".json")
            if metadata_file.exists():
                backup.write_bytes(metadata_file.read_bytes())
            temporary = metadata_file.with_name(".library-import-" + uuid.uuid4().hex + ".json")
            try:
                temporary.write_text(json.dumps(saved, ensure_ascii=False, indent=2))
                os.replace(temporary, metadata_file)
            finally:
                if temporary.exists():
                    temporary.unlink()
        return {"imported":added, "message":"Existing metadata was preserved. No media files were changed."}
    files = api["media_files"]()
    if len(files) > 10000:
        raise ValueError("This version supports at most 10,000 files per operation")
    progress["total"] = len(files)
    incoming = data.get("manifest")
    if action == "import-preview":
        if not isinstance(incoming, dict) or incoming.get("format") != "utube-library-metadata" or incoming.get("schema") != 1 or not isinstance(incoming.get("items"), list) or len(incoming["items"]) > 10000:
            raise ValueError("Not a supported UTUBE MAC metadata export")
        for entry in incoming["items"]:
            if not isinstance(entry, dict) or not isinstance(entry.get("sha256"), str) or len(entry["sha256"]) != 64 or not isinstance(entry.get("metadata"), dict):
                raise ValueError("Invalid export record")
    records, lookup, unreadable, missing, unavailable = [], {}, 0, 0, 0
    for index, path in enumerate(files):
        try:
            if not api["safe_media"](str(path)):
                raise OSError("File outside registered library")
            before = path.stat()
            digest = fingerprint(path) if action != "scan" else ""
            if action == "import-preview":
                info = {}
            else:
                info = api["inspect_video_source"](str(path))
            after = path.stat()
            if (before.st_size,before.st_mtime_ns) != (after.st_size,after.st_mtime_ns):
                raise ValueError("File changed during scan")
            metadata = api["custom_metadata_for"](path)
            metadata = {key:str(metadata.get(key) or "")[:600] for key in ("title","channel","source_url")}
            if not metadata["source_url"] and info.get("source_url"):
                metadata["source_url"] = info["source_url"][:600]
            if info.get("error"):
                unavailable += 1
            elif not metadata["source_url"]:
                missing += 1
            records.append({"name":path.name, "size":after.st_size, "sha256":digest, "metadata":metadata})
            lookup.setdefault((digest,after.st_size), []).append((path,after.st_mtime_ns))
        except (OSError, ValueError):
            unreadable += 1
        progress["done"] = index + 1
    if action == "scan":
        return {"scanned":len(records), "source_missing":missing, "scanner_errors":unavailable, "unreadable":unreadable, "message":"Read-only scan finished. No files or metadata were changed."}
    if action == "export":
        return {"manifest":{"format":"utube-library-metadata", "schema":1, "items":records}, "unreadable":unreadable, "scanner_errors":unavailable}
    matches, unmatched, ambiguous = [], 0, 0
    for entry in incoming["items"]:
        candidates = lookup.get((entry["sha256"],entry.get("size")), [])
        if not candidates:
            unmatched += 1
            continue
        if len(candidates) != 1:
            ambiguous += 1
            continue
        path, mtime = candidates[0]
        metadata = {key:str(entry["metadata"].get(key) or "")[:600] for key in ("title","channel","source_url")}
        if metadata["source_url"] and not metadata["source_url"].startswith(("https://","http://")):
            raise ValueError("Invalid source link in export")
        matches.append({"path":str(path),"size":entry["size"],"mtime":mtime,"metadata":metadata})
    token = uuid.uuid4().hex
    PREVIEWS.clear()
    PREVIEWS[token] = {"created":time.time(),"matches":matches}
    return {"token":token,"matched":len(matches),"unmatched":unmatched,"ambiguous":ambiguous,"unreadable":unreadable}
