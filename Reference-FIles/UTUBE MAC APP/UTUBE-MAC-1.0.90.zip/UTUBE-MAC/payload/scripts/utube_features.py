"""Read-only status helpers shared by the dashboard and release tests."""
import json
import os
import re
import shutil
import subprocess
from pathlib import Path

TERMINAL = {'completed', 'failed', 'cancelled', 'canceled'}

def read_status(path):
    try:
        return dict(line.split('=', 1) for line in path.read_text(errors='replace').splitlines() if '=' in line)
    except OSError:
        return {}

def alive(pid):
    try:
        pid = int(pid)
        if pid <= 1: return False
        os.kill(pid, 0)
        return True
    except (ValueError, TypeError, OSError):
        return False

def queue_summary(runtime):
    folder = Path(runtime) / 'Download Progress'
    manifests = sorted((folder / 'Queue').glob('queue-*.json'), key=lambda p: p.stat().st_mtime, reverse=True)
    if not manifests: return None
    # Prefer a running queue; otherwise report the latest recorded queue.
    records = []
    for path in manifests:
        try:
            record = json.loads(path.read_text())
            if isinstance(record.get('jobs'), list) and record['jobs']: records.append(record)
        except (OSError, ValueError, AttributeError): pass
    if not records: return None
    record = next((r for r in records if alive(r.get('pid'))), records[0])
    running = alive(record.get('pid'))
    counts = dict(completed=0, failed=0, cancelled=0, active=0, waiting=0, interrupted=0)
    for job in record['jobs']:
        if not isinstance(job, str) or not re.fullmatch(r'[A-Za-z0-9._-]+', job): continue
        state = read_status(folder / 'Jobs' / (job + '.status'))
        result = state.get('RESULT')
        if result in TERMINAL: counts['cancelled' if result == 'canceled' else result] += 1
        elif running:
            counts['active' if (folder / 'Jobs' / (job + '.active')).exists() else 'waiting'] += 1
        else: counts['interrupted'] += 1
    return dict(id=record.get('id'), total=sum(counts.values()), remaining=counts['active']+counts['waiting'], running=running, unit='queue-items', **counts)

def failure_info(runtime, job_id):
    if not re.fullmatch(r'[A-Za-z0-9._-]+', job_id): return {'category': 'unknown', 'retry': False}
    folder = Path(runtime) / 'Download Progress' / 'Jobs'
    status = read_status(folder / (job_id + '.status'))
    if status.get('RESULT') != 'failed': return {'category': 'none', 'retry': False}
    try:
        with (folder / (job_id + '.log')).open('rb') as stream:
            stream.seek(0, 2); stream.seek(max(0, stream.tell()-32000)); log = stream.read().decode(errors='replace').lower()
    except OSError: log = ''
    patterns = [
        ('destination-missing', ['utube_destination_missing:']),
        ('destination-denied', ['utube_destination_denied:']),
        ('disk', ['no space left on device', 'disk full']),
        ('permission', ['permission denied', 'operation not permitted']),
        ('missing-tool', ['ffmpeg not found', 'ffprobe not found', 'command not found', 'ffmpeg is not installed']),
        ('unavailable', ['video unavailable', 'private video', 'video has been removed', 'not available in your country']),
        ('authentication', ['sign in to confirm', 'login required', 'members-only', 'age-restricted']),
        ('network', ['timed out', 'temporary failure in name resolution', 'network is unreachable', 'connection reset', 'unable to download webpage']),
    ]
    category = next((key for key, needles in patterns if any(n in log for n in needles)), 'unknown')
    return {'category': category, 'retry': saved_request(runtime, job_id) is not None}

def saved_request(runtime, job_id):
    if not re.fullmatch(r'[A-Za-z0-9._-]+', job_id): return None
    try:
        item = json.loads((Path(runtime) / 'Download Progress' / 'Jobs' / (job_id + '.request.json')).read_text())
        if item.get('mode') not in {'single-mp4','playlist-mp4','single-mp3','playlist-mp3','single-mp3-advanced','playlist-mp3-advanced','single-mkv','playlist-mkv'}: return None
        if not str(item.get('url', '')).startswith(('https://', 'http://')): return None
        if not all(isinstance(item.get(k), str) for k in ('mode','url','quality','subtitles')): return None
        return item
    except (OSError, ValueError, AttributeError): return None

def save_request(runtime, job_id, item):
    folder = Path(runtime) / 'Download Progress' / 'Jobs'
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / (job_id + '.request.json')
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, 'w') as stream:
        json.dump({k: item[k] for k in ('mode','url','quality','subtitles')}, stream)

def tool_health(manifest):
    data = json.loads(Path(manifest).read_text())
    if data.get('schema') != 1: raise ValueError('Unsupported dependency manifest')
    rows = []
    for tool in data['tools']:
        command = tool['command']
        executable = next((str(p) for p in (Path('/opt/homebrew/bin')/command, Path('/usr/local/bin')/command) if p.is_file() and os.access(p, os.X_OK)), None) or shutil.which(command)
        state, version = 'missing', ''
        if executable:
            try:
                run = subprocess.run([executable, tool['flag']], capture_output=True, text=True, timeout=3)
                match = re.search(r'\d+(?:\.\d+)+', run.stdout + run.stderr)
                version = match.group() if match else ''
                def parts(v): return tuple((list(map(int, v.split('.')))+[0]*4)[:4])
                state = 'ready' if run.returncode == 0 and version and parts(version) >= parts(tool['minimum']) else 'outdated' if version and run.returncode == 0 else 'unavailable'
            except (OSError, subprocess.SubprocessError): state = 'unavailable'
        rows.append({**tool, 'state':state, 'version':version})
    return rows
