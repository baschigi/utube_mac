#!/usr/bin/env python3
"""One developer-side builder for both 03 and 04. Never publishes anything."""
import argparse
import hashlib
import json
import os
import platform
import plistlib
import re
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = 'https://raw.githubusercontent.com/baschigi/utube_mac/main/Reference-FIles/UTUBE%20MAC%20APP'
# Explicit runtime inventory. No Settings, library databases, histories or caches.
RUNTIME = (
    'utube_features.py', 'utube_i18n.html', 'translations.json', 'utube_feature_settings.html',
    'utube_developer_console.py', 'utube_library_tools.py',
    'utube_embedded_player.html', 'utube_library_settings.html',
    'utube_settings_help.html', 'utube_media_download.sh',
    'open_utube_dashboard.sh', 'move_audio_to_music.sh',
    'utube_progress_dashboard.sh', 'snapshot_utube_scripts.sh',
    'UTUBE-MAC-App.swift', 'UTUBESetup.swift', 'dependencies.json',
    'dependency-manager.sh', 'install.sh', 'update_utube_tools.sh',
    'build_release.py', 'Install.command', 'Build Complete Package.command',
)

def build(args):
    if not re.fullmatch(r'\d\.\d(?:\.\d)?', args.version):
        raise ValueError('Use X.Y or X.Y.Z, one digit per component')
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    final = output / f'UTUBE-MAC-{args.version}.zip'
    if final.exists():
        raise ValueError(f'{final} already exists. Published version numbers must not be reused; choose a new version or a different output folder.')
    staging = Path(tempfile.mkdtemp(prefix='utube-build-'))
    root = staging / 'UTUBE-MAC'
    scripts = root / 'payload/scripts'
    scripts.mkdir(parents=True)
    for name in RUNTIME:
        source = HERE / name
        if not source.is_file():
            source = args.support / 'scripts' / name
        if not source.is_file() or source.is_symlink():
            raise ValueError(f'Missing runtime file: {name}')
        shutil.copyfile(source, scripts / name)
        (scripts / name).chmod(0o755 if name.endswith(('.sh', '.command')) else 0o644)
    app = root / 'payload/app/UTUBE MAC.app'
    macos = app / 'Contents/MacOS'
    resources = app / 'Contents/Resources'
    macos.mkdir(parents=True)
    resources.mkdir()
    icon = args.support / 'Assets/UTUBE-MAC-Icon.icns'
    if not icon.is_file():
        icon = Path.home() / 'Applications/UTUBE MAC.app/Contents/Resources/UTUBE-MAC-Icon.icns'
    shutil.copyfile(icon, resources / 'UTUBE-MAC-Icon.icns')
    # Multi-file Swift programs require the top-level entry point to be main.swift.
    shutil.copyfile(scripts / 'UTUBE-MAC-App.swift', staging / 'main.swift')
    subprocess.run(['xcrun', 'swiftc', '-module-cache-path', '/private/tmp/utube-swift-module-cache',
                    '-O', '-target', f'{platform.machine()}-apple-macos{args.minimum_macos}',
                    '-framework', 'Cocoa', '-framework', 'WebKit', '-framework', 'AVKit',
                    '-framework', 'AVFoundation', str(staging / 'main.swift'),
                    str(scripts / 'UTUBESetup.swift'), '-o', str(macos / 'UTUBE MAC')], check=True)
    info = dict(CFBundleDisplayName='UTUBE MAC', CFBundleName='UTUBE MAC',
                CFBundleExecutable='UTUBE MAC', CFBundleIdentifier='com.utube-mac.webapp',
                CFBundleIconFile='UTUBE-MAC-Icon', CFBundlePackageType='APPL',
                CFBundleShortVersionString=args.version, CFBundleVersion=args.version,
                LSMinimumSystemVersion=args.minimum_macos)
    (app / 'Contents/Info.plist').write_bytes(plistlib.dumps(info))
    subprocess.run(['/usr/bin/codesign', '--force', '--sign', '-', str(app)], check=True)
    subprocess.run(['/usr/bin/codesign', '--verify', '--deep', '--strict', str(app)], check=True)
    manifest = dict(schema=1, bootstrap_protocol=1, version=args.version,
                    architecture=platform.machine(), minimum_macos=args.minimum_macos)
    (root / 'package.json').write_text(json.dumps(manifest, indent=2) + '\n')
    shutil.copyfile(HERE / 'Install.command', root / 'Install.command')
    (root / 'Install.command').chmod(0o755)
    inventory = []
    for file in sorted((root / 'payload').rglob('*')):
        if file.is_symlink():
            raise ValueError(f'Unexpected symbolic link: {file}')
        if file.is_file():
            inventory.append(hashlib.sha256(file.read_bytes()).hexdigest() + '\t' + str(file.relative_to(root / 'payload')))
    (root / 'inventory.tsv').write_text('\n'.join(inventory) + '\n')
    (root / 'READ-ME.txt').write_text('UTUBE MAC complete package\n\nQuit UTUBE MAC and finish downloads, then double-click Install.command.\nSettings, libraries, media and the independently versioned Shortcut are preserved.\nNo Homebrew/Python is needed to run this installer. The app offers native tool setup.\nThis local build is ad-hoc signed, not Developer ID signed/notarized. macOS may require explicit approval.\nDo not disable Gatekeeper or remove quarantine protections.\n')
    temporary_zip = staging / final.name
    with zipfile.ZipFile(temporary_zip, 'w', zipfile.ZIP_DEFLATED) as archive:
        for file in sorted(root.rglob('*')):
            if file.is_file():
                archive.write(file, str(file.relative_to(staging)))
    manifest.update(package_url=f'{BASE}/{final.name}', sha256=hashlib.sha256(temporary_zip.read_bytes()).hexdigest())
    shutil.copyfile(temporary_zip, final)
    (output / f'{args.version}.json').write_text(json.dumps(manifest, indent=2) + '\n')
    # Local pointer only. Publishing is a separate, explicit operation.
    (output / 'latest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    shutil.copyfile(HERE / 'install.sh', output / 'install.sh')
    print(f'Complete package: {final}\nUnpacked package for testing: {root}\nNot published. Upload the ZIP and version manifest before latest.json.')
    return root

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--support', type=Path, default=Path.home() / 'Library/Application Support/UTUBE-MAC')
    parser.add_argument('--version', required=True)
    parser.add_argument('--minimum-macos', default='26.5')
    parser.add_argument('--output', type=Path, required=True)
    build(parser.parse_args())
