#!/bin/bash
# Last updated: 07 September 2026 · 22:11 CEST
# Saves one readable, self-contained snapshot of the currently installed scripts.

set -Eeuo pipefail

support_directory="$HOME/Library/Application Support/UTUBE-MAC"
scripts_directory="$support_directory/scripts"
settings_directory="$support_directory/Settings"
history_directory="$support_directory/History/Script History"
version_file="$settings_directory/General/utube-mac-version.txt"
version="$(tr -d '[:space:]' < "$version_file" 2>/dev/null || printf '6.2.0')"
[[ "$version" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || version="6.2.0"
version_tag="V${version//./_}"
timestamp="$(date '+%d%m%Y__%H%M%S')"
snapshot_directory="$history_directory/${version_tag}__${timestamp}"

# Keep the main history readable for every user.  The current naming scheme is
# V6_2_0__DDMMYYYY__HHMMSS.  Any older naming style remains preserved, but is
# moved into one archive folder instead of cluttering the main history view.
archive_directory="$history_directory/Archive – older script snapshots"
mkdir -p "$history_directory" "$archive_directory"
while IFS= read -r -d '' candidate; do
  candidate_name="$(basename "$candidate")"
  [[ "$candidate" == "$archive_directory" ]] && continue
  if [[ ! "$candidate_name" =~ ^V[0-9]+_[0-9]+_[0-9]+__[0-9]{8}__[0-9]{6}$ ]]; then
    destination="$archive_directory/$candidate_name"
    if [[ -e "$destination" ]]; then
      destination="$archive_directory/${candidate_name}__migrated-$(date '+%Y%m%d-%H%M%S')"
    fi
    mv "$candidate" "$destination"
  fi
done < <(find "$history_directory" -mindepth 1 -maxdepth 1 -type d -print0)

mkdir -p "$snapshot_directory"
find "$scripts_directory" -maxdepth 1 -type f \( -name '*.sh' -o -name '*.py' -o -name '*.swift' \) -print0 | while IFS= read -r -d '' script_file; do
  /usr/bin/ditto "$script_file" "$snapshot_directory/$(basename "$script_file")"
done

if [[ -d "$settings_directory" ]]; then
  /usr/bin/ditto "$settings_directory" "$snapshot_directory/Settings"
fi

printf 'UTUBE MAC script snapshot\nShortcut version: %s\nCreated: %s\n' \
  "$version" "$(date '+%d.%m.%Y %H:%M:%S %Z')" > "$snapshot_directory/INFO.txt"
printf '%s\n' "$snapshot_directory"
