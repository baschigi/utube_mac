#!/bin/bash
# Same release selection and engine as the permanent Terminal command.
set -euo pipefail
directory="$(cd "$(dirname "$0")" && pwd)"
exec /bin/bash "$directory/install.sh" "$@"
