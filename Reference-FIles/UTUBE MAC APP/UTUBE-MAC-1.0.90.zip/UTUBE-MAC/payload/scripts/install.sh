#!/bin/bash
# Permanent bootstrap. Requires only the tools supplied with macOS.
set -euo pipefail
release_base='https://raw.githubusercontent.com/baschigi/utube_mac/main/Reference-FIles/UTUBE%20MAC%20APP'
requested=latest
while [[ $# -gt 0 ]]; do
  case "$1" in
    --version) requested="${2:?Version required}"; shift 2 ;;
    *) echo 'Usage: install.sh [--version X.Y.Z]'; exit 2 ;;
  esac
done
[[ "$requested" == latest || "$requested" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || exit 2
[[ "$(uname -s)" == Darwin ]] || { echo 'UTUBE MAC requires macOS.'; exit 1; }
work="$(mktemp -d "${TMPDIR:-/tmp}/utube-download.XXXXXXXX")"
verified=false
failed(){
  result=$?
  [[ "$result" != 0 ]] || return 0
  trap - EXIT
  echo "Installer stopped. Details are above. Download folder: $work"
  choice="$(/usr/bin/osascript - "$verified" <<'APPLESCRIPT'
on run argv
  set choices to {"Close", "Retry"}
  if item 1 of argv is "true" then set choices to {"Close", "Open package folder", "Retry"}
  return button returned of (display dialog "UTUBE MAC could not finish. Read the error in Terminal. Retry repeats verification. Opening the folder does not rerun the installer." with title "UTUBE MAC installer" buttons choices default button "Close" with icon caution)
end run
APPLESCRIPT
  )" || choice=Close
  if [[ "$choice" == 'Open package folder' && "$verified" == true ]]; then /usr/bin/open "$package"; fi
  if [[ "$choice" == Retry && -f "$0" ]]; then exec /bin/bash "$0" --version "$requested"; fi
  exit "$result"
}
trap failed EXIT
echo "Preparing installer in $work"
fetch(){ /usr/bin/curl --proto '=https' --proto-redir '=https' --tlsv1.2 -fL --retry 2 --connect-timeout 15 --max-time 600 "$1" -o "$2"; }
fetch "$release_base/$requested.json" "$work/release.json" || { echo 'Download failed. Your installation was not changed. Run the same command to retry.'; exit 1; }
field(){ /usr/bin/plutil -extract "$1" raw -o - "$work/release.json"; }
[[ "$(field schema)" == 1 ]] || { echo 'Unsupported release manifest.'; exit 1; }
[[ "$(field bootstrap_protocol)" == 1 ]] || { echo 'This release needs a different installer protocol. No files changed. See the official installation instructions.'; exit 1; }
version="$(field version)"; hash="$(field sha256)"; url="$(field package_url)"
[[ "$version" =~ ^[0-9]\.[0-9](\.[0-9])?$ && "$hash" =~ ^[a-f0-9]{64}$ ]] || exit 1
[[ "$requested" == latest || "$version" == "$requested" ]] || exit 1
[[ "$url" == "$release_base/UTUBE-MAC-$version.zip" ]] || { echo 'Unexpected package location.'; exit 1; }
[[ "$(field architecture)" == "$(uname -m)" ]] || { echo 'This release does not support your Mac architecture.'; exit 1; }
at_least(){ /usr/bin/awk -v a="$1" -v b="$2" 'BEGIN{split(a,x,".");split(b,y,".");for(i=1;i<=4;i++){if(x[i]+0>y[i]+0)exit 0;if(x[i]+0<y[i]+0)exit 1}exit 0}'; }
at_least "$(sw_vers -productVersion)" "$(field minimum_macos)" || { echo 'This release requires a newer macOS.'; exit 1; }
fetch "$url" "$work/package.zip" || { echo 'Package download failed. Nothing installed; run again to retry.'; exit 1; }
[[ "$(/usr/bin/shasum -a 256 "$work/package.zip" | /usr/bin/awk '{print $1}')" == "$hash" ]] || { echo 'Checksum mismatch. Nothing installed.'; exit 1; }
# Reject traversal, hidden extra roots, symlinks and unusual names BEFORE extracting.
/usr/bin/zipinfo -1 "$work/package.zip" > "$work/entries"
/usr/bin/awk 'BEGIN{ok=1} !/^UTUBE-MAC\// || /(^|\/)\.\.?(\/|$)/ || /[^A-Za-z0-9_ .\/-]/ {ok=0} END{exit !ok}' "$work/entries" || { echo 'Unsafe archive paths.'; exit 1; }
/usr/bin/zipinfo -l "$work/package.zip" | /usr/bin/awk '/^[lcbps]/ {bad=1} END{exit bad}' || { echo 'Archive contains links or special files.'; exit 1; }
duplicates="$(sort "$work/entries" | uniq -d)"; [[ -z "$duplicates" ]] || { echo 'Duplicate archive entries.'; exit 1; }
/usr/bin/ditto -x -k "$work/package.zip" "$work/unpacked"
package="$work/unpacked/UTUBE-MAC"
[[ -f "$package/Install.command" && -f "$package/package.json" ]] || exit 1
[[ "$(/usr/bin/plutil -extract schema raw -o - "$package/package.json")" == 1 ]] || { echo 'Unsupported package layout. Nothing installed.'; exit 1; }
[[ "$(/usr/bin/plutil -extract version raw -o - "$package/package.json")" == "$version" ]] || exit 1
[[ "$(/usr/bin/plutil -extract architecture raw -o - "$package/package.json")" == "$(field architecture)" ]] || exit 1
[[ "$(/usr/bin/plutil -extract minimum_macos raw -o - "$package/package.json")" == "$(field minimum_macos)" ]] || exit 1
verified=true
if [[ "$requested" == latest ]]; then
  /bin/bash "$package/Install.command"
else
  /bin/bash "$package/Install.command" --allow-downgrade
fi
echo "Downloaded package retained for recovery: $work/package.zip"
