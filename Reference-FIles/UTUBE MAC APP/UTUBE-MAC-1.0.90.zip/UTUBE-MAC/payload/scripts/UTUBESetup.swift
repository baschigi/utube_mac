import Cocoa

final class UTUBESetup {
  static let shared = UTUBESetup()
  private var checking = false
  private let support = FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Library/Application Support/UTUBE-MAC")
  func check(force: Bool = false, completion: @escaping (Bool) -> Void) {
    guard !checking else { return }
    checking = true
    let script = support.appendingPathComponent("scripts/dependency-manager.sh")
    let version = (try? String(contentsOf: support.appendingPathComponent("Settings/General/utube-mac-version.txt"), encoding:.utf8).trimmingCharacters(in:.whitespacesAndNewlines)) ?? "unknown"
    DispatchQueue.global().async {
      let task=Process(), pipe=Pipe()
      task.executableURL=URL(fileURLWithPath:"/bin/bash");task.arguments=[script.path,"--check"]
      task.standardOutput=pipe;task.standardError=FileHandle.nullDevice
      var output=""
      do {try task.run();output=String(data:pipe.fileHandleForReading.readDataToEndOfFile(),encoding:.utf8) ?? "";task.waitUntilExit()} catch {}
      let rows=output.split(separator:"\n").map{$0.split(separator:"\t").map(String.init)}.filter{$0.count==4}
      DispatchQueue.main.async {
        self.checking=false
        let required=rows.filter{$0[1] != "ready" && $0[2]=="true"}
        let pythonReady=rows.contains{$0[0]=="python" && $0[1]=="ready"}
        let firstRun = !UserDefaults.standard.bool(forKey:"utubeSetupPresentedV1")
        if !force && !firstRun && !rows.isEmpty && required.isEmpty {completion(true);return}
        let key="utubeDependencyDeferred"
        if !force && !firstRun && pythonReady && UserDefaults.standard.string(forKey:key)==version {completion(true);return}
        let alert=NSAlert();alert.messageText="UTUBE MAC — Tools & Setup"
        if rows.isEmpty {
          alert.informativeText="The setup manifest or checker is missing. Run the permanent installer to repair this installation."
          alert.addButton(withTitle:"Close");alert.runModal();completion(false);return
        }
        alert.informativeText="Required tools are selected below. Optional tools can be selected individually. Installation opens Terminal for progress and any official Homebrew password prompt. UTUBE MAC never collects your password."
        let stack=NSStackView();stack.orientation = .vertical;stack.alignment = .leading;stack.spacing=7
        var choices:[NSButton]=[]
        for row in rows {
          let button=NSButton(checkboxWithTitle:"\(row[1]=="ready" ? "✓" : "○") \(row[0]) [\(row[2]=="true" ? "Required" : "Optional")] — \(row[3])",target:nil,action:nil)
          button.identifier=NSUserInterfaceItemIdentifier(row[0])
          button.isEnabled=row[1] != "ready"
          button.state=(row[1] != "ready" && row[2]=="true") ? .on : .off
          choices.append(button);stack.addArrangedSubview(button)
        }
        stack.frame=NSRect(x:0,y:0,width:560,height:240);alert.accessoryView=stack
        alert.addButton(withTitle:"Install selected");alert.addButton(withTitle:"Check again")
        alert.addButton(withTitle:pythonReady ? "Continue with available features" : "Quit")
        let answer=alert.runModal()
        UserDefaults.standard.set(true,forKey:"utubeSetupPresentedV1")
        if answer == .alertFirstButtonReturn {
          let ids=choices.filter{$0.isEnabled && $0.state == .on}.compactMap{$0.identifier?.rawValue}
          if ids.isEmpty {completion(pythonReady);return}
          func quote(_ value:String)->String {"'"+value.replacingOccurrences(of:"'",with:"'\\''")+"'"}
          let command=(["/bin/bash",script.path,"--install"]+ids).map(quote).joined(separator:" ")
          // Launch a real Terminal document through Launch Services. This does
          // not need Apple Events permission and never hides launch errors.
          do {
            let folder=self.support.appendingPathComponent("Runtime/Tool Setup/"+UUID().uuidString,isDirectory:true)
            try FileManager.default.createDirectory(at:folder,withIntermediateDirectories:true,attributes:[.posixPermissions:0o700])
            let launcher=folder.appendingPathComponent("Install Selected Tools.command")
            let text="#!/bin/bash\n"+command+"\nresult=$?\nprintf '\\nSetup finished with exit code %s. Return to UTUBE MAC and choose Check again.\\n' \"$result\"\nprintf 'Press Return to close this session.'\nread -r answer\nexit \"$result\"\n"
            try text.write(to:launcher,atomically:true,encoding:.utf8)
            try FileManager.default.setAttributes([.posixPermissions:0o700],ofItemAtPath:launcher.path)
            guard let terminal=NSWorkspace.shared.urlForApplication(withBundleIdentifier:"com.apple.Terminal") else {
              throw NSError(domain:"UTUBESetup",code:1,userInfo:[NSLocalizedDescriptionKey:"Terminal could not be found."])
            }
            let config=NSWorkspace.OpenConfiguration();config.activates=true
            NSWorkspace.shared.open([launcher],withApplicationAt:terminal,configuration:config) { _,error in
              DispatchQueue.main.async {
                if let error=error {
                  let failed=NSAlert(error:error);failed.messageText="Terminal could not open the installer"
                  failed.informativeText="No installation has been confirmed. You can retry setup. Installer file: "+launcher.path
                  failed.runModal();self.check(force:true,completion:completion);return
                }
                UserDefaults.standard.set(version,forKey:key)
                let next=NSAlert();next.messageText="Finish setup in Terminal";next.informativeText="The selected installer was opened in Terminal. When installation finishes, choose Check again. Opening Terminal does not mean installation has finished."
                next.addButton(withTitle:"Check again");next.addButton(withTitle:"Later")
                if next.runModal() == .alertFirstButtonReturn {self.check(force:true,completion:completion)}
                else {completion(pythonReady)}
              }
            }
          } catch {
            let failed=NSAlert(error:error);failed.messageText="The tool installer could not be prepared";failed.runModal()
            self.check(force:true,completion:completion)
          }
        } else if answer == .alertSecondButtonReturn {
          self.check(force:true,completion:completion)
        } else {UserDefaults.standard.set(version,forKey:key);completion(pythonReady)}
      }
    }
  }
}
