#!/bin/bash
set -u

apple_music_directory="$HOME/Music/Music/Media.localized/Automatically Add to Music.localized"
support_directory="${UTUBE_MAC_SUPPORT_DIRECTORY:-$HOME/Library/Application Support/UTUBE-MAC}"
downloads_location_file="$support_directory/Settings/General/downloads_directory.txt"
queue_file="$(mktemp "${TMPDIR:-/tmp}/utube-music-import.XXXXXX")"
trap 'rm -f -- "$queue_file"' EXIT HUP INT TERM

show_message() {
  local message="$1"
  local icon="${2:-note}"
  osascript - "$message" "$icon" <<'MESSAGE_EOF'
on run argv
  set messageText to item 1 of argv
  set iconType to item 2 of argv
  if iconType is "caution" then
    display dialog messageText with title "UTUBE MAC – Apple Music" buttons {"Fertig"} default button "Fertig" with icon caution
  else
    display dialog messageText with title "UTUBE MAC – Apple Music" buttons {"Fertig"} default button "Fertig" with icon note
  end if
end run
MESSAGE_EOF
}

# Music creates its watched import folder after it has been opened at least
# once. Start it only when the standard folder is still missing.
if [[ ! -d "$apple_music_directory" ]]; then
  open -a Music
  for unused_iteration in 1 2 3 4 5; do
    [[ -d "$apple_music_directory" ]] && break
    sleep 1
  done
fi

if [[ ! -d "$apple_music_directory" ]]; then
  show_message "Der automatische Importordner von Apple Music wurde nicht gefunden. Öffne Music einmal, richte deine Mediathek ein und versuche es danach erneut." "caution"
  exit 1
fi

if [[ -r "$downloads_location_file" ]]; then
  downloads_directory="$(<"$downloads_location_file")"
else
  downloads_directory="$HOME/Downloads/UTUBE-MAC"
fi
downloads_directory="${downloads_directory%$'\r'}"
downloads_directory="${downloads_directory#\"}"
downloads_directory="${downloads_directory%\"}"
downloads_directory="${downloads_directory/#\$HOME/$HOME}"
downloads_directory="${downloads_directory/#\~/$HOME}"

mp3_single_directory="$downloads_directory/MP3/Single"
mp3_playlists_directory="$downloads_directory/MP3/Playlists"

append_mp3_file() {
  local candidate="$1"
  local extension

  [[ -f "$candidate" ]] || return 0
  extension="${candidate##*.}"
  extension="$(printf '%s' "$extension" | tr '[:upper:]' '[:lower:]')"
  [[ "$extension" == "mp3" ]] || return 0
  printf '%s\0' "$candidate" >> "$queue_file"
}

for source_directory in "$mp3_single_directory" "$mp3_playlists_directory"; do
  [[ -d "$source_directory" ]] || continue
  while IFS= read -r -d '' nested_file; do
    append_mp3_file "$nested_file"
  done < <(find "$source_directory" -type f -iname '*.mp3' -print0 2>/dev/null)
done

eligible_count=0
while IFS= read -r -d '' unused_audio_file; do
  eligible_count=$((eligible_count + 1))
done < "$queue_file"

if [[ "$eligible_count" -eq 0 ]]; then
  show_message "In MP3/Single und MP3/Playlists wurden keine MP3-Dateien gefunden. Es wurde nichts verschoben." "note"
  exit 0
fi

confirmation="$(osascript - "$eligible_count" <<'CONFIRM_MUSIC_MOVE_EOF'
on run argv
  display dialog ((item 1 of argv) & " MP3-Datei(en) aus MP3/Single und MP3/Playlists werden zu Apple Music verschoben." & return & return & "Möchtest du fortfahren?" & return & return & "Die Dateien bleiben danach nicht in den bisherigen UTUBE-MAC-Ordnern.") with title "UTUBE MAC – Apple Music" buttons {"Abbrechen", "Fortfahren"} default button "Fortfahren" with icon caution
end run
CONFIRM_MUSIC_MOVE_EOF
)"
[[ "$confirmation" == *"Fortfahren"* ]] || exit 0

moved_count=0
failed_count=0
while IFS= read -r -d '' audio_file; do
  [[ -f "$audio_file" ]] || continue
  if [[ "$audio_file" == "$apple_music_directory/"* ]]; then
    continue
  fi

  file_name="$(basename "$audio_file")"
  destination_file="$apple_music_directory/$file_name"
  if [[ -e "$destination_file" ]]; then
    name_without_extension="${file_name%.*}"
    extension="${file_name##*.}"
    destination_file="$apple_music_directory/${name_without_extension} - $(date '+%Y%m%d-%H%M%S')-$$.$extension"
  fi

  if mv -- "$audio_file" "$destination_file"; then
    moved_count=$((moved_count + 1))
  else
    failed_count=$((failed_count + 1))
  fi
done < "$queue_file"

result_choice="$(osascript - "$moved_count" "$failed_count" <<'MUSIC_MOVE_COMPLETE_EOF'
on run argv
  display dialog ("An Apple Music übergeben: " & (item 1 of argv) & return & "Fehlgeschlagen: " & (item 2 of argv) & return & return & "Music verarbeitet die Dateien automatisch.") with title "UTUBE MAC – Apple Music" buttons {"Fertig", "Music öffnen"} default button "Fertig" with icon note
end run
MUSIC_MOVE_COMPLETE_EOF
)"

if [[ "$result_choice" == *"Music öffnen"* ]]; then
  open -a Music
fi
