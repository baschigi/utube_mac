#!/bin/bash
set -u

export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"

support_directory="${UTUBE_MAC_SUPPORT_DIRECTORY:-$HOME/Library/Application Support/UTUBE-MAC}"
runtime_directory="$support_directory/Runtime/Download Progress"
jobs_directory="$runtime_directory/Jobs"
dashboard_pid_file="$runtime_directory/dashboard.pid"
dashboard_launch_lock="$runtime_directory/dashboard-launching.lock"

mkdir -p "$jobs_directory"
printf '%s\n' "$$" > "$dashboard_pid_file"
rmdir "$dashboard_launch_lock" 2>/dev/null || true

cleanup_dashboard() {
  rm -f -- "$dashboard_pid_file"
  # Restore the cursor and the user's normal Terminal buffer. The animated
  # dashboard uses the alternate screen, so its per-second redraws never fill
  # the regular scrollback history.
  printf '\033[?25h\033[0m\033[?1049l'
}
trap cleanup_dashboard EXIT
trap 'exit 130' HUP INT TERM

reset=$'\033[0m'
bold=$'\033[1m'
dim=$'\033[2m'
red=$'\033[1;31m'
green=$'\033[1;32m'
yellow=$'\033[1;33m'
blue=$'\033[1;34m'
magenta=$'\033[1;35m'
cyan=$'\033[1;36m'
orange=$'\033[38;5;208m'
purple=$'\033[38;5;141m'

dashboard_started_epoch="$(date +%s)"
ever_seen_job=0
idle_cycles=0
animation_index=0
animation_frames=('⠋' '⠙' '⠹' '⠸' '⠼' '⠴' '⠦' '⠧' '⠇' '⠏')
pulse_frames=('·' '•' '●' '•')
playlist_details_visible=0
playlist_page=0
playlist_page_size=8
dashboard_hint="L = Playlist-Liste öffnen"
# Use Terminal's alternate screen buffer and hide the cursor. Repainting this
# buffer does not append hundreds of copies to the normal Terminal history.
printf '\033[?1049h\033[2J\033[H\033[?25l'

format_elapsed() {
  local total_seconds="$1"
  printf '%02d:%02d' "$((total_seconds / 60))" "$((total_seconds % 60))"
}

render_cow_status() {
  local count="$1"
  local cow_message
  local cow_color="$purple"
  local cow_line

  if [[ "$count" -eq 0 ]]; then
    cow_message="Alle Downloads sind beendet – muh-tastisch!"
    cow_color="$green"
  elif [[ "$count" -eq 1 ]]; then
    cow_message="Aktive Downloads oder Dialoge: 1 – Muh!"
  else
    cow_message="Aktive Downloads oder Dialoge: $count – Muh!"
  fi

  printf '\n'
  if command -v cowsay >/dev/null 2>&1; then
    while IFS= read -r cow_line; do
      printf '%s%s%s\n' "$cow_color" "$cow_line" "$reset"
    done < <(cowsay -W 50 "$cow_message")
  else
    printf '%s  %s%s\n' "$cow_color" "$cow_message" "$reset"
    printf '%s        \\   ^__^\n         \\  (oo)\\_______\n            (__)\\       )\\/\\\n                ||----w |\n                ||     ||%s\n' "$cow_color" "$reset"
  fi
}

make_bar() {
  local raw_percent="$1"
  local percent_integer
  local filled
  local empty
  local full_bar
  local empty_bar

  percent_integer="$(printf '%s' "$raw_percent" | awk '{value=$1+0; if (value<0) value=0; if (value>100) value=100; printf "%d", value}')"
  filled=$((percent_integer * 28 / 100))
  empty=$((28 - filled))
  printf -v full_bar '%*s' "$filled" ''
  printf -v empty_bar '%*s' "$empty" ''
  full_bar="${full_bar// /█}"
  empty_bar="${empty_bar// /░}"
  printf '%s%s' "$full_bar" "$empty_bar"
}

make_small_bar() {
  local raw_percent="$1"
  local percent_integer
  local filled
  local empty
  local full_bar
  local empty_bar

  percent_integer="$(printf '%s' "$raw_percent" | awk '{value=$1+0; if (value<0) value=0; if (value>100) value=100; printf "%d", value}')"
  filled=$((percent_integer * 12 / 100))
  empty=$((12 - filled))
  printf -v full_bar '%*s' "$filled" ''
  printf -v empty_bar '%*s' "$empty" ''
  full_bar="${full_bar// /■}"
  empty_bar="${empty_bar// /·}"
  printf '%s%s' "$full_bar" "$empty_bar"
}

render_playlist_items() {
  local status_file="$1"
  local items_directory="${status_file%.status}.items"
  local item_count=0
  local total_pages=1
  local page_start=0
  local page_end=0
  local item_position=0
  local item_status_file
  local item_index
  local item_total
  local item_title
  local item_phase
  local item_percent
  local item_result
  local item_color
  local item_icon
  local item_bar
  local display_title

  [[ -d "$items_directory" ]] || return 0
  item_count="$(find "$items_directory" -maxdepth 1 -type f -name 'item-*.status' 2>/dev/null | wc -l | tr -d '[:space:]')"
  [[ "$item_count" =~ ^[0-9]+$ ]] || item_count=0
  [[ "$item_count" -gt 0 ]] || return 0

  if [[ "$playlist_details_visible" -eq 0 ]]; then
    printf '  %s📚 Playlist:%s %s Titel  %s▸ [L] Titelliste öffnen%s\n\n' \
      "$purple" "$reset" "$item_count" "$dim" "$reset"
    return 0
  fi

  total_pages=$(( (item_count + playlist_page_size - 1) / playlist_page_size ))
  [[ "$total_pages" -gt 0 ]] || total_pages=1
  if [[ "$playlist_page" -ge "$total_pages" ]]; then
    playlist_page=$((total_pages - 1))
  fi
  [[ "$playlist_page" -ge 0 ]] || playlist_page=0
  page_start=$((playlist_page * playlist_page_size))
  page_end=$((page_start + playlist_page_size))

  printf '  %s📚 PLAYLIST-TITEL%s  %sSeite %s/%s · %s Titel%s\n' \
    "$bold$purple" "$reset" "$dim" "$((playlist_page + 1))" "$total_pages" "$item_count" "$reset"

  for item_status_file in "$items_directory"/item-*.status; do
    [[ -f "$item_status_file" ]] || continue
    if [[ "$item_position" -lt "$page_start" ]]; then
      item_position=$((item_position + 1))
      continue
    fi
    [[ "$item_position" -lt "$page_end" ]] || break

    item_index="$((item_position + 1))"
    item_total="$item_count"
    item_title="Titel wird geladen"
    item_phase="Wartet"
    item_percent="0"
    item_result="queued"
    while IFS='=' read -r item_key item_value; do
      case "$item_key" in
        INDEX) item_index="$item_value" ;;
        TOTAL) item_total="$item_value" ;;
        TITLE) item_title="$item_value" ;;
        PHASE) item_phase="$item_value" ;;
        PERCENT) item_percent="$item_value" ;;
        RESULT) item_result="$item_value" ;;
      esac
    done < "$item_status_file"
    if [[ ! "$item_total" =~ ^[0-9]+$ || "$item_total" -le 0 ]]; then
      item_total="$item_count"
    fi

    case "$item_result" in
      completed) item_color="$green"; item_icon="✅" ;;
      failed) item_color="$red"; item_icon="❌" ;;
      skipped) item_color="$yellow"; item_icon="↷" ;;
      active) item_color="$cyan"; item_icon="$live_spinner" ;;
      *) item_color="$dim"; item_icon="○" ;;
    esac

    display_title="$item_title"
    if [[ "${#display_title}" -gt 48 ]]; then
      display_title="${display_title:0:47}…"
    fi
    item_bar="$(make_small_bar "$item_percent")"
    printf '    %s%s%s %s%02d/%02d%s  %s\n' \
      "$bold" "$item_color" "$item_icon" "$dim" "$item_index" "$item_total" "$reset" "$display_title"
    printf '       %s[%s]%s %5s%%  %s%s%s\n' \
      "$item_color" "$item_bar" "$reset" "$item_percent" "$dim" "$item_phase" "$reset"
    item_position=$((item_position + 1))
  done

  printf '  %s▾ [L] Liste schließen%s' "$dim" "$reset"
  if [[ "$total_pages" -gt 1 ]]; then
    printf '   %s◀ [P] zurück   [N] weiter ▶%s' "$dim" "$reset"
  fi
  printf '\n\n'
}

while :; do
  pressed_key=""
  if [[ -t 0 ]]; then
    # macOS still ships Bash 3.2, whose read command accepts whole-second
    # timeouts only. This one-second input wait also replaces the loop sleep.
    if IFS= read -rsn1 -t 1 pressed_key 2>/dev/null; then
      case "$pressed_key" in
        l|L)
          if [[ "$playlist_details_visible" -eq 0 ]]; then
            playlist_details_visible=1
            dashboard_hint="L = Liste schließen · N/P = Seite wechseln"
          else
            playlist_details_visible=0
            dashboard_hint="L = Playlist-Liste öffnen"
          fi
          ;;
        n|N)
          playlist_page=$((playlist_page + 1))
          ;;
        p|P)
          if [[ "$playlist_page" -gt 0 ]]; then
            playlist_page=$((playlist_page - 1))
          fi
          ;;
      esac
    fi
  else
    sleep 1
  fi

  live_spinner="${animation_frames[$animation_index]}"
  live_pulse="${pulse_frames[$((animation_index % ${#pulse_frames[@]}))]}"
  animation_index=$(( (animation_index + 1) % ${#animation_frames[@]} ))
  dashboard_elapsed=$(( $(date +%s) - dashboard_started_epoch ))
  dashboard_clock="$(date '+%H:%M:%S')"

  printf '\033[2J\033[H\033]0;UTUBE MAC – Downloads\007'
  printf '%s%s╭──────────────────────────────────────────────────────────────╮%s\n' "$bold" "$purple" "$reset"
  printf '%s%s│              🚀  UTUBE MAC – DOWNLOADS  🚀                 │%s\n' "$bold" "$magenta" "$reset"
  printf '%s%s╰──────────────────────────────────────────────────────────────╯%s\n' "$bold" "$purple" "$reset"
  printf '  %s%s LIVE %s%s  %s%s%s  %s%s%s  Laufzeit %s%s%s\n' \
    "$cyan" "$live_spinner" "$live_pulse" "$reset" "$bold" "$dashboard_clock" "$reset" "$purple" "$live_pulse" "$reset" "$orange" "$(format_elapsed "$dashboard_elapsed")" "$reset"
  printf '  %s⌨️  %s%s\n\n' "$dim" "$dashboard_hint" "$reset"

  active_count=0
  shown_count=0

  for status_file in "$jobs_directory"/*.status; do
    [[ -f "$status_file" ]] || continue

    status_modified_epoch="$(stat -f '%m' "$status_file" 2>/dev/null || printf '0')"
    [[ "$status_modified_epoch" =~ ^[0-9]+$ ]] || status_modified_epoch=0
    if [[ "$status_modified_epoch" -lt $((dashboard_started_epoch - 5)) ]]; then
      continue
    fi

    active_marker="${status_file%.status}.active"
    shown_count=$((shown_count + 1))
    ever_seen_job=1

    job_pid=""
    title="Download"
    mode="—"
    phase="Vorbereitung"
    percent="0"
    speed="—"
    eta="—"
    result="active"

    while IFS='=' read -r key value; do
      case "$key" in
        PID) job_pid="$value" ;;
        TITLE) title="$value" ;;
        MODE) mode="$value" ;;
        PHASE) phase="$value" ;;
        PERCENT) percent="$value" ;;
        SPEED) speed="$value" ;;
        ETA) eta="$value" ;;
        RESULT) result="$value" ;;
      esac
    done < "$status_file"

    if [[ -f "$active_marker" ]]; then
      if [[ "$job_pid" =~ ^[0-9]+$ ]] && ! kill -0 "$job_pid" 2>/dev/null; then
        rm -f -- "$active_marker"
        result="failed"
        phase="Downloadprozess wurde beendet"
      else
        active_count=$((active_count + 1))
      fi
    fi

    case "$result" in
      completed) state_color="$green"; state_icon="✅" ;;
      failed) state_color="$red"; state_icon="❌" ;;
      waiting) state_color="$yellow"; state_icon="🕹️" ;;
      *) state_color="$cyan"; state_icon="$live_spinner" ;;
    esac

    progress_bar="$(make_bar "$percent")"
    percent_integer="$(printf '%s' "$percent" | awk '{value=$1+0; if (value<0) value=0; if (value>100) value=100; printf "%d", value}')"
    bar_color="$cyan"
    [[ "$percent_integer" -ge 50 ]] && bar_color="$yellow"
    [[ "$percent_integer" -ge 90 ]] && bar_color="$green"
    [[ "$result" == "failed" ]] && bar_color="$red"

    printf '%s%s  %s  %s%s\n' "$bold" "$state_color" "$state_icon" "$title" "$reset"
    printf '  %s%s%s  %s•%s  %s\n' "$dim" "$mode" "$reset" "$purple" "$reset" "$phase"
    printf '  %s[%s]%s %s%6s%%%s\n' "$bar_color" "$progress_bar" "$reset" "$bold" "$percent" "$reset"
    printf '  %s⚡ Geschwindigkeit:%s %s    %s⏳ Restzeit:%s %s\n' "$blue" "$reset" "$speed" "$orange" "$reset" "$eta"
    case "$mode" in
      playlist-*) render_playlist_items "$status_file" ;;
      *) printf '\n' ;;
    esac
  done

  if [[ "$shown_count" -eq 0 ]]; then
    printf '%s%s Ein Download wird vorbereitet …%s\n' "$yellow" "$live_spinner" "$reset"
  else
    printf '%s────────────────────────────────────────────────────────────────%s\n' "$purple" "$reset"
    render_cow_status "$active_count"
  fi

  if [[ "$active_count" -eq 0 && "$ever_seen_job" -eq 1 ]]; then
    idle_cycles=$((idle_cycles + 1))
    printf '\n%s✨ Alle Downloads sind beendet. Fenster schließt automatisch …%s\n' "$green" "$reset"
    if [[ "$idle_cycles" -ge 3 ]]; then
      break
    fi
  else
    idle_cycles=0
  fi

done

sleep 1
