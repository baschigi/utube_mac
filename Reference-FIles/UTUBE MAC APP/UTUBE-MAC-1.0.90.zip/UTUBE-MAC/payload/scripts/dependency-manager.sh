#!/bin/bash
# Shared checks and installation. Never run Homebrew as root.
set -euo pipefail
script_directory="$(cd "$(dirname "$0")" && pwd)"
manifest="$script_directory/dependencies.json"
mode="${1:---check}"
field(){ /usr/bin/plutil -extract "$1" raw -o - "$manifest"; }
at_least(){ /usr/bin/awk -v a="$1" -v b="$2" 'BEGIN{split(a,x,".");split(b,y,".");for(i=1;i<=4;i++){if(x[i]+0>y[i]+0)exit 0;if(x[i]+0<y[i]+0)exit 1}exit 0}'; }
[[ "$(field schema)" == 1 ]] || { echo "Unsupported dependency manifest"; exit 1; }
brew_path=""
for candidate in /opt/homebrew/bin/brew /usr/local/bin/brew; do
  [[ ! -x "$candidate" ]] || { brew_path="$candidate"; break; }
done
tool_path(){
  local command_name="$1" candidate
  for candidate in "/opt/homebrew/bin/$command_name" "/usr/local/bin/$command_name"; do
    if [[ -x "$candidate" ]]; then printf '%s\n' "$candidate"; return; fi
  done
  return 1
}
healthy(){
  local index="$1" executable output version
  executable="$(tool_path "$(field tools.$index.command)")" || return 1
  output="$("$executable" "$(field tools.$index.flag)" 2>&1)" || return 1
  version="$(printf '%s\n' "$output" | /usr/bin/sed -nE 's/^[^0-9]*([0-9]+(\.[0-9]+)+).*/\1/p' | /usr/bin/head -1)"
  [[ -n "$version" ]] && at_least "$version" "$(field tools.$index.minimum)"
}
if [[ "$mode" == "--check" ]]; then
  index=0
  while field "tools.$index.id" >/dev/null 2>&1; do
    status=missing; healthy "$index" && status=ready
    printf '%s\t%s\t%s\t%s\n' "$(field tools.$index.id)" "$status" "$(field tools.$index.required)" "$(field tools.$index.purpose)"
    index=$((index+1))
  done
  exit 0
fi
[[ "$mode" == "--install" ]] || { echo "Use --check or --install [tool IDs]"; exit 2; }
shift
[[ "$EUID" != 0 ]] || { echo "Run this as your normal user, not root."; exit 1; }
selected=("$@")
for requested in "$@"; do
  valid=false; index=0
  while id="$(field "tools.$index.id" 2>/dev/null)"; do
    [[ "$requested" != "$id" ]] || valid=true
    index=$((index+1))
  done
  [[ "$valid" == true ]] || { echo "Unknown tool ID: $requested"; exit 2; }
done
formulae=()
index=0
while field "tools.$index.id" >/dev/null 2>&1; do
  id="$(field tools.$index.id)"
  required="$(field tools.$index.required)"
  include=false
  if [[ ${#selected[@]} -eq 0 && "$required" == true ]]; then include=true; fi
  for requested in "$@"; do [[ "$requested" != "$id" ]] || include=true; done
  if [[ "$include" == true ]] && ! healthy "$index"; then
    formula="$(field tools.$index.formula)"
    [[ "$formula" =~ ^[a-z0-9@+._-]+$ ]] || exit 1
    formulae+=("$formula")
  fi
  index=$((index+1))
done
[[ ${#formulae[@]} -gt 0 ]] || { echo "Selected tools are already ready."; exit 0; }
if ! /usr/bin/xcode-select -p >/dev/null 2>&1; then
  /usr/bin/xcode-select --install || true
  echo "Finish Apple's Command Line Tools installation, then select Retry in UTUBE MAC."
  exit 3
fi
if [[ -z "$brew_path" ]]; then
  echo "Homebrew setup will request confirmation and may request your Mac password in Terminal."
  setup_directory="$(mktemp -d)"
  /usr/bin/curl --proto '=https' --tlsv1.2 -fL --retry 2 --connect-timeout 15 --max-time 180 https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh -o "$setup_directory/homebrew-install.sh"
  /bin/bash "$setup_directory/homebrew-install.sh"
  brew_path=/opt/homebrew/bin/brew
  [[ -x "$brew_path" ]] || brew_path=/usr/local/bin/brew
fi
[[ -x "$brew_path" ]] || { echo "Homebrew setup did not finish."; exit 1; }
# Install only missing/incompatible declared packages; no blanket upgrade/cleanup.
last=""
while IFS= read -r formula; do
  [[ "$formula" != "$last" ]] || continue
  last="$formula"
  if "$brew_path" list --versions "$formula" >/dev/null 2>&1; then
    HOMEBREW_NO_AUTO_UPDATE=1 "$brew_path" upgrade "$formula"
  else
    HOMEBREW_NO_AUTO_UPDATE=1 "$brew_path" install "$formula"
  fi
done < <(printf '%s\n' "${formulae[@]}" | /usr/bin/sort -u)
echo "Installation finished. Return to UTUBE MAC and select Check again."
exec /bin/bash "$0" --check
