#!/bin/bash
set -euo pipefail
directory="$(cd "$(dirname "$0")" && pwd)"
version_file="$HOME/Library/Application Support/UTUBE-MAC/Settings/General/utube-mac-version.txt"
version="$(tr -d '[:space:]' < "$version_file")"
read -r -p "Package version [$version]: " selected
version="${selected:-$version}"
python=''
for candidate in /opt/homebrew/bin/python3 /usr/local/bin/python3; do
  [[ ! -x "$candidate" ]] || { python="$candidate"; break; }
done
[[ -n "$python" ]] || { echo 'The developer package builder requires Python 3. The user installer does not.'; exit 1; }
output="${1:-$directory}/Packages/$(date +%Y%m%d-%H%M%S)"
"$python" "$directory/build_release.py" --version "$version" --output "$output"
open "$output"
