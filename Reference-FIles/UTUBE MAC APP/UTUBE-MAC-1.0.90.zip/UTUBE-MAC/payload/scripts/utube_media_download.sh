#!/bin/bash
# Last updated: 08 September 2026 · 20:20 CEST
set -euo pipefail

# A failed worker writes the failing line to its job log instead of leaving
# the dashboard with only the unhelpful word "failed".
trap 'exit_code=$?; printf "\nUTUBE-MAC Fehler: Zeile %s (Status %s)\n" "$LINENO" "$exit_code" >&2' ERR

mode="${1:-}"
url="${2:-}"
quality="${3:-best}"
subtitle_mode="${4:-none}"

# Shortcuts has no useful live console. Start the real download as a detached
# worker and open one shared, coloured Terminal dashboard. Further downloads
# reuse that window instead of opening another Terminal window.
support_directory="${UTUBE_MAC_SUPPORT_DIRECTORY:-$HOME/Library/Application Support/UTUBE-MAC}"
progress_runtime_directory="$support_directory/Runtime/Download Progress"
progress_jobs_directory="$progress_runtime_directory/Jobs"
progress_dashboard_script="$support_directory/scripts/utube_progress_dashboard.sh"
mkdir -p "$progress_jobs_directory"

if [[ "${UTUBE_MAC_DOWNLOAD_WORKER:-0}" != "1" && ( "${UTUBE_MAC_FORCE_DASHBOARD:-0}" == "1" || ! -t 1 ) ]]; then
  job_id="$(date '+%Y%m%d-%H%M%S')-$$-$RANDOM"
  job_log_file="$progress_jobs_directory/$job_id.log"

  nohup env \
    UTUBE_MAC_DOWNLOAD_WORKER=1 \
    UTUBE_MAC_JOB_ID="$job_id" \
    UTUBE_MAC_FORCE_DASHBOARD=0 \
    /bin/bash "$0" "$mode" "$url" "$quality" "$subtitle_mode" \
    > "$job_log_file" 2>&1 < /dev/null &

  dashboard_running=0
  dashboard_pid_file="$progress_runtime_directory/dashboard.pid"
  dashboard_launch_lock="$progress_runtime_directory/dashboard-launching.lock"
  if [[ -r "$dashboard_pid_file" ]]; then
    dashboard_pid="$(tr -cd '0-9' < "$dashboard_pid_file")"
    if [[ -n "$dashboard_pid" ]] && kill -0 "$dashboard_pid" 2>/dev/null; then
      dashboard_running=1
    else
      rm -f -- "$dashboard_pid_file"
    fi
  fi

  if [[ "$dashboard_running" -eq 0 ]]; then
    if [[ -d "$dashboard_launch_lock" ]]; then
      launch_lock_epoch="$(stat -f '%m' "$dashboard_launch_lock" 2>/dev/null || printf '0')"
      [[ "$launch_lock_epoch" =~ ^[0-9]+$ ]] || launch_lock_epoch=0
      if (( $(date +%s) - launch_lock_epoch > 30 )); then
        rmdir "$dashboard_launch_lock" 2>/dev/null || true
      fi
    fi

    if mkdir "$dashboard_launch_lock" 2>/dev/null; then
      if dashboard_window_id="$(osascript - "$progress_dashboard_script" <<'OPEN_PROGRESS_TERMINAL_EOF'
on run argv
  set dashboardPath to item 1 of argv
  set commandText to "clear; /bin/bash " & quoted form of dashboardPath & "; exit"
  set terminalWasRunning to application "Terminal" is running

  tell application "Terminal"
    if terminalWasRunning then
      -- Terminal is already available: create one dedicated dashboard window.
      do script commandText
    else
      -- On a cold start Terminal may create its own empty initial window and
      -- then another one for "do script". Start it first and reuse exactly
      -- that initial window for the dashboard command.
      launch
      activate
      repeat 50 times
        if (count of windows) > 0 then exit repeat
        delay 0.1
      end repeat

      if (count of windows) > 0 then
        do script commandText in front window
      else
        do script commandText
      end if
    end if
    activate
    return id of front window
  end tell
end run
OPEN_PROGRESS_TERMINAL_EOF
)"; then
        # Terminal profiles can be configured to keep a window after a clean
        # shell exit. This independent watcher closes only the dashboard window
        # once its command has ended; it never touches the user's other windows.
        if [[ "$dashboard_window_id" =~ ^[0-9]+$ ]]; then
          nohup osascript - "$dashboard_window_id" > /dev/null 2>&1 <<'CLOSE_PROGRESS_TERMINAL_EOF' &
on run argv
  set targetWindowID to (item 1 of argv) as integer
  delay 2

  repeat 43200 times
    tell application "Terminal"
      if not (exists window id targetWindowID) then return
      if not busy of selected tab of window id targetWindowID then
        close window id targetWindowID
        return
      end if
    end tell
    delay 1
  end repeat
end run
CLOSE_PROGRESS_TERMINAL_EOF
        fi
      else
        rmdir "$dashboard_launch_lock" 2>/dev/null || true
        printf '%s\n' "Hinweis: Der gemeinsame Fortschrittsmonitor konnte nicht geöffnet werden." >&2
      fi
    fi
  fi
  exit 0
fi

# New simple actions can use auto-mp4, auto-mkv, auto-mp3, or
# auto-mp3-advanced. A normal playlist link becomes a playlist download;
# YouTube's generated radio playlists (list=RD...) stay single downloads.
case "$mode" in
  auto-mp4|auto-mkv|auto-mp3|auto-mp3-advanced)
    media_kind="${mode#auto-}"
    if [[ "$url" =~ [\?\&]list=([^\&]+) ]] && [[ "${BASH_REMATCH[1]}" != RD* ]]; then
      mode="playlist-$media_kind"
    else
      mode="single-$media_kind"
    fi
    ;;
esac

# Older Shortcut buttons use "video" and "mp3". Give them the same smart
# link detection, so a normal video checks Single and a real playlist checks
# Playlists.
case "$mode" in
  video|mp3)
    media_kind="${mode/video/mp4}"
    media_kind="${media_kind/mp3/mp3}"
    if [[ "$url" =~ [\?\&]list=([^\&]+) ]] && [[ "${BASH_REMATCH[1]}" != RD* ]]; then
      mode="playlist-$media_kind"
    else
      mode="single-$media_kind"
    fi
    ;;
esac

archive_directory="$support_directory/History/Download History"
beets_config_file="$support_directory/Settings/Beets/beets.yaml"
version_file="$support_directory/Settings/General/utube-mac-version.txt"
readable_download_history="$archive_directory/DOWNLOAD-HISTORY.txt"
download_history_index="$archive_directory/DOWNLOAD-HISTORY-INDEX.txt"
audio_destination_file="$support_directory/Settings/General/audio_destination.txt"
apple_music_directory="$HOME/Music/Music/Media.localized/Automatically Add to Music.localized"
completed_files_manifest="$support_directory/Temp/completed-files-$$.txt"
new_completed_files_manifest="$support_directory/Temp/new-completed-files-$$.txt"
expected_output_stems_manifest="$support_directory/Temp/expected-output-stems-$$.txt"
playlist_metadata_manifest="$support_directory/Temp/playlist-metadata-$$.txt"
media_details_file="$support_directory/Temp/media-details-$$.txt"
single_popup_summary_file="$support_directory/Temp/single-popup-summary-$$.txt"
current_probe_json_file="$support_directory/Temp/ffprobe-$$.json"
yt_dlp_error_file="$support_directory/Temp/yt-dlp-error-$$.txt"
history_lock_directory="$archive_directory/.download-history.lock"
history_lock_held=0

progress_tracking=0
progress_finalized=0
progress_cancelled=0
progress_job_id=""
progress_status_file=""
progress_active_file=""
progress_done_file=""
progress_log_file=""
progress_items_directory=""
if [[ "${UTUBE_MAC_DOWNLOAD_WORKER:-0}" == "1" ]]; then
  progress_tracking=1
  progress_job_id="${UTUBE_MAC_JOB_ID:-$(date '+%Y%m%d-%H%M%S')-$$-$RANDOM}"
  if [[ ! "$progress_job_id" =~ ^[A-Za-z0-9._-]+$ ]]; then
    progress_job_id="$(date '+%Y%m%d-%H%M%S')-$$-$RANDOM"
  fi
  progress_status_file="$progress_jobs_directory/$progress_job_id.status"
  progress_active_file="$progress_jobs_directory/$progress_job_id.active"
  progress_done_file="$progress_jobs_directory/$progress_job_id.done"
  progress_log_file="$progress_jobs_directory/$progress_job_id.log"
  progress_items_directory="$progress_jobs_directory/$progress_job_id.items"
fi

clean_progress_value() {
  printf '%s' "$1" | tr '\r\n' '  '
}

acquire_download_history_lock() {
  local attempt=0
  local holder_pid=""
  local lock_modified_epoch=0
  local lock_age=0

  mkdir -p "$archive_directory"
  while ! mkdir "$history_lock_directory" 2>/dev/null; do
    holder_pid="$(tr -cd '0-9' < "$history_lock_directory/pid" 2>/dev/null || true)"
    lock_modified_epoch="$(stat -f '%m' "$history_lock_directory" 2>/dev/null || printf '0')"
    [[ "$lock_modified_epoch" =~ ^[0-9]+$ ]] || lock_modified_epoch=0
    lock_age=$(( $(date +%s) - lock_modified_epoch ))

    # Recover a lock left behind by a crashed worker. A brand-new lock without
    # its PID is left alone briefly so two simultaneous jobs cannot race.
    if [[ -n "$holder_pid" ]] && ! kill -0 "$holder_pid" 2>/dev/null; then
      rm -f -- "$history_lock_directory/pid" 2>/dev/null || true
      rmdir "$history_lock_directory" 2>/dev/null || true
      continue
    elif [[ -z "$holder_pid" && "$lock_age" -gt 5 ]] || [[ "$lock_age" -gt 300 ]]; then
      rm -f -- "$history_lock_directory/pid" 2>/dev/null || true
      rmdir "$history_lock_directory" 2>/dev/null || true
      continue
    fi

    attempt=$((attempt + 1))
    [[ "$attempt" -lt 600 ]] || return 1
    sleep 0.1
  done

  printf '%s\n' "$$" > "$history_lock_directory/pid"
  history_lock_held=1
  return 0
}

release_download_history_lock() {
  [[ "$history_lock_held" -eq 1 ]] || return 0
  rm -f -- "$history_lock_directory/pid" 2>/dev/null || true
  rmdir "$history_lock_directory" 2>/dev/null || true
  history_lock_held=0
}

write_progress_status() {
  local phase="$1"
  local percent="$2"
  local speed="$3"
  local eta="$4"
  local result="$5"
  local title="${6:-Download}"
  local temporary_status_file

  [[ "$progress_tracking" -eq 1 ]] || return 0
  temporary_status_file="$progress_status_file.tmp.$$"
  {
    printf 'PID=%s\n' "$$"
    printf 'TITLE=%s\n' "$(clean_progress_value "$title")"
    printf 'MODE=%s\n' "$(clean_progress_value "$mode")"
    printf 'PHASE=%s\n' "$(clean_progress_value "$phase")"
    printf 'PERCENT=%s\n' "$(clean_progress_value "$percent")"
    printf 'SPEED=%s\n' "$(clean_progress_value "$speed")"
    printf 'ETA=%s\n' "$(clean_progress_value "$eta")"
    printf 'RESULT=%s\n' "$(clean_progress_value "$result")"
  } > "$temporary_status_file"
  mv -f -- "$temporary_status_file" "$progress_status_file"
}

write_playlist_item_status() {
  local item_index="$1"
  local item_total="$2"
  local media_id="$3"
  local item_title="$4"
  local item_phase="$5"
  local item_percent="$6"
  local item_speed="$7"
  local item_eta="$8"
  local item_result="$9"
  local padded_index
  local item_status_file
  local temporary_item_status_file

  [[ "$progress_tracking" -eq 1 ]] || return 0
  case "$mode" in playlist-*) ;; *) return 0 ;; esac
  [[ "$item_index" =~ ^[0-9]+$ ]] || return 0
  [[ "$item_total" =~ ^[0-9]+$ ]] || item_total=0
  # Treat leading-zero playlist positions such as 08 and 09 as decimal.
  # Bash otherwise interprets them as invalid octal values under set -e.
  printf -v padded_index '%06d' "$((10#$item_index))"
  item_status_file="$progress_items_directory/item-$padded_index.status"
  temporary_item_status_file="$item_status_file.tmp.$$"
  mkdir -p "$progress_items_directory"
  {
    printf 'INDEX=%s\n' "$item_index"
    printf 'TOTAL=%s\n' "$item_total"
    printf 'ID=%s\n' "$(clean_progress_value "$media_id")"
    printf 'TITLE=%s\n' "$(clean_progress_value "$item_title")"
    printf 'PHASE=%s\n' "$(clean_progress_value "$item_phase")"
    printf 'PERCENT=%s\n' "$(clean_progress_value "$item_percent")"
    printf 'SPEED=%s\n' "$(clean_progress_value "$item_speed")"
    printf 'ETA=%s\n' "$(clean_progress_value "$item_eta")"
    printf 'RESULT=%s\n' "$(clean_progress_value "$item_result")"
  } > "$temporary_item_status_file"
  mv -f -- "$temporary_item_status_file" "$item_status_file"
}

finalize_playlist_items() {
  local final_result="$1"
  local item_status_file
  local item_index
  local item_total
  local media_id
  local item_title
  local item_phase
  local item_percent
  local item_speed
  local item_eta
  local item_result

  [[ -d "$progress_items_directory" ]] || return 0
  for item_status_file in "$progress_items_directory"/item-*.status; do
    [[ -f "$item_status_file" ]] || continue
    item_index="0"; item_total="0"; media_id=""; item_title="Titel"
    item_phase="Wartet"; item_percent="0"; item_speed="—"; item_eta="—"; item_result="queued"
    while IFS='=' read -r item_key item_value; do
      case "$item_key" in
        INDEX) item_index="$item_value" ;;
        TOTAL) item_total="$item_value" ;;
        ID) media_id="$item_value" ;;
        TITLE) item_title="$item_value" ;;
        PHASE) item_phase="$item_value" ;;
        PERCENT) item_percent="$item_value" ;;
        SPEED) item_speed="$item_value" ;;
        ETA) item_eta="$item_value" ;;
        RESULT) item_result="$item_value" ;;
      esac
    done < "$item_status_file"

    if [[ "$final_result" == "completed" ]]; then
      case "$item_result" in
        queued)
          item_result="skipped"; item_phase="Bereits vorhanden / übersprungen"
          ;;
        active)
          item_result="completed"; item_phase="Abgeschlossen"; item_percent="100"
          ;;
      esac
    elif [[ "$item_result" == "active" ]]; then
      item_result="failed"; item_phase="Nicht abgeschlossen"
    fi
    write_playlist_item_status "$item_index" "$item_total" "$media_id" "$item_title" \
      "$item_phase" "$item_percent" "$item_speed" "$item_eta" "$item_result"
  done
}

finalize_progress_job() {
  local result="$1"
  local phase="$2"
  local last_title="Download"
  local last_percent="0"

  [[ "$progress_tracking" -eq 1 ]] || return 0
  [[ "$progress_finalized" -eq 0 ]] || return 0
  if [[ -r "$progress_status_file" ]]; then
    last_title="$(sed -n 's/^TITLE=//p' "$progress_status_file" | head -n 1)"
    last_percent="$(sed -n 's/^PERCENT=//p' "$progress_status_file" | head -n 1)"
  fi
  [[ -n "$last_title" ]] || last_title="Download"
  [[ -n "$last_percent" ]] || last_percent="0"
  [[ "$result" == "completed" ]] && last_percent="100"
  finalize_playlist_items "$result"
  write_progress_status "$phase" "$last_percent" "—" "—" "$result" "$last_title"
  rm -f -- "$progress_active_file"
  : > "$progress_done_file"
  progress_finalized=1
}

current_script_version="$(tr -d '[:space:]' < "$version_file" 2>/dev/null || true)"
if [[ ! "$current_script_version" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
  current_script_version="unknown"
fi

export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"

audio_destination="$(tr -d '[:space:]' < "$audio_destination_file" 2>/dev/null || true)"
if [[ "$audio_destination" != "apple_music" ]]; then
  audio_destination="downloads"
fi

mkdir -p "$support_directory/Temp"
: > "$completed_files_manifest"
: > "$new_completed_files_manifest"
: > "$expected_output_stems_manifest"
: > "$playlist_metadata_manifest"
: > "$media_details_file"
: > "$single_popup_summary_file"
: > "$yt_dlp_error_file"
if [[ "$progress_tracking" -eq 1 ]]; then
  : > "$progress_active_file"
  rm -f -- "$progress_done_file"
  mkdir -p "$progress_items_directory"
  write_progress_status "Vorbereitung" "0" "—" "—" "active" "Download wird vorbereitet"
fi
cleanup_completed_files_manifest() {
  local exit_code="$?"

  release_download_history_lock

  if [[ "$progress_tracking" -eq 1 && "$progress_finalized" -eq 0 ]]; then
    if [[ "$progress_cancelled" -eq 1 ]]; then
      finalize_progress_job "cancelled" "Vom Nutzer abgebrochen"
    elif [[ "$exit_code" -eq 0 ]]; then
      finalize_progress_job "completed" "Beendet"
    else
      finalize_progress_job "failed" "Fehler – Details im Protokoll"
    fi
  fi
  rm -f -- \
    "$completed_files_manifest" \
    "$new_completed_files_manifest" \
    "$expected_output_stems_manifest" \
    "$playlist_metadata_manifest" \
    "$media_details_file" \
    "$single_popup_summary_file" \
    "$current_probe_json_file" \
    "$yt_dlp_error_file"
}
trap cleanup_completed_files_manifest EXIT

# The dashboard can stop its current background worker.  Handle the signal
# here so the UI gets a truthful "abgebrochen" state rather than "failed".
cancel_download() {
  progress_cancelled=1
  exit 130
}
trap cancel_download INT TERM

# ▼ READ THE FOLDER SELECTED DURING SETUP ▼
downloads_location_file="$support_directory/Settings/General/downloads_directory.txt"

if [[ -r "$downloads_location_file" ]]; then
  downloads_directory="$(<"$downloads_location_file")"
else
  downloads_directory="$HOME/Downloads/UTUBE-MAC"
fi

case "$downloads_directory" in
  '$HOME/'*) downloads_directory="$HOME/${downloads_directory#\$HOME/}" ;;
  '${HOME}/'*) downloads_directory="$HOME/${downloads_directory#\$\{HOME\}/}" ;;
  '~/'*) downloads_directory="$HOME/${downloads_directory#\~/}" ;;
esac
if [[ ! -d "$downloads_directory" ]]; then
  printf 'UTUBE_DESTINATION_MISSING: Download-Ordner nicht gefunden: %s. Bitte unter Einstellungen → Mediathek einen vorhandenen Ordner auswählen.\n' "$downloads_directory" >&2
  exit 72
fi
if [[ ! -w "$downloads_directory" || ! -x "$downloads_directory" ]]; then
  printf 'UTUBE_DESTINATION_DENIED: Kein Schreibzugriff auf den Download-Ordner: %s. Bitte unter Einstellungen → Mediathek einen zugänglichen Ordner auswählen.\n' "$downloads_directory" >&2
  exit 73
fi
mp4_single_directory="$downloads_directory/MP4/Single"
mp4_playlists_directory="$downloads_directory/MP4/Playlists"

mkv_single_directory="$downloads_directory/MKV/Single"
mkv_playlists_directory="$downloads_directory/MKV/Playlists"

mp3_single_directory="$downloads_directory/MP3/Single"
mp3_playlists_directory="$downloads_directory/MP3/Playlists"

mp3_advanced_single_directory="$downloads_directory/MP3/Advanced/Single"
mp3_advanced_playlists_directory="$downloads_directory/MP3/Advanced/Playlists"

mp4_archive="$archive_directory/downloaded_mp4s.txt"
mkv_archive="$archive_directory/downloaded_mkvs.txt"
mp3_archive="$archive_directory/downloaded_mp3s.txt"
mp3_advanced_archive="$archive_directory/downloaded_advanced_mp3s.txt"

mkdir -p \
  "$archive_directory" \
  "$mp4_single_directory" \
  "$mp4_playlists_directory" \
  "$mkv_single_directory" \
  "$mkv_playlists_directory" \
  "$mp3_single_directory" \
  "$mp3_playlists_directory" \
  "$mp3_advanced_single_directory" \
  "$mp3_advanced_playlists_directory"

if [[ -z "$url" || ! "$url" =~ ^https?://([^/]+\.)?(youtube\.com|youtu\.be)/ ]]; then
  printf 'Bitte zuerst einen gültigen YouTube-Link kopieren.\n'
  exit 64
fi

format_for_quality() {
  case "$quality" in
    fast) printf '%s\n' "bv*[height<=1080][ext=mp4]+ba[ext=m4a]/b[ext=mp4]/b" ;;
    best) printf '%s\n' "bv*+ba/b" ;;
    2160) printf '%s\n' "bv*[height<=2160]+ba/b" ;;
    1080) printf '%s\n' "bv*[height<=1080]+ba/b" ;;
    720)  printf '%s\n' "bv*[height<=720]+ba/b" ;;
    480)  printf '%s\n' "bv*[height<=480]+ba/b" ;;
    *)
      printf 'Ungültige Videoqualität: %s\n' "$quality"
      exit 64
      ;;
  esac
}

subtitle_arguments=(--no-write-subs)

case "$subtitle_mode" in
  none)
    ;;
  de)
    subtitle_arguments=(--write-subs --write-auto-subs --sub-langs "de.*" --sub-format "srt" --embed-subs)
    ;;
  en)
    subtitle_arguments=(--write-subs --write-auto-subs --sub-langs "en.*" --sub-format "srt" --embed-subs)
    ;;
  all)
    subtitle_arguments=(--write-subs --write-auto-subs --sub-langs all --sub-format "srt" --embed-subs)
    ;;
  *)
    printf 'Ungültige Untertitelwahl: %s\n' "$subtitle_mode"
    exit 64
    ;;
esac

# ▼ CHOOSE THE DESTINATION BEFORE CHECKING FOR A REAL EXISTING FILE ▼
case "$mode" in
  single-mp4|single-video|playlist-mp4|video)
    active_archive="$mp4_archive"
    output_template="$mp4_single_directory/%(title)s.%(ext)s"
    [[ "$mode" == playlist-* || "$mode" == video ]] && output_template="$mp4_playlists_directory/%(playlist_title)s/%(playlist_index)03d - %(title)s.%(ext)s"
    ;;
  single-mkv|playlist-mkv)
    active_archive="$mkv_archive"
    output_template="$mkv_single_directory/%(title)s.%(ext)s"
    [[ "$mode" == playlist-* ]] && output_template="$mkv_playlists_directory/%(playlist_title)s/%(playlist_index)03d - %(title)s.%(ext)s"
    ;;
  single-mp3|playlist-mp3|mp3)
    active_archive="$mp3_archive"
    output_template="$mp3_single_directory/%(title)s.%(ext)s"
    [[ "$mode" == playlist-* || "$mode" == mp3 ]] && output_template="$mp3_playlists_directory/%(playlist_title)s/%(playlist_index)03d - %(title)s.%(ext)s"
    ;;
  single-mp3-advanced|playlist-mp3-advanced)
    active_archive="$mp3_advanced_archive"
    output_template="$mp3_advanced_single_directory/%(title)s.%(ext)s"
    [[ "$mode" == playlist-* ]] && output_template="$mp3_advanced_playlists_directory/%(playlist_title)s/%(playlist_index)03d - %(title)s.%(ext)s"
    ;;
  *)
    printf 'Ungültiger Modus: %s\n' "$mode"
    exit 64
    ;;
esac

probe_format_value() {
  local media_file="$1"
  local field="$2"

  if [[ -s "$current_probe_json_file" ]] && command -v jq >/dev/null 2>&1; then
    jq -r --arg field "$field" '.format[$field] // empty' "$current_probe_json_file" 2>/dev/null || true
    return 0
  fi

  ffprobe -v error \
    -show_entries "format=$field" \
    -of default=noprint_wrappers=1:nokey=1 \
    "$media_file" 2>/dev/null | head -n 1 | tr -d '\r' || true
}

probe_stream_value() {
  local media_file="$1"
  local stream_selector="$2"
  local field="$3"
  local stream_type=""

  case "$stream_selector" in
    v*) stream_type="video" ;;
    a*) stream_type="audio" ;;
    s*) stream_type="subtitle" ;;
  esac

  if [[ -n "$stream_type" && -s "$current_probe_json_file" ]] && command -v jq >/dev/null 2>&1; then
    jq -r --arg type "$stream_type" --arg field "$field" \
      '[.streams[] | select(.codec_type == $type)][0][$field] // empty' \
      "$current_probe_json_file" 2>/dev/null || true
    return 0
  fi

  ffprobe -v error \
    -select_streams "$stream_selector" \
    -show_entries "stream=$field" \
    -of default=noprint_wrappers=1:nokey=1 \
    "$media_file" 2>/dev/null | head -n 1 | tr -d '\r' || true
}

probe_tag_value() {
  local media_file="$1"
  local field="$2"

  if [[ -s "$current_probe_json_file" ]] && command -v jq >/dev/null 2>&1; then
    jq -r --arg field "$field" '
      [(.format.tags // {}) | to_entries[] | select((.key | ascii_downcase) == ($field | ascii_downcase)) | .value][0] // empty
    ' "$current_probe_json_file" 2>/dev/null || true
    return 0
  fi

  ffprobe -v error \
    -show_entries "format_tags=$field" \
    -of default=noprint_wrappers=1:nokey=1 \
    "$media_file" 2>/dev/null | head -n 1 | tr -d '\r' || true
}

human_file_size() {
  awk -v bytes="${1:-0}" 'BEGIN {
    split("B KB MB GB TB", units, " ")
    unit = 1
    while (bytes >= 1024 && unit < 5) {
      bytes /= 1024
      unit++
    }
    if (unit == 1) printf "%d %s", bytes, units[unit]
    else printf "%.1f %s", bytes, units[unit]
  }'
}

human_duration() {
  awk -v seconds="${1:-0}" 'BEGIN {
    if (seconds == "" || seconds == "N/A") seconds = 0
    total = int(seconds + 0.5)
    hours = int(total / 3600)
    minutes = int((total % 3600) / 60)
    remaining = total % 60
    if (hours > 0) printf "%d:%02d:%02d", hours, minutes, remaining
    else printf "%d:%02d", minutes, remaining
  }'
}

human_bitrate() {
  awk -v bits="${1:-0}" 'BEGIN {
    if (bits == "" || bits == "N/A" || bits + 0 <= 0) printf "Unbekannt"
    else printf "%.0f kbit/s", bits / 1000
  }'
}

human_sample_rate() {
  awk -v hz="${1:-0}" 'BEGIN {
    if (hz == "" || hz == "N/A" || hz + 0 <= 0) printf "Unbekannt"
    else printf "%.1f kHz", hz / 1000
  }'
}

human_frame_rate() {
  awk -v rate="${1:-0}" 'BEGIN {
    split(rate, parts, "/")
    if (parts[1] + 0 <= 0) printf "Unbekannt"
    else if (parts[2] + 0 > 0) printf "%.2f fps", parts[1] / parts[2]
    else printf "%.2f fps", parts[1]
  }'
}

human_channels() {
  case "${1:-0}" in
    1) printf '%s' "Mono" ;;
    2) printf '%s' "Stereo" ;;
    ""|0|N/A) printf '%s' "Unbekannt" ;;
    *) printf '%s Kanäle' "$1" ;;
  esac
}

rotate_readable_download_history_if_needed() {
  local entry_count=0
  local sequence=1
  local sequence_label
  local archived_history
  local first_date="Unbekannt"
  local last_date="Unbekannt"

  [[ -f "$readable_download_history" ]] || return 0
  entry_count="$(grep -c '^Date:' "$readable_download_history" 2>/dev/null || true)"
  [[ "$entry_count" =~ ^[0-9]+$ ]] || entry_count=0
  [[ "$entry_count" -ge 1000 ]] || return 0

  while :; do
    printf -v sequence_label '%03d' "$sequence"
    archived_history="$archive_directory/DOWNLOAD-HISTORY-$sequence_label.txt"
    [[ -e "$archived_history" ]] || break
    sequence=$((sequence + 1))
  done

  first_date="$(awk -F': ' '/^Date:/{print substr($0, 7); exit}' "$readable_download_history" 2>/dev/null || true)"
  last_date="$(awk -F': ' '/^Date:/{latest=substr($0, 7)} END{print latest}' "$readable_download_history" 2>/dev/null || true)"
  [[ -n "$first_date" ]] || first_date="Unbekannt"
  [[ -n "$last_date" ]] || last_date="Unbekannt"

  mv -- "$readable_download_history" "$archived_history"
  {
    printf '%s\n' "$(basename "$archived_history")"
    printf '  Einträge: %s\n' "$entry_count"
    printf '  Zeitraum: %s bis %s\n' "$first_date" "$last_date"
    printf '  Archiviert: %s\n\n' "$(date '+%Y-%m-%d %H:%M:%S %Z')"
  } >> "$download_history_index"
}

completed_files_count=0
completed_files_total_bytes=0
completed_files_total_seconds=0
primary_completed_file=""
playlist_successful=0
playlist_skipped=0
playlist_failed=0
completion_summary=""

analyse_completed_media() {
  local completed_file
  local file_modified_epoch
  local minimum_modified_epoch=$((download_started_epoch - 5))
  local file_name
  local file_extension
  local file_size_bytes
  local file_size_text
  local duration_seconds
  local duration_text
  local title_tag
  local artist_tag
  local album_tag
  local format_name
  local video_codec
  local video_bitrate
  local width
  local height
  local frame_rate
  local aspect_ratio
  local color_transfer
  local hdr_status
  local audio_codec
  local audio_bitrate
  local sample_rate
  local bit_depth
  local channels
  local subtitle_languages
  local attached_picture
  local metadata_status
  local cover_status
  local audio_only

  : > "$new_completed_files_manifest"
  : > "$media_details_file"
  : > "$single_popup_summary_file"

  while IFS= read -r completed_file; do
    [[ -f "$completed_file" ]] || continue
    grep -Fqx -- "$completed_file" "$new_completed_files_manifest" 2>/dev/null && continue

    # Only include files created or updated by this run. An older file that
    # yt-dlp merely skipped must not be reported as a new successful download.
    file_modified_epoch="$(stat -f '%m' "$completed_file" 2>/dev/null || printf '0')"
    [[ "$file_modified_epoch" =~ ^[0-9]+$ ]] || file_modified_epoch=0
    if [[ "$file_modified_epoch" -lt "$minimum_modified_epoch" ]]; then
      continue
    fi

    printf '%s\n' "$completed_file" >> "$new_completed_files_manifest"
    completed_files_count=$((completed_files_count + 1))
    [[ -n "$primary_completed_file" ]] || primary_completed_file="$completed_file"

    file_name="$(basename "$completed_file")"

    # One ffprobe run supplies all properties for this file. Reusing its JSON
    # output is much faster than starting ffprobe once for every property.
    : > "$current_probe_json_file"
    ffprobe -v error -show_format -show_streams -of json "$completed_file" > "$current_probe_json_file" 2>/dev/null || true

    file_extension="${file_name##*.}"
    file_extension="$(printf '%s' "$file_extension" | tr '[:lower:]' '[:upper:]')"
    audio_only=0
    case "$file_extension" in
      MP3|M4A|AAC|FLAC|OGG|OPUS|WAV|AIFF) audio_only=1 ;;
    esac
    file_size_bytes="$(stat -f '%z' "$completed_file" 2>/dev/null || printf '0')"
    [[ "$file_size_bytes" =~ ^[0-9]+$ ]] || file_size_bytes=0
    file_size_text="$(human_file_size "$file_size_bytes")"
    completed_files_total_bytes=$((completed_files_total_bytes + file_size_bytes))

    duration_seconds="$(probe_format_value "$completed_file" duration)"
    duration_text="$(human_duration "$duration_seconds")"
    completed_files_total_seconds=$((completed_files_total_seconds + $(awk -v value="${duration_seconds:-0}" 'BEGIN {printf "%d", value + 0.5}')))

    title_tag="$(probe_tag_value "$completed_file" title)"
    artist_tag="$(probe_tag_value "$completed_file" artist)"
    album_tag="$(probe_tag_value "$completed_file" album)"
    [[ -n "$title_tag" ]] || title_tag="${file_name%.*}"
    [[ -n "$artist_tag" ]] || artist_tag="Unbekannt"
    [[ -n "$album_tag" ]] || album_tag="Unbekannt"

    format_name="$(probe_format_value "$completed_file" format_name)"
    video_codec="$(probe_stream_value "$completed_file" 'v:0' codec_name)"
    audio_codec="$(probe_stream_value "$completed_file" 'a:0' codec_name)"
    audio_bitrate="$(probe_stream_value "$completed_file" 'a:0' bit_rate)"
    sample_rate="$(probe_stream_value "$completed_file" 'a:0' sample_rate)"
    bit_depth="$(probe_stream_value "$completed_file" 'a:0' bits_per_raw_sample)"
    [[ -n "$bit_depth" && "$bit_depth" != "0" && "$bit_depth" != "N/A" ]] || bit_depth="$(probe_stream_value "$completed_file" 'a:0' bits_per_sample)"
    [[ -n "$bit_depth" && "$bit_depth" != "0" && "$bit_depth" != "N/A" ]] || bit_depth="Unbekannt"
    channels="$(probe_stream_value "$completed_file" 'a:0' channels)"

    if [[ "$audio_only" -eq 0 && -n "$video_codec" ]]; then
      width="$(probe_stream_value "$completed_file" 'v:0' width)"
      height="$(probe_stream_value "$completed_file" 'v:0' height)"
      frame_rate="$(probe_stream_value "$completed_file" 'v:0' r_frame_rate)"
      aspect_ratio="$(probe_stream_value "$completed_file" 'v:0' display_aspect_ratio)"
      video_bitrate="$(probe_stream_value "$completed_file" 'v:0' bit_rate)"
      color_transfer="$(probe_stream_value "$completed_file" 'v:0' color_transfer)"
      if [[ -s "$current_probe_json_file" ]] && command -v jq >/dev/null 2>&1; then
        subtitle_languages="$(jq -r '[.streams[] | select(.codec_type == "subtitle") | .tags.language // empty] | unique | join(", ")' "$current_probe_json_file" 2>/dev/null || true)"
      else
        subtitle_languages="$(ffprobe -v error -select_streams s -show_entries stream_tags=language -of default=noprint_wrappers=1:nokey=1 "$completed_file" 2>/dev/null | awk 'NF && !seen[$0]++' | paste -sd ', ' - || true)"
      fi
      [[ -n "$aspect_ratio" && "$aspect_ratio" != "N/A" ]] || aspect_ratio="Unbekannt"
      [[ -n "$subtitle_languages" ]] || subtitle_languages="Keine"
      case "$color_transfer" in
        smpte2084|arib-std-b67) hdr_status="HDR" ;;
        ""|N/A|unknown) hdr_status="Unbekannt" ;;
        *) hdr_status="SDR" ;;
      esac

      {
        printf '\n%s\n' "MEDIA FILE $completed_files_count"
        printf '  File: %s\n' "$completed_file"
        printf '  Title: %s\n' "$title_tag"
        printf '  Type: Video\n'
        printf '  Container: %s (%s)\n' "$file_extension" "${format_name:-Unbekannt}"
        printf '  File size: %s (%s bytes)\n' "$file_size_text" "$file_size_bytes"
        printf '  Duration: %s\n' "$duration_text"
        printf '  Resolution: %sx%s\n' "${width:-Unbekannt}" "${height:-Unbekannt}"
        printf '  Frame rate: %s\n' "$(human_frame_rate "$frame_rate")"
        printf '  Aspect ratio: %s\n' "$aspect_ratio"
        printf '  Video codec: %s\n' "${video_codec:-Unbekannt}"
        printf '  Video bitrate: %s\n' "$(human_bitrate "$video_bitrate")"
        printf '  Dynamic range: %s\n' "$hdr_status"
        printf '  Audio codec: %s\n' "${audio_codec:-Unbekannt}"
        printf '  Audio bitrate: %s\n' "$(human_bitrate "$audio_bitrate")"
        printf '  Audio channels: %s\n' "$(human_channels "$channels")"
        printf '  Subtitles: %s\n' "$subtitle_languages"
      } >> "$media_details_file"

      if [[ "$completed_files_count" -eq 1 ]]; then
        {
          printf '🎬 %s\n\n' "$title_tag"
          printf 'Format: %s · %s\n' "$file_extension" "$file_size_text"
          printf 'Bild: %sx%s · %s · %s\n' "${width:-?}" "${height:-?}" "$(human_frame_rate "$frame_rate")" "${video_codec:-Unbekannt}"
          printf 'Audio: %s · %s · %s\n' "${audio_codec:-Unbekannt}" "$(human_bitrate "$audio_bitrate")" "$(human_channels "$channels")"
          printf 'Dauer: %s\n' "$duration_text"
          printf 'Untertitel: %s' "$subtitle_languages"
        } > "$single_popup_summary_file"
      fi
    else
      [[ -n "$audio_bitrate" && "$audio_bitrate" != "N/A" ]] || audio_bitrate="$(probe_format_value "$completed_file" bit_rate)"
      if [[ -s "$current_probe_json_file" ]] && command -v jq >/dev/null 2>&1; then
        attached_picture="$(jq -r '[.streams[] | select(.codec_type == "video")][0].disposition.attached_pic // 0' "$current_probe_json_file" 2>/dev/null || true)"
      else
        attached_picture="$(ffprobe -v error -select_streams v -show_entries stream_disposition=attached_pic -of default=noprint_wrappers=1:nokey=1 "$completed_file" 2>/dev/null | head -n 1 || true)"
      fi
      if [[ "$attached_picture" == "1" ]]; then cover_status="Vorhanden"; else cover_status="Nicht erkannt"; fi
      if [[ "$artist_tag" != "Unbekannt" || "$album_tag" != "Unbekannt" ]]; then metadata_status="Vorhanden"; else metadata_status="Nur Grunddaten"; fi

      {
        printf '\n%s\n' "MEDIA FILE $completed_files_count"
        printf '  File: %s\n' "$completed_file"
        printf '  Title: %s\n' "$title_tag"
        printf '  Artist: %s\n' "$artist_tag"
        printf '  Album: %s\n' "$album_tag"
        printf '  Type: Audio\n'
        printf '  Format: %s (%s)\n' "$file_extension" "${format_name:-Unbekannt}"
        printf '  File size: %s (%s bytes)\n' "$file_size_text" "$file_size_bytes"
        printf '  Duration: %s\n' "$duration_text"
        printf '  Audio codec: %s\n' "${audio_codec:-Unbekannt}"
        printf '  Bitrate: %s\n' "$(human_bitrate "$audio_bitrate")"
        printf '  Sample rate: %s\n' "$(human_sample_rate "$sample_rate")"
        printf '  Bit depth: %s\n' "$bit_depth"
        printf '  Channels: %s\n' "$(human_channels "$channels")"
        printf '  Metadata: %s\n' "$metadata_status"
        printf '  Cover: %s\n' "$cover_status"
      } >> "$media_details_file"

      if [[ "$completed_files_count" -eq 1 ]]; then
        {
          printf '🎵 %s\n' "$title_tag"
          printf 'Interpret: %s\n' "$artist_tag"
          printf 'Album: %s\n\n' "$album_tag"
          printf 'Format: %s · %s\n' "$file_extension" "$file_size_text"
          printf 'Audio: %s · %s · %s\n' "${audio_codec:-Unbekannt}" "$(human_bitrate "$audio_bitrate")" "$(human_channels "$channels")"
          printf 'Abtastrate: %s\n' "$(human_sample_rate "$sample_rate")"
          printf 'Dauer: %s\n' "$duration_text"
          printf 'Metadaten: %s · Cover: %s' "$metadata_status" "$cover_status"
        } > "$single_popup_summary_file"
      fi
    fi
  done < "$completed_files_manifest"
}

record_readable_download_history() {
  local result="$1"

  if ! acquire_download_history_lock; then
    printf '%s\n' "Hinweis: Der Downloadverlauf war länger als 60 Sekunden durch einen anderen Download belegt." >&2
    printf '%s\n' "Die Mediendatei bleibt sicher gespeichert und wird beim nächsten Einrichten automatisch nachgetragen." >&2
    return 0
  fi

  rotate_readable_download_history_if_needed

  {
    printf '%s\n' "------------------------------------------------------------"
    printf 'Date: %s\n' "$(date '+%Y-%m-%d %H:%M:%S %Z')"
    printf 'UTUBE MAC version: %s\n' "$current_script_version"
    printf 'Result: %s\n' "$result"
    printf 'Mode: %s\n' "$mode"
    printf 'Title: %s\n' "$job_name"
    printf 'URL: %s\n' "$url"
    printf 'Quality: %s\n' "$quality"
    printf 'Subtitles: %s\n' "$subtitle_mode"
    printf 'Destination: %s\n' "$folder_to_open"
    printf 'Duplicate database: %s\n' "$(basename "$active_archive")"
    printf 'Completed media files in this run: %s\n' "$completed_files_count"
    case "$mode" in
      playlist-*)
        printf 'Playlist expected items: %s\n' "$expected_total"
        printf 'Playlist successful items: %s\n' "$playlist_successful"
        printf 'Playlist skipped items: %s\n' "$playlist_skipped"
        printf 'Playlist failed or unfinished items: %s\n' "$playlist_failed"
        printf 'New media total size: %s\n' "$(human_file_size "$completed_files_total_bytes")"
        printf 'New media total duration: %s\n' "$(human_duration "$completed_files_total_seconds")"
        ;;
    esac
    if [[ "${#moved_music_files[@]}" -gt 0 ]]; then
      printf 'Files moved to Apple Music: %s\n' "${#moved_music_files[@]}"
      for moved_music_file in "${moved_music_files[@]}"; do
        printf '  • %s\n' "$moved_music_file"
      done
    fi
    if [[ -s "$media_details_file" ]]; then
      printf '%s\n' "Technical media details (measured with ffprobe):"
      cat "$media_details_file"
    fi
  } >> "$readable_download_history"
  release_download_history_lock
}

download_archive_options=(--download-archive "$active_archive")
already_downloaded=0
force_redownload=0

# Shared progress options for MP3, MP4 and MKV. Workers emit machine-readable
# progress lines for the shared dashboard; a manual Terminal run keeps yt-dlp's
# normal interactive progress display.
yt_dlp_progress_options=(
  --progress
  --progress-delta 1
)
if [[ "$progress_tracking" -eq 1 ]]; then
  yt_dlp_progress_options+=(
    --newline
    --no-colors
    --progress-template 'download:UTUBE_PROGRESS|%(progress.status)s|%(progress._percent_str)s|%(progress._speed_str)s|%(progress._eta_str)s|%(info.playlist_index)s|%(info.playlist_count)s|%(info.id)s|%(info.title)s'
    --progress-template 'postprocess:UTUBE_POSTPROCESS|%(progress.status)s|%(progress.postprocessor)s|%(info.playlist_index)s|%(info.playlist_count)s|%(info.id)s|%(info.title)s'
  )
else
  yt_dlp_progress_options+=(--console-title)
fi

translate_postprocessor_phase() {
  case "$1" in
    *Merger*) printf '%s' "Bild und Ton zusammenführen" ;;
    *ExtractAudio*) printf '%s' "In MP3 umwandeln" ;;
    *EmbedThumbnail*) printf '%s' "Cover einbetten" ;;
    *Metadata*) printf '%s' "Metadaten schreiben" ;;
    *Subtitle*|*Subtitles*) printf '%s' "Untertitel verarbeiten" ;;
    *Fixup*) printf '%s' "Mediendatei optimieren" ;;
    *) printf '%s' "Medien verarbeiten" ;;
  esac
}

process_ytdlp_progress() {
  local line
  local marker
  local status
  local percent
  local speed
  local eta
  local title
  local postprocessor
  local phase
  local playlist_index
  local playlist_count
  local media_id
  local item_result

  while IFS= read -r line; do
    case "$line" in
      UTUBE_PROGRESS\|*)
        IFS='|' read -r marker status percent speed eta playlist_index playlist_count media_id title <<< "$line"
        percent="$(printf '%s' "$percent" | tr -d ' %' | awk '{value=$1+0; if (value<0) value=0; if (value>100) value=100; printf "%.1f", value}')"
        [[ -n "$speed" && "$speed" != "NA" ]] || speed="—"
        [[ -n "$eta" && "$eta" != "NA" ]] || eta="—"
        [[ -n "$title" && "$title" != "NA" ]] || title="Download"
        if [[ "$status" == "finished" ]]; then
          phase="Download abgeschlossen"
          percent="100"
          speed="—"
          eta="—"
        else
          phase="Herunterladen"
        fi
        write_progress_status "$phase" "$percent" "$speed" "$eta" "active" "$title"
        write_playlist_item_status "$playlist_index" "$playlist_count" "$media_id" "$title" \
          "$phase" "$percent" "$speed" "$eta" "active"
        ;;
      UTUBE_POSTPROCESS\|*)
        IFS='|' read -r marker status postprocessor playlist_index playlist_count media_id title <<< "$line"
        [[ -n "$title" && "$title" != "NA" ]] || title="Download"
        phase="$(translate_postprocessor_phase "$postprocessor")"
        item_result="active"
        if [[ "$status" == "finished" ]]; then
          item_result="completed"
          phase="Abgeschlossen"
        fi
        write_progress_status "$phase" "100" "—" "—" "active" "$title"
        write_playlist_item_status "$playlist_index" "$playlist_count" "$media_id" "$title" \
          "$phase" "100" "—" "—" "$item_result"
        ;;
      *)
        if [[ "$line" == ERROR:* ]]; then
          printf '%s\n' "$line" >> "$yt_dlp_error_file"
        fi
        printf '%s\n' "$line"
        ;;
    esac
  done
}

run_ytdlp() {
  local exit_code

  if [[ "$progress_tracking" -eq 1 ]]; then
    set +e
    yt-dlp "${yt_dlp_progress_options[@]}" "$@" 2>&1 | process_ytdlp_progress
    exit_code="${PIPESTATUS[0]}"
    set -e
    yt_dlp_last_exit_code="$exit_code"
    return 0
  fi

  set +e
  yt-dlp "${yt_dlp_progress_options[@]}" "$@"
  exit_code="$?"
  set -e
  yt_dlp_last_exit_code="$exit_code"
  return 0
}

yt_dlp_last_exit_code=0

case "$mode" in
  playlist-mp4|video|playlist-mkv|playlist-mp3|playlist-mp3-advanced)
    id_lookup_options=(--flat-playlist)
    ;;
  *)
    # Ignore YouTube's extra radio-playlist parameter for a single download.
    id_lookup_options=(--no-playlist)
    ;;
esac

prepare_playlist_dashboard_items() {
  local marker
  local playlist_index
  local playlist_count
  local media_id
  local item_title
  local fallback_index=0

  [[ "$progress_tracking" -eq 1 ]] || return 0
  case "$mode" in playlist-*) ;; *) return 0 ;; esac

  write_progress_status "Playlist-Titelliste wird geladen" "0" "—" "—" "active" "Playlist wird vorbereitet"
  while IFS='|' read -r marker playlist_index playlist_count media_id item_title; do
    [[ "$marker" == "UTUBE_PLAYLIST_ITEM" ]] || continue
    fallback_index=$((fallback_index + 1))
    [[ "$playlist_index" =~ ^[0-9]+$ ]] || playlist_index="$fallback_index"
    [[ "$playlist_count" =~ ^[0-9]+$ ]] || playlist_count=0
    [[ -n "$item_title" && "$item_title" != "NA" ]] || item_title="Titel $playlist_index"
    write_playlist_item_status "$playlist_index" "$playlist_count" "$media_id" "$item_title" \
      "Wartet" "0" "—" "—" "queued"
  done < <(yt-dlp --flat-playlist --no-warnings \
    --print 'UTUBE_PLAYLIST_ITEM|%(playlist_index)s|%(playlist_count)s|%(id)s|%(title)s' \
    "$url" 2>/dev/null || true)
  write_progress_status "Playlist ist vorbereitet" "0" "—" "—" "active" "Playlist mit $fallback_index Titel(n)"
}

prepare_playlist_dashboard_items

# Remember the exact output-name stems belonging to this job. This manifest is
# also used after the download, so a parallel job's .part file cannot make this
# completed download look unfinished.
while IFS= read -r expected_file; do
  [[ -n "$expected_file" ]] || continue
  expected_stem="${expected_file%.*}"
  if ! grep -Fqx -- "$expected_stem" "$expected_output_stems_manifest" 2>/dev/null; then
    printf '%s\n' "$expected_stem" >> "$expected_output_stems_manifest"
  fi
done < <(yt-dlp "${id_lookup_options[@]}" --no-warnings --get-filename --output "$output_template" "$url" 2>/dev/null || true)

# Keep a stable identity map while this download runs.  The same YouTube ID is
# later written into the downloaded file itself, so moving folders is harmless.
case "$mode" in
  playlist-*)
    yt-dlp --flat-playlist --no-warnings \
      --print '%(playlist_index)s\t%(id)s\t%(webpage_url)s\t%(channel)s\t%(channel_url)s' \
      "$url" > "$playlist_metadata_manifest" 2>/dev/null || true
    ;;
  *)
    yt-dlp --no-playlist --no-warnings \
      --print '1\t%(id)s\t%(webpage_url)s\t%(channel)s\t%(channel_url)s' \
      "$url" > "$playlist_metadata_manifest" 2>/dev/null || true
    ;;
esac

# Keep a durable, human-readable source record inside every playlist folder.
# It remains available even when YouTube metadata or the download history is
# no longer reachable, and the Mediathek can use it without another web query.
write_playlist_info_file() {
  case "$mode" in playlist-*) ;; *) return 0 ;; esac
  local first_stem playlist_folder info_file
  playlist_folder="${1:-}"
  if [[ -z "$playlist_folder" ]]; then
    first_stem="$(head -n 1 "$expected_output_stems_manifest" 2>/dev/null || true)"
    [[ -n "$first_stem" ]] || return 0
    playlist_folder="$(dirname "$first_stem")"
  fi
  mkdir -p "$playlist_folder"
  info_file="$playlist_folder/UTUBE-MAC-PLAYLIST.txt"
  {
    printf '%s\n' 'UTUBE MAC – Playlist-Information'
    printf 'Erstellt am: %s\n' "$(date '+%d.%m.%Y %H:%M:%S')"
    printf 'Playlist-URL: %s\n' "$url"
    printf 'Download-Modus: %s\n' "$mode"
    printf 'Gewählte Qualität: %s\n' "$quality"
    printf '\n%s\n' '--- PLAYLIST ---'
    yt-dlp --flat-playlist --playlist-items 1 --no-warnings \
      --print 'Titel: %(playlist_title)s' \
      --print 'Kanal: %(channel)s' \
      --print 'Kanal-URL: %(channel_url)s' \
      --print 'Playlist-ID: %(playlist_id)s' \
      "$url" 2>/dev/null || true
    printf '\n%s\n' '--- VIDEOS ---'
    yt-dlp --flat-playlist --no-warnings \
      --print 'Video %(playlist_index)s von %(playlist_count)s' \
      --print 'Titel: %(title)s' \
      --print 'Video-URL: %(webpage_url)s' \
      --print 'Video-ID: %(id)s' \
      --print 'Kanal: %(channel)s' \
      --print 'Kanal-URL: %(channel_url)s' \
      --print 'Uploaddatum: %(upload_date)s' \
      --print 'Dauer: %(duration_string)s' \
      --print 'Beschreibung: %(description)s' \
      --print '' \
      "$url" 2>/dev/null || true
  } > "$info_file"
}

write_playlist_info_file

write_playlist_failure_note() {
  case "$mode" in playlist-*) ;; *) return 0 ;; esac
  local first_stem playlist_folder info_file
  first_stem="$(head -n 1 "$expected_output_stems_manifest" 2>/dev/null || true)"
  [[ -n "$first_stem" ]] || return 0
  playlist_folder="$(dirname "$first_stem")"
  write_playlist_info_file "$playlist_folder"
  info_file="$playlist_folder/UTUBE-MAC-PLAYLIST.txt"
  {
    printf '\n%s\n' '--- DOWNLOAD-STATUS ---'
    printf 'Status: Unvollständig oder fehlgeschlagen\n'
    printf 'Protokoll: %s\n' "${progress_log_file:-Nicht verfügbar}"
    printf 'Hinweis: UTUBE MAC kann diese Playlist über „Erneut versuchen / Reparieren“ ergänzen.\n'
  } >> "$info_file"
}

expected_total=0
expected_present=0
partial_download=0
apple_music_mode=0
existing_media_file=""

# A leftover audio/video stream from an interrupted merge is not a completed
# download.  Only the final format selected by the person counts as present.
is_completed_media_file() {
  local candidate="$1"
  case "$mode" in
    *-mp4|single-video|video) [[ "$candidate" == *.mp4 ]] || return 1 ;;
    *-mkv) [[ "$candidate" == *.mkv ]] || return 1 ;;
    *-mp3|*-mp3-advanced) [[ "$candidate" == *.mp3 ]] || return 1 ;;
    *) return 1 ;;
  esac
  # A file with the right extension can still be a broken merge.  Count it
  # only when FFmpeg can read a real duration from it.
  ffprobe -v error -show_entries format=duration -of default=nw=1:nk=1 "$candidate" 2>/dev/null | grep -Eq '^[0-9]+(\.[0-9]+)?$'
}

if [[ "$audio_destination" == "apple_music" ]]; then
  case "$mode" in
    single-mp3|playlist-mp3|single-mp3-advanced|playlist-mp3-advanced)
      apple_music_mode=1
      ;;
  esac
fi

if [[ "$apple_music_mode" -eq 1 ]]; then
  # Music moves imported files out of its watched folder. In this mode the
  # yt-dlp archive, rather than the no-longer-present MP3 file, is the source
  # of truth for duplicate detection.
  while IFS= read -r archive_entry; do
    [[ -n "$archive_entry" ]] || continue
    expected_total=$((expected_total + 1))
    if [[ -f "$active_archive" ]] && grep -Fqx "$archive_entry" "$active_archive"; then
      expected_present=$((expected_present + 1))
    fi
  done < <(yt-dlp "${id_lookup_options[@]}" --no-warnings --print '%(extractor)s %(id)s' "$url" 2>/dev/null || true)

  if [[ "$expected_total" -gt 0 && "$expected_total" -eq "$expected_present" ]]; then
    already_downloaded=1
  fi
else
  # For normal folders, only a real media file counts as downloaded.
  # Thumbnails and temporary .part files must not trigger completion.
  case "$mode" in
    single-*|single-video)
      # Ask yt-dlp for the exact filename it would create. Reconstructing the
      # path from the title is unreliable because yt-dlp may normalise special
      # characters differently on another Mac or in another locale.
      while IFS= read -r expected_stem; do
        [[ -n "$expected_stem" ]] || continue
        expected_total=1
        for candidate in "$expected_stem".*; do
          [[ -f "$candidate" ]] || continue
          if is_completed_media_file "$candidate"; then
            expected_present=1
            [[ -n "$existing_media_file" ]] || existing_media_file="$candidate"
            break
          elif [[ "$candidate" == *.part || "$candidate" == *.ytdl ]]; then
            partial_download=1
          fi
        done
      done < "$expected_output_stems_manifest"
      ;;
    *)
      while IFS= read -r expected_stem; do
        [[ -n "$expected_stem" ]] || continue
        expected_total=$((expected_total + 1))
        for candidate in "$expected_stem".*; do
          [[ -f "$candidate" ]] || continue
          if is_completed_media_file "$candidate"; then
            expected_present=$((expected_present + 1))
            [[ -n "$existing_media_file" ]] || existing_media_file="$candidate"
            break
          elif [[ "$candidate" == *.part || "$candidate" == *.ytdl ]]; then
            partial_download=1
          fi
        done
      done < "$expected_output_stems_manifest"
      ;;
  esac

  if [[ "$expected_total" -gt 0 && "$expected_total" -eq "$expected_present" ]]; then
    already_downloaded=1
  elif [[ "$expected_total" -gt 0 ]]; then
    # A file was deleted or a playlist is incomplete. Existing files are kept
    # while missing items are allowed to download again.
    download_archive_options=(--no-download-archive)
  elif [[ "$partial_download" -eq 1 ]]; then
    download_archive_options=(--no-download-archive)
  fi
fi

if [[ "$already_downloaded" -eq 1 ]]; then
  write_progress_status "Bereits vorhanden – warte auf Auswahl" "100" "—" "—" "waiting" "Download bereits gespeichert"
  if [[ -n "$existing_media_file" ]]; then
    choice="$(osascript - "$existing_media_file" <<'ALREADY_DOWNLOADED_DIALOG_EOF'
on run argv
  display dialog ("Dieser Download ist bereits vorhanden." & return & return & "Datei:" & return & item 1 of argv & return & return & "Du kannst die vorhandene Datei im Finder anzeigen oder sie erneut herunterladen und ersetzen.") with title "UTUBE MAC" buttons {"Nicht erneut laden", "Datei anzeigen", "Erneut herunterladen"} default button "Nicht erneut laden" with icon note
end run
ALREADY_DOWNLOADED_DIALOG_EOF
)"
  else
    choice="$(osascript -e 'display dialog "Dieser Download wurde bereits gespeichert. Möchtest du ihn erneut herunterladen?" with title "UTUBE MAC" buttons {"Nicht erneut laden", "Erneut herunterladen"} default button "Nicht erneut laden" with icon note')"
  fi

  if [[ "$choice" == *"Erneut herunterladen"* ]]; then
    download_archive_options=(--force-overwrites)
    force_redownload=1
    write_progress_status "Erneuter Download wird vorbereitet" "0" "—" "—" "active" "Download wird vorbereitet"
  elif [[ "$choice" == *"Datei anzeigen"* ]]; then
    open -R "$existing_media_file"
    finalize_progress_job "completed" "Bereits vorhanden"
    exit 0
  else
    if [[ "$apple_music_mode" -eq 1 ]]; then
      exit 0
    else
      case "$mode" in
        single-mp3-advanced|playlist-mp3-advanced)
          # Keep the existing file, then continue to its background metadata scan.
          ;;
        *)
          exit 0
          ;;
      esac
    fi
  fi
fi

download_mp4() {
  local playlist_option="$1"
  local output_template="$2"

  run_ytdlp \
    "$playlist_option" \
    --continue \
    --ignore-errors \
    --no-abort-on-error \
    "${download_archive_options[@]}" \
    --embed-metadata \
    --embed-thumbnail \
    "${subtitle_arguments[@]}" \
    --format "$(format_for_quality)" \
    --merge-output-format mp4 \
    --print-to-file "after_move:%(filepath)s" "$completed_files_manifest" \
    --output "$output_template" \
    "$url"
}

download_mkv() {
  local playlist_option="$1"
  local output_template="$2"
  local mkv_format

  case "$quality" in
    fast) mkv_format="bv*[height<=1080]+ba/b" ;;
    best) mkv_format="bv*+mergeall[vcodec=none]/bv*+ba/b" ;;
    2160) mkv_format="bv*[height<=2160]+mergeall[vcodec=none]/bv*[height<=2160]+ba/b" ;;
    1080) mkv_format="bv*[height<=1080]+mergeall[vcodec=none]/bv*[height<=1080]+ba/b" ;;
    720) mkv_format="bv*[height<=720]+mergeall[vcodec=none]/bv*[height<=720]+ba/b" ;;
    480) mkv_format="bv*[height<=480]+mergeall[vcodec=none]/bv*[height<=480]+ba/b" ;;
    *)
      printf 'Ungültige Videoqualität: %s\n' "$quality"
      exit 64
      ;;
  esac

  run_ytdlp \
    "$playlist_option" \
    --continue \
    --ignore-errors \
    --no-abort-on-error \
    "${download_archive_options[@]}" \
    --audio-multistreams \
    --write-subs \
    --write-auto-subs \
    --sub-langs all \
    --sub-format "srt" \
    --embed-subs \
    --embed-metadata \
    --embed-thumbnail \
    --format "$mkv_format" \
    --merge-output-format mkv \
    --print-to-file "after_move:%(filepath)s" "$completed_files_manifest" \
    --output "$output_template" \
    "$url"
}

download_mp3() {
  local playlist_option="$1"
  local output_template="$2"

  run_ytdlp \
    "$playlist_option" \
    --continue \
    --ignore-errors \
    --no-abort-on-error \
    "${download_archive_options[@]}" \
    --embed-metadata \
    --embed-thumbnail \
    --extract-audio \
    --audio-format mp3 \
    --audio-quality 0 \
    --print-to-file "after_move:%(filepath)s" "$completed_files_manifest" \
    --output "$output_template" \
    "$url"
}

find_beet() {
  if command -v beet >/dev/null 2>&1; then
    command -v beet
  elif [[ -x /opt/homebrew/bin/beet ]]; then
    printf '%s\n' "/opt/homebrew/bin/beet"
  elif [[ -x /usr/local/bin/beet ]]; then
    printf '%s\n' "/usr/local/bin/beet"
  else
    return 1
  fi
}

apply_beets_metadata() {
  local folder="$1"
  local beet_path

  beet_path="$(find_beet)" || {
    printf 'Beets ist nicht installiert. Bitte zuerst Einrichten auswählen.\n'
    return 1
  }

  run_beets_scan() {
    while IFS= read -r -d '' audio_file; do
      "$beet_path" -c "$beets_config_file" import -q -s -C -M "$audio_file" || :
    done < <(find "$folder" -type f -iname '*.mp3' -print0)

    osascript -e 'display notification "MusicBrainz-Metadaten wurden im Hintergrund verarbeitet." with title "UTUBE MAC"'
  }

  if [[ "$audio_destination" == "apple_music" ]]; then
    # MusicBrainz must finish before the completed file is handed to Music.
    run_beets_scan
  else
    (run_beets_scan) >/dev/null 2>&1 &
  fi
}

download_mp3_advanced() {
  local playlist_option="$1"
  local output_template="$2"

  run_ytdlp \
    "$playlist_option" \
    --continue \
    --ignore-errors \
    --no-abort-on-error \
    "${download_archive_options[@]}" \
    --embed-metadata \
    --embed-thumbnail \
    --extract-audio \
    --audio-format mp3 \
    --audio-quality 0 \
    --print-to-file "after_move:%(filepath)s" "$completed_files_manifest" \
    --output "$output_template" \
    "$url"
}

download_started_epoch="$(date +%s)"

case "$mode" in
  single-mp4|single-video)
    download_mp4 \
      --no-playlist \
      "$mp4_single_directory/%(title)s.%(ext)s"
    ;;
  playlist-mp4|video)
    download_mp4 \
      --yes-playlist \
      "$mp4_playlists_directory/%(playlist_title)s/%(playlist_index)03d - %(title)s.%(ext)s"
    ;;
  single-mkv)
    download_mkv \
      --no-playlist \
      "$mkv_single_directory/%(title)s.%(ext)s"
    ;;
  playlist-mkv)
    download_mkv \
      --yes-playlist \
      "$mkv_playlists_directory/%(playlist_title)s/%(playlist_index)03d - %(title)s.%(ext)s"
    ;;
  single-mp3)
    download_mp3 \
      --no-playlist \
      "$mp3_single_directory/%(title)s.%(ext)s"
    ;;
  playlist-mp3|mp3)
    download_mp3 \
      --yes-playlist \
      "$mp3_playlists_directory/%(playlist_title)s/%(playlist_index)03d - %(title)s.%(ext)s"
    ;;
single-mp3-advanced)
  download_mp3_advanced \
    --no-playlist \
    "$mp3_advanced_single_directory/%(title)s.%(ext)s"
  apply_beets_metadata "$mp3_advanced_single_directory"
  ;;
playlist-mp3-advanced)
  download_mp3_advanced \
    --yes-playlist \
    "$mp3_advanced_playlists_directory/%(playlist_title)s/%(playlist_index)03d - %(title)s.%(ext)s"
  apply_beets_metadata "$mp3_advanced_playlists_directory"
  ;;
*)
  printf 'Ungültiger Modus: %s\n' "$mode"
  exit 64
  ;;
esac

if [[ "$yt_dlp_last_exit_code" -eq 0 ]]; then
  write_progress_status "Abschlussdaten werden geprüft" "100" "—" "—" "active" "Download"
else
  write_progress_status "Download fehlgeschlagen – Fehler wird ausgewertet" "0" "—" "—" "active" "Download"
fi

case "$mode" in
  single-mp4|single-video) folder_to_open="$mp4_single_directory" ;;
  playlist-mp4|video)     folder_to_open="$mp4_playlists_directory" ;;
  single-mkv)             folder_to_open="$mkv_single_directory" ;;
  playlist-mkv)           folder_to_open="$mkv_playlists_directory" ;;
  single-mp3)             folder_to_open="$mp3_single_directory" ;;
  playlist-mp3|mp3)       folder_to_open="$mp3_playlists_directory" ;;
  single-mp3-advanced)   folder_to_open="$mp3_advanced_single_directory" ;;
  playlist-mp3-advanced) folder_to_open="$mp3_advanced_playlists_directory" ;;
esac

audio_files_sent_to_music=0
music_handoff_epoch=0
moved_music_files=()
send_completed_audio_to_music() {
  local completed_file
  local file_name
  local destination_file
  local name_without_extension

  [[ "$apple_music_mode" -eq 1 ]] || return 0

  if [[ ! -d "$apple_music_directory" ]]; then
    printf 'Apple-Music-Importordner wurde nicht gefunden: %s\n' "$apple_music_directory"
    return 1
  fi

  while IFS= read -r completed_file; do
    [[ -f "$completed_file" ]] || continue
    case "$completed_file" in
      *.mp3|*.MP3) ;;
      *) continue ;;
    esac

    file_name="$(basename "$completed_file")"
    destination_file="$apple_music_directory/$file_name"

    # Avoid overwriting an item that Music has not processed yet.
    if [[ -e "$destination_file" ]]; then
      name_without_extension="${file_name%.*}"
      destination_file="$apple_music_directory/${name_without_extension} - $(date +%Y%m%d-%H%M%S).mp3"
    fi

    if [[ "$music_handoff_epoch" -eq 0 ]]; then
      music_handoff_epoch="$(date +%s)"
    fi

    mv -- "$completed_file" "$destination_file"
    moved_music_files+=("$destination_file")
    audio_files_sent_to_music=$((audio_files_sent_to_music + 1))
  done < "$new_completed_files_manifest"

  folder_to_open="$apple_music_directory"
}

case "$mode" in
  playlist-*) job_name="$(yt-dlp --flat-playlist --no-warnings --print '%(playlist_title)s' "$url" 2>/dev/null | head -n 1 || true)" ;;
  *) job_name="$(yt-dlp --no-playlist --no-warnings --print '%(title)s' "$url" 2>/dev/null | head -n 1 || true)" ;;
esac
[[ -n "$job_name" ]] || job_name="Download"
write_progress_status "Technische Daten werden gelesen" "100" "—" "—" "active" "$job_name"

# Write it again beside the actual completed media.  This fallback also works
# when YouTube returned a filename different from the predicted filename.
case "$mode" in
  playlist-*)
    first_completed_file="$(head -n 1 "$completed_files_manifest" 2>/dev/null || true)"
    [[ -n "$first_completed_file" ]] && write_playlist_info_file "$(dirname "$first_completed_file")"
    ;;
esac

# Store an invisible, portable UTUBE MAC identity in each newly written media
# file. Finder does not show it; the Mediathek can read it after folders move.
embed_utube_mac_identifiers() {
  local media_file media_name media_index metadata_line video_id source_url channel_name channel_url temporary_file extension
  while IFS= read -r media_file; do
    [[ -f "$media_file" ]] || continue
    media_name="$(basename "$media_file")"
    media_index="${media_name%% - *}"
    media_index="$((10#${media_index:-1}))" 2>/dev/null || media_index=1
    metadata_line="$(awk -F '\t' -v index="$media_index" '$1 == index {print; exit}' "$playlist_metadata_manifest" 2>/dev/null || true)"
    [[ -n "$metadata_line" ]] || metadata_line="$(head -n 1 "$playlist_metadata_manifest" 2>/dev/null || true)"
    IFS=$'\t' read -r _ video_id source_url channel_name channel_url <<< "$metadata_line"
    [[ -n "$video_id" && "$video_id" != "NA" ]] || continue
    extension="${media_file##*.}"
    temporary_file="${media_file%.*}.utube-mac-tagging-$$.${extension}"
    if [[ "$extension" == "mp4" || "$extension" == "MP4" ]]; then
      ffmpeg -hide_banner -loglevel error -y -i "$media_file" -map 0 -map_metadata 0 -c copy -movflags use_metadata_tags+faststart \
        -metadata "utube_mac_id=$video_id" -metadata "utube_mac_source_url=$source_url" \
        -metadata "utube_mac_channel=$channel_name" -metadata "utube_mac_channel_url=$channel_url" \
        "$temporary_file" && mv -f -- "$temporary_file" "$media_file" || rm -f -- "$temporary_file"
    else
      ffmpeg -hide_banner -loglevel error -y -i "$media_file" -map 0 -map_metadata 0 -c copy \
        -metadata "utube_mac_id=$video_id" -metadata "utube_mac_source_url=$source_url" \
        -metadata "utube_mac_channel=$channel_name" -metadata "utube_mac_channel_url=$channel_url" \
        "$temporary_file" && mv -f -- "$temporary_file" "$media_file" || rm -f -- "$temporary_file"
    fi
  done < "$completed_files_manifest"
}

embed_utube_mac_identifiers

# Keep YouTube thumbnail sidecar files available for UTUBE MAC without
# cluttering the playlist folder in Finder. Files beginning with a dot are
# hidden by macOS but remain usable as Mediathek cover art.
hide_playlist_thumbnails() {
  local media_file asset_directory image_file media_name media_index metadata_line video_id source_url asset_index moved_image
  case "$mode" in playlist-*) ;; *) return 0 ;; esac
  while IFS= read -r media_file; do
    [[ -f "$media_file" ]] || continue
    asset_directory="$(dirname "$media_file")/.utube-mac-assets"
    mkdir -p "$asset_directory"
    asset_index="$asset_directory/UTUBE-MAC-ASSETS.txt"
    media_name="$(basename "$media_file")"; media_index="${media_name%% - *}"
    media_index="$((10#${media_index:-1}))" 2>/dev/null || media_index=1
    metadata_line="$(awk -F '\t' -v index="$media_index" '$1 == index {print; exit}' "$playlist_metadata_manifest" 2>/dev/null || true)"
    IFS=$'\t' read -r _ video_id source_url _ _ <<< "$metadata_line"
    for image_file in "${media_file%.*}".jpg "${media_file%.*}".jpeg "${media_file%.*}".webp "${media_file%.*}".png; do
      [[ -f "$image_file" ]] || continue
      moved_image="$asset_directory/$(basename "$image_file")"
      mv -f -- "$image_file" "$asset_directory/"
      [[ -n "$video_id" && "$video_id" != "NA" ]] || continue
      xattr -w com.utube-mac.video-id "$video_id" "$moved_image" 2>/dev/null || true
      xattr -w com.utube-mac.source-url "$source_url" "$moved_image" 2>/dev/null || true
      printf 'Bild: %s\nUTUBE-MAC-ID: %s\nVideo-URL: %s\n\n' "$(basename "$moved_image")" "$video_id" "$source_url" >> "$asset_index"
    done
  done < "$completed_files_manifest"
}

hide_playlist_thumbnails

# Capture real technical data before Music moves completed MP3 files out of its
# watched folder. Files that yt-dlp only skipped are excluded by modification
# time, so the popup describes this run rather than an older download.
analyse_completed_media

case "$mode" in
  playlist-*)
    playlist_successful="$completed_files_count"
    if [[ "$force_redownload" -eq 1 ]]; then
      playlist_skipped=0
    else
      playlist_skipped="$expected_present"
    fi
    playlist_failed=$((expected_total - playlist_successful - playlist_skipped))
    [[ "$playlist_failed" -ge 0 ]] || playlist_failed=0

    completion_summary="$(printf '📚 %s\n\nErfolgreich: %s\nÜbersprungen: %s\nFehlgeschlagen: %s\nNeu gespeichert: %s · %s' \
      "$job_name" \
      "$playlist_successful" \
      "$playlist_skipped" \
      "$playlist_failed" \
      "$(human_file_size "$completed_files_total_bytes")" \
      "$(human_duration "$completed_files_total_seconds")")"
    ;;
  *)
    completion_summary="$(<"$single_popup_summary_file")"
    [[ -n "$completion_summary" ]] || completion_summary="Download abgeschlossen: $job_name"
    ;;
esac

# Do not call this job complete while one of its own resumable files remains.
# Checking only the expected stems is essential when several downloads run in
# parallel: an unrelated job may legitimately still have a recent .part file.
incomplete_after_download=0
while IFS= read -r expected_stem; do
  [[ -n "$expected_stem" ]] || continue
  for candidate in \
    "$expected_stem".part \
    "$expected_stem".*.part \
    "$expected_stem".ytdl \
    "$expected_stem".*.ytdl; do
    [[ -f "$candidate" ]] || continue
    candidate_modified_epoch="$(stat -f '%m' "$candidate" 2>/dev/null || printf '0')"
    [[ "$candidate_modified_epoch" =~ ^[0-9]+$ ]] || candidate_modified_epoch=0
    if [[ "$candidate_modified_epoch" -ge $((download_started_epoch - 5)) ]]; then
      incomplete_after_download=1
      break 2
    fi
  done
done < "$expected_output_stems_manifest"

# Finished MP3s may safely be handed to Music even if another playlist item is
# still resumable. Only paths from this run are moved; fragments stay behind.
if [[ "$apple_music_mode" -eq 1 && "$completed_files_count" -gt 0 ]]; then
  send_completed_audio_to_music
fi

if [[ "$incomplete_after_download" -eq 1 ]]; then
  write_playlist_failure_note
  record_readable_download_history "Incomplete — will continue on the next run"
  write_progress_status "Unvollständig – warte auf Bestätigung" "100" "—" "—" "waiting" "$job_name"
  if [[ "${UTUBE_MAC_DOWNLOAD_WORKER:-0}" == "1" ]]; then
    finalize_progress_job "failed" "Unvollständig – wird später fortgesetzt"
    exit 0
  fi
  osascript - "$completed_files_count" <<'INCOMPLETE_DIALOG_EOF'
on run argv
  set completedCount to item 1 of argv
  display dialog ("Der Download ist noch nicht vollständig abgeschlossen." & return & return & completedCount & " fertige Datei(en) wurden bereits gespeichert. Unvollständige Teile werden beim nächsten Start automatisch fortgesetzt.") with title "UTUBE MAC" buttons {"Fertig"} default button "Fertig" with icon caution
end run
INCOMPLETE_DIALOG_EOF
  finalize_progress_job "failed" "Unvollständig – wird später fortgesetzt"
  exit 0
fi

if [[ "$completed_files_count" -eq 0 ]]; then
  write_playlist_failure_note
  download_error_detail="$(tail -n 1 "$yt_dlp_error_file" 2>/dev/null | sed 's/^ERROR: *//' || true)"
  case "$download_error_detail" in
    *"playlist does not exist"*)
      download_error_detail="Diese YouTube-Playlist existiert nicht, ist privat oder der Link ist nicht mehr gültig."
      ;;
    *"Private video"*|*"private video"*)
      download_error_detail="Das Video ist privat und kann ohne berechtigten YouTube-Zugang nicht geladen werden."
      ;;
    *"Video unavailable"*|*"video unavailable"*)
      download_error_detail="Das Video ist bei YouTube nicht verfügbar."
      ;;
  esac
  [[ -n "$download_error_detail" ]] || download_error_detail="YouTube hat keine herunterladbare Mediendatei geliefert."
  download_error_detail="${download_error_detail:0:600}"
  record_readable_download_history "Failed — no completed media file was created"
  write_progress_status "Keine fertige Datei – warte auf Bestätigung" "100" "—" "—" "waiting" "$job_name"
  if [[ "${UTUBE_MAC_DOWNLOAD_WORKER:-0}" == "1" ]]; then
    finalize_progress_job "failed" "Keine fertige Mediendatei erstellt"
    exit 1
  fi
  if [[ -n "$progress_log_file" ]]; then
    failure_choice="$(osascript - "$download_error_detail" <<'DOWNLOAD_FAILURE_DIALOG_EOF'
on run argv
  display dialog ("Der Download konnte nicht abgeschlossen werden." & return & return & (item 1 of argv)) with title "UTUBE MAC" buttons {"Fertig", "Protokoll öffnen"} default button "Fertig" with icon caution
end run
DOWNLOAD_FAILURE_DIALOG_EOF
)"
    if [[ "$failure_choice" == *"Protokoll öffnen"* ]]; then
      open "$progress_log_file"
    fi
  else
    osascript - "$download_error_detail" <<'DOWNLOAD_FAILURE_DIALOG_EOF'
on run argv
  display dialog ("Der Download konnte nicht abgeschlossen werden." & return & return & (item 1 of argv)) with title "UTUBE MAC" buttons {"Fertig"} default button "Fertig" with icon caution
end run
DOWNLOAD_FAILURE_DIALOG_EOF
  fi
  finalize_progress_job "failed" "Keine fertige Mediendatei erstellt"
  exit 1
fi

if [[ "$apple_music_mode" -eq 1 && "$audio_files_sent_to_music" -eq 0 ]]; then
  record_readable_download_history "Failed — completed MP3 could not be sent to Apple Music"
  write_progress_status "Apple-Music-Übergabe fehlgeschlagen" "100" "—" "—" "waiting" "$job_name"
  if [[ "${UTUBE_MAC_DOWNLOAD_WORKER:-0}" == "1" ]]; then
    finalize_progress_job "failed" "Apple-Music-Übergabe fehlgeschlagen"
    exit 1
  fi
  osascript -e 'display dialog "Die fertige MP3-Datei konnte nicht zu Apple Music hinzugefügt werden. Temporäre Dateien wurden nicht verschoben." with title "UTUBE MAC" buttons {"Fertig"} default button "Fertig" with icon caution'
  finalize_progress_job "failed" "Apple-Music-Übergabe fehlgeschlagen"
  exit 1
fi

record_readable_download_history "Completed"
write_progress_status "Fertig – warte auf deine Auswahl" "100" "—" "—" "waiting" "$job_name"

# A queue must never pause for a dialog after every playlist.  Its worker
# creates one summary only after every queued item has reached a result.
if [[ "${UTUBE_MAC_DOWNLOAD_WORKER:-0}" == "1" ]]; then
  finalize_progress_job "completed" "Abgeschlossen"
  exit 0
fi

if [[ "$apple_music_mode" -eq 1 ]]; then
  choice="$(osascript - "$completion_summary" "$audio_files_sent_to_music" <<'MUSIC_COMPLETION_DIALOG_EOF'
on run argv
  display dialog ((item 1 of argv) & return & return & "Ziel: Apple Music" & return & "Importierte Dateien: " & (item 2 of argv)) buttons {"Fertig", "In Music anzeigen", "Verlauf öffnen"} default button "Fertig" with title "UTUBE MAC"
end run
MUSIC_COMPLETION_DIALOG_EOF
)"

  if [[ "$choice" == *"In Music anzeigen"* ]]; then
    elapsed_since_music_handoff=0
    if [[ "$music_handoff_epoch" -gt 0 ]]; then
      elapsed_since_music_handoff=$(( $(date +%s) - music_handoff_epoch ))
    fi

    music_reveal_result="$(osascript - "$elapsed_since_music_handoff" <<'REVEAL_IMPORTED_MUSIC_EOF'
on run argv
  set seconds_since_handoff to (item 1 of argv) as integer
  set cutoff_time to (current date) - (seconds_since_handoff + 5)

  tell application "Music"
    activate

    -- Music imports files from its watched folder asynchronously. Wait until
    -- the new UTUBE-MAC track is present, then reveal the newest matching item.
    repeat 30 times
      try
        set recent_tracks to every file track of library playlist 1 whose date added is greater than cutoff_time
        if (count of recent_tracks) > 0 then
          set newest_track to item 1 of recent_tracks
          repeat with candidate_track in recent_tracks
            if (date added of candidate_track) > (date added of newest_track) then
              set newest_track to candidate_track
            end if
          end repeat
          reveal newest_track
          return "shown"
        end if
      end try
      delay 1
    end repeat
  end tell

  return "not-found"
end run
REVEAL_IMPORTED_MUSIC_EOF
)"

    if [[ "$music_reveal_result" != "shown" ]]; then
      osascript -e 'display dialog "Music wurde geöffnet, aber der neue Titel wird noch importiert. Du findest ihn gleich unter ‚Zuletzt hinzugefügt‘ bzw. ‚Recently Added‘." with title "UTUBE MAC" buttons {"OK"} default button "OK" with icon note'
    fi
  elif [[ "$choice" == *"Verlauf öffnen"* ]]; then
    open "$readable_download_history"
  fi
else
  case "$mode" in
    playlist-*)
      choice="$(osascript - "$completion_summary" "$folder_to_open" <<'PLAYLIST_COMPLETION_DIALOG_EOF'
on run argv
  display dialog ((item 1 of argv) & return & return & "Ziel: " & (item 2 of argv)) buttons {"Fertig", "Ordner öffnen", "Verlauf öffnen"} default button "Fertig" with title "UTUBE MAC"
end run
PLAYLIST_COMPLETION_DIALOG_EOF
)"

      if [[ "$choice" == *"Ordner öffnen"* ]]; then
        open "$folder_to_open"
      elif [[ "$choice" == *"Verlauf öffnen"* ]]; then
        open "$readable_download_history"
      fi
      ;;
    *)
      choice="$(osascript - "$completion_summary" "$folder_to_open" <<'SINGLE_COMPLETION_DIALOG_EOF'
on run argv
  display dialog ((item 1 of argv) & return & return & "Ziel: " & (item 2 of argv)) buttons {"Fertig", "Datei anzeigen", "Weitere Aktionen"} default button "Fertig" with title "UTUBE MAC"
end run
SINGLE_COMPLETION_DIALOG_EOF
)"

      if [[ "$choice" == *"Datei anzeigen"* ]]; then
        open -R "$primary_completed_file"
      elif [[ "$choice" == *"Weitere Aktionen"* ]]; then
        more_choice="$(osascript <<'MORE_ACTIONS_DIALOG_EOF'
display dialog "Was möchtest du mit dem fertigen Download machen?" with title "UTUBE MAC" buttons {"Zurück", "Ordner öffnen", "Mit AirDrop teilen"} default button "Ordner öffnen"
MORE_ACTIONS_DIALOG_EOF
)"
        if [[ "$more_choice" == *"Ordner öffnen"* ]]; then
          open "$folder_to_open"
        elif [[ "$more_choice" == *"Mit AirDrop teilen"* ]]; then
          write_progress_status "AirDrop-Auswahl geöffnet" "100" "—" "—" "waiting" "$job_name"
          if /usr/bin/osascript -l JavaScript - "$primary_completed_file" <<'AIRDROP_SHARE_JXA_EOF'
ObjC.import('AppKit')

function run(argv) {
    const fileURL = $.NSURL.fileURLWithPath(argv[0])
    const shareItems = $.NSMutableArray.alloc.init
    shareItems.addObject(fileURL)

    const sharingService = $.NSSharingService.sharingServiceNamed(
        $.NSSharingServiceNameSendViaAirDrop
    )
    if (!sharingService || !sharingService.canPerformWithItems(shareItems)) {
        throw new Error('AirDrop ist für diese Datei nicht verfügbar.')
    }

    $.NSApplication.sharedApplication.activateIgnoringOtherApps(true)
    sharingService.performWithItems(shareItems)

    // Give macOS enough time to hand the native AirDrop window to its sharing
    // service before this invisible helper exits.
    delay(5)
}
AIRDROP_SHARE_JXA_EOF
          then
            osascript -e 'display notification "AirDrop wurde mit der fertigen Datei geöffnet." with title "UTUBE MAC"' || true
          else
            airdrop_error_choice="$(osascript - "$primary_completed_file" <<'AIRDROP_ERROR_DIALOG_EOF'
on run argv
  display dialog ("Die Datei konnte nicht an AirDrop übergeben werden." & return & return & "Datei:" & return & item 1 of argv) with title "UTUBE MAC – AirDrop" buttons {"Fertig", "Datei anzeigen"} default button "Fertig" with icon caution
end run
AIRDROP_ERROR_DIALOG_EOF
)"
            if [[ "$airdrop_error_choice" == *"Datei anzeigen"* ]]; then
              open -R "$primary_completed_file"
            fi
          fi
        fi
      fi
      ;;
  esac
fi
finalize_progress_job "completed" "Abgeschlossen"
