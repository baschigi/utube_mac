#!/bin/bash
# Shared local/Terminal/in-app installation engine. Never writes personal data.
set -euo pipefail
[[ "$EUID" != 0 ]] || { echo 'Run as your normal user, not root.'; exit 1; }
package="$(cd "$(dirname "$0")" && pwd)"
allow_downgrade=false; test_root=''; assume_yes=false
while [[ $# -gt 0 ]]; do
  case "$1" in
    --allow-downgrade) allow_downgrade=true; shift ;;
    --test-root) test_root="${2:?}"; shift 2 ;;
    --yes) assume_yes=true; shift ;;
    *) echo "Unknown option: $1"; exit 2 ;;
  esac
done
die(){ echo "UTUBE MAC: $*" >&2; exit 1; }
process_exists(){
  local status
  if /usr/bin/pgrep -u "$(id -u)" -f "$1" >/dev/null; then return 0; else status=$?; fi
  [[ "$status" == 1 ]] || die 'Cannot inspect running processes safely. No installation attempted.'
  return 1
}
field(){ /usr/bin/plutil -extract "$1" raw -o - "$package/package.json"; }
at_least(){ /usr/bin/awk -v a="$1" -v b="$2" 'BEGIN{split(a,x,".");split(b,y,".");for(i=1;i<=4;i++){if(x[i]+0>y[i]+0)exit 0;if(x[i]+0<y[i]+0)exit 1}exit 0}'; }
[[ "$(field schema)" == 1 ]] || die 'Unsupported package.'
version="$(field version)"; [[ "$version" =~ ^[0-9]\.[0-9](\.[0-9])?$ ]] || die 'Invalid version.'
[[ "$(field architecture)" == "$(uname -m)" ]] || die 'Unsupported Mac architecture.'
at_least "$(sw_vers -productVersion)" "$(field minimum_macos)" || die 'Unsupported macOS version.'
[[ -z "$(find "$package/payload" -type l -print)" ]] || die 'Package links are not allowed.'
[[ -f "$package/payload/app/UTUBE MAC.app/Contents/Info.plist" && -f "$package/payload/scripts/dependency-manager.sh" ]] || die 'Incomplete package.'
verify(){
  local root="$1" hash relative
  while IFS=$'\t' read -r hash relative; do
    [[ "$hash" =~ ^[a-f0-9]{64}$ && "$relative" =~ ^(app/UTUBE\ MAC.app/|scripts/)[A-Za-z0-9_\ ./-]+$ && "$relative" != *..* && "$relative" != */./* ]] || return 1
    [[ -f "$root/$relative" && ! -L "$root/$relative" ]] || return 1
    [[ "$(/usr/bin/shasum -a 256 "$root/$relative" | /usr/bin/awk '{print $1}')" == "$hash" ]] || return 1
  done < "$package/inventory.tsv"
}
[[ -s "$package/inventory.tsv" ]] && verify "$package/payload" || die 'Package file verification failed.'
expected="$(cut -f2 "$package/inventory.tsv" | LC_ALL=C sort)"
actual="$(cd "$package/payload" && find app scripts -type f | LC_ALL=C sort)"
[[ "$actual" == "$expected" ]] || die 'Package contains unlisted files or duplicate inventory entries.'
/usr/bin/codesign --verify --deep --strict "$package/payload/app/UTUBE MAC.app" || die 'App signature verification failed.'
user_root="$HOME"
if [[ -n "$test_root" ]]; then
  [[ "$test_root" == /private/tmp/utube-test.* && -d "$test_root" && ! -L "$test_root" ]] || die 'Tests require an existing /private/tmp/utube-test.* directory.'
  user_root="$test_root"
fi
support="$user_root/Library/Application Support/UTUBE-MAC"
applications="$user_root/Applications"
app="$applications/UTUBE MAC.app"
current_file="$support/Settings/General/utube-mac-version.txt"
current=0.0.0
if [[ -f "$current_file" ]]; then current="$(tr -d '[:space:]' < "$current_file")"; fi
[[ "$current" =~ ^[0-9]+\.[0-9]+(\.[0-9]+)?$ ]] || die 'Installed version is invalid; please inspect it before updating.'
comparison_current="$current"
# Explicit migration from the old 1.0.7x labels to the one-digit release series.
case "$current" in 1.0.7[1-9]) comparison_current=1.0.7 ;; esac
if ! at_least "$version" "$comparison_current" && [[ "$allow_downgrade" != true ]]; then die "Installed $current is newer than published $version. No downgrade performed."; fi
healthy=false
if [[ "$current" == "$version" && -d "$app" && -d "$support/scripts" ]]; then
  healthy=true
  while IFS=$'\t' read -r hash relative; do
    case "$relative" in app/*) installed="$applications/${relative#app/}" ;; scripts/*) installed="$support/$relative" ;; *) healthy=false; break ;; esac
    [[ -f "$installed" && ! -L "$installed" && "$(/usr/bin/shasum -a 256 "$installed" | /usr/bin/awk '{print $1}')" == "$hash" ]] || { healthy=false; break; }
  done < "$package/inventory.tsv"
fi
if [[ "$healthy" == true ]]; then
  if /bin/bash "$support/scripts/dependency-manager.sh" --check | /usr/bin/awk -F '\t' '$2!="ready" && $3=="true"{bad=1} END{exit bad}'; then
    echo 'Everything is up to date.'; exit 0
  fi
  echo 'The app is current. Some required tools need repair.'
  [[ -n "$test_root" ]] || /usr/bin/open "$app" --args --setup-tools
  exit 0
fi
echo "Install UTUBE MAC $version (currently $current). Settings, libraries, media and Shortcut are preserved."
if [[ "$assume_yes" != true ]]; then
  read -r -p 'Continue? [y/N] ' answer
  [[ "$answer" == y || "$answer" == Y ]] || { echo 'Cancelled. Nothing changed.'; exit 0; }
fi
if [[ -z "$test_root" ]]; then
  # Do not interrupt playback, downloads, or background library jobs automatically.
  if process_exists "$app/Contents/MacOS/"; then die 'Quit UTUBE MAC and run this command again. No files were changed.'; fi
  if process_exists '(yt-dlp|utube_media_download.sh)'; then die 'Finish downloads before installing. No files were changed.'; fi
fi
for target in "$user_root/Library" "$user_root/Library/Application Support" "$applications" "$support" "$support/scripts" "$support/Settings" "$support/Settings/General" "$support/Backups" "$current_file" "$app"; do [[ ! -L "$target" ]] || die "Refusing linked destination: $target"; done
if [[ -d "$support/scripts" && -n "$(find "$support/scripts" -type l -print)" ]]; then die 'Existing scripts contain links. Review these before updating.'; fi
mkdir -p "$applications" "$support/Settings/General" "$support/Backups"
lock="$support/.release-install-lock"
mkdir "$lock" 2>/dev/null || die 'Another installation is running (or an interrupted installation needs its lock reviewed).'
stage="$(mktemp -d "$support/.release-stage.XXXXXXXX")"
app_stage="$(mktemp -d "$applications/.utube-stage.XXXXXXXX")"
backup="$(mktemp -d "$support/Backups/release-$current-to-$version.XXXXXXXX")"
app_moved=false; scripts_moved=false; new_app=false; new_scripts=false; committed=false
cleanup(){
  result=$?
  if [[ "$committed" != true ]]; then
    [[ "$new_app" != true ]] || mv "$app" "$app_stage/failed-app"
    [[ "$new_scripts" != true ]] || mv "$support/scripts" "$stage/failed-scripts"
    [[ "$app_moved" != true ]] || mv "$backup/UTUBE MAC.app" "$app"
    [[ "$scripts_moved" != true ]] || mv "$backup/scripts" "$support/scripts"
    if [[ -f "$backup/previous-version.txt" ]]; then cp "$backup/previous-version.txt" "$current_file"; fi
    echo 'Installation did not finish. Previous app/runtime restored; personal data untouched.'
  fi
  rmdir "$lock" || true
  exit "$result"
}
trap cleanup EXIT
trap 'exit 130' INT TERM
mkdir -p "$stage/scripts"
[[ ! -d "$support/scripts" ]] || /usr/bin/ditto "$support/scripts" "$stage/scripts"
/usr/bin/ditto "$package/payload/scripts" "$stage/scripts"
/usr/bin/ditto "$package/payload/app/UTUBE MAC.app" "$app_stage/UTUBE MAC.app"
[[ ! -f "$current_file" ]] || cp "$current_file" "$backup/previous-version.txt"
cp "$package/package.json" "$backup/installed-package.json"
# Keep a complete recovery package (including engine and inventory), not user settings.
/usr/bin/ditto "$package" "$backup/package"
if [[ -z "$test_root" ]]; then
  # Stop only this user's exact dashboard command, after explicit installation consent.
  while read -r pid; do
    command="$(/bin/ps -p "$pid" -o command=)"
    [[ "$command" == *"$support/scripts/utube_developer_console.py" ]] || die 'Unexpected dashboard process.'
    kill -TERM "$pid"
  done < <(/usr/bin/pgrep -u "$(id -u)" -f "$support/scripts/utube_developer_console.py" || true)
fi
if [[ -d "$app" ]]; then mv "$app" "$backup/UTUBE MAC.app"; app_moved=true; fi
if [[ -d "$support/scripts" ]]; then mv "$support/scripts" "$backup/scripts"; scripts_moved=true; fi
mv "$app_stage/UTUBE MAC.app" "$app"; new_app=true
mv "$stage/scripts" "$support/scripts"; new_scripts=true
if [[ -n "$test_root" && "${UTUBE_TEST_FAIL_AFTER_SWAP:-}" == 1 ]]; then die 'Injected test failure.'; fi
printf '%s\n' "$version" > "$stage/version.txt"
mv "$stage/version.txt" "$current_file"
committed=true
echo "UTUBE MAC $version installed. Recovery files: $backup"
[[ -n "$test_root" ]] || /usr/bin/open "$app"
