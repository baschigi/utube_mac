#!/bin/bash
set -euo pipefail
support_directory="$HOME/Library/Application Support/UTUBE-MAC"
console_file="$support_directory/scripts/utube_developer_console.py"
runtime_directory="$support_directory/Runtime"
log_file="$runtime_directory/ui.log"
mkdir -p "$runtime_directory"

# Homebrew's exact Python version changes between macOS releases.  Look for
# its stable python3 command first, then fall back to other standard paths.
python_bin=""
for candidate in /opt/homebrew/bin/python3 /usr/local/bin/python3 /usr/bin/python3; do
  if [[ -x "$candidate" ]]; then
    python_bin="$candidate"
    break
  fi
done

if ! /usr/sbin/lsof -nP -iTCP:8765 -sTCP:LISTEN >/dev/null 2>&1; then
  if [[ ! -f "$console_file" || -z "$python_bin" ]]; then
    printf '%s  UTUBE MAC could not start: Python or the UI file is missing.\n' "$(date '+%Y-%m-%d %H:%M:%S')" >> "$log_file"
    exit 1
  fi
  nohup "$python_bin" "$console_file" >> "$log_file" 2>&1 &
  for _ in {1..25}; do
    /usr/sbin/lsof -nP -iTCP:8765 -sTCP:LISTEN >/dev/null 2>&1 && break
    sleep 0.2
  done
fi

if ! /usr/sbin/lsof -nP -iTCP:8765 -sTCP:LISTEN >/dev/null 2>&1; then
  printf '%s  UTUBE MAC server did not become ready.\n' "$(date '+%Y-%m-%d %H:%M:%S')" >> "$log_file"
  exit 1
fi

if [[ "${1:-}" != "--serve" ]]; then
  open "http://127.0.0.1:8765/" || true
fi
