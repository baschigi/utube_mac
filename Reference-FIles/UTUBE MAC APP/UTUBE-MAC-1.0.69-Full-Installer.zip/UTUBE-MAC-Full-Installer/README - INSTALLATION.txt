UTUBE MAC Full Installer Package
Version: 1.0.69

How to install it on another Mac:

1. Unzip the file.
2. Double-click "Install.command".
3. If macOS shows a security warning: right-click it and choose "Open".

What gets installed:

- UTUBE MAC.app to:
  ~/Applications/UTUBE MAC.app

- Support files to:
  ~/Library/Application Support/UTUBE-MAC

Optional Dock setup:
The installer can add UTUBE MAC to the Dock when dockutil is available.
If not, open UTUBE MAC, right-click the Dock icon, then choose:
Options → Keep in Dock

Manual install folder:
The package also contains:
"Manual Install - Drag App To Applications"

Use it only as fallback. The automatic Install.command is recommended,
because the app also needs the Application Support files.

The app alone is only a wrapper. The support files are required too.
