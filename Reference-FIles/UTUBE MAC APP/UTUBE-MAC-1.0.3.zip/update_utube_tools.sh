#!/bin/bash
# Last updated: 11 September 2026 · 19:28 CEST
# UI updates are independent from Shortcut versions.
set -euo pipefail

local_version_file="$HOME/Library/Application Support/UTUBE-MAC/Settings/General/utube-mac-version.txt"
current_version="$(tr -d '[:space:]' < "$local_version_file" 2>/dev/null || true)"
if [[ ! "$current_version" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
  osascript -e 'display notification "Lokale Versionsnummer fehlt. Bitte UTUBE MAC einmal starten." with title "UTUBE MAC"'
  exit 0
fi
github_repository_archive="https://github.com/baschigi/utube_mac/archive/refs/heads/main.zip"
github_raw_root="https://raw.githubusercontent.com/baschigi/utube_mac/main"
github_repository_directory="$HOME/Library/Application Support/UTUBE-MAC/GitHub Repository"
shortcut_history_directory="$HOME/Library/Application Support/UTUBE-MAC/History/Shortcut Versions"
instructions_url="$github_raw_root/Reference-FIles/update-instructions-de.txt"

version_is_newer() {
  awk -v installed="$1" -v available="$2" '
    BEGIN {
      split(installed, installed_parts, ".")
      split(available, available_parts, ".")
      for (part = 1; part <= 3; part++) {
        old = installed_parts[part] + 0
        new = available_parts[part] + 0
        if (new > old) exit 0
        if (new < old) exit 1
      }
      exit 1
    }
  '
}

sync_shortcut_history() {
  local temporary_directory
  local repository_zip
  local extracted_directory
  local repository_root
  local remote_shortcut_versions
  local remote_version_file

  temporary_directory="$(mktemp -d "${TMPDIR:-/tmp}/utube-shortcut-history.XXXXXX")" || return 1
  repository_zip="$temporary_directory/utube-mac-main.zip"
  extracted_directory="$temporary_directory/extracted"
  mkdir -p "$extracted_directory"

  if ! curl -fsSL --max-time 60 "$github_repository_archive?check=$(date +%s)" -o "$repository_zip"; then
    rm -rf -- "$temporary_directory"
    return 1
  fi

  if ! /usr/bin/ditto -x -k "$repository_zip" "$extracted_directory"; then
    rm -rf -- "$temporary_directory"
    return 1
  fi

  repository_root="$(find "$extracted_directory" -mindepth 1 -maxdepth 1 -type d -print -quit)"
  remote_shortcut_versions="$repository_root/Shortcut Versions"
  if [[ -z "$repository_root" || ! -d "$remote_shortcut_versions" ]]; then
    rm -rf -- "$temporary_directory"
    return 1
  fi

  # Read available releases exclusively from this newly downloaded GitHub
  # snapshot.  The local history is intentionally cumulative, so it can retain
  # retired test folders such as 99.0.0 and must never determine availability.
  latest_version=""
  while IFS= read -r remote_version_file; do
    remote_version_name="$(basename "$remote_version_file")"
    if [[ "$remote_version_name" =~ ^UTUBE[[:space:]]MAC[[:space:]]([0-9]+\.[0-9]+\.[0-9]+)$ ]]; then
      candidate_version="${BASH_REMATCH[1]}"
      if [[ -z "$latest_version" ]] || version_is_newer "$latest_version" "$candidate_version"; then
        latest_version="$candidate_version"
      fi
    fi
  done < <(find "$remote_shortcut_versions" -mindepth 1 -maxdepth 1 -type d -print 2>/dev/null)

  mkdir -p "$github_repository_directory" "$shortcut_history_directory"

  # Preserve every tracked file and folder from the current main branch.
  if ! /usr/bin/ditto "$repository_root" "$github_repository_directory"; then
    rm -rf -- "$temporary_directory"
    return 1
  fi

  # ditto merges the GitHub folder into the local history. It adds new
  # versions and refreshes matching files, but it does not delete older local
  # version folders if they are later removed from GitHub.
  if ! /usr/bin/ditto "$remote_shortcut_versions" "$shortcut_history_directory"; then
    rm -rf -- "$temporary_directory"
    return 1
  fi

  rm -rf -- "$temporary_directory"
  return 0
}

install_latest_ui_release() {
  local temporary_directory repository_zip extracted_directory repository_root package_directory
  local package_candidate package_name package_version latest_version="" latest_package=""
  local unpacked_package script_name app_bundle old_app_pids old_server_pids
  local -a required_scripts=(utube_developer_console.py UTUBE-MAC-App.m build_utube_mac_app.sh open_utube_dashboard.sh update_utube_tools.sh)

  temporary_directory="$(mktemp -d "${TMPDIR:-/tmp}/utube-ui-update.XXXXXX")" || return 1
  repository_zip="$temporary_directory/utube-mac-main.zip"
  extracted_directory="$temporary_directory/extracted"
  mkdir -p "$extracted_directory"
  curl -fsSL --max-time 60 "$github_repository_archive?check=$(date +%s)" -o "$repository_zip" || return 1
  /usr/bin/ditto -x -k "$repository_zip" "$extracted_directory" || return 1
  repository_root="$(find "$extracted_directory" -mindepth 1 -maxdepth 1 -type d -print -quit)"
  package_directory="$repository_root/Reference-FIles/UTUBE MAC APP"
  [[ -d "$package_directory" ]] || return 1

  # Availability is calculated from this freshly downloaded GitHub directory
  # only.  Old Application Support or Shortcut History folders never count.
  for package_candidate in "$package_directory"/UTUBE-MAC-*.zip; do
    [[ -f "$package_candidate" ]] || continue
    package_name="$(basename "$package_candidate")"
    [[ "$package_name" =~ ^UTUBE-MAC-([0-9]+(\.[0-9]+){1,3})\.zip$ ]] || continue
    package_version="${BASH_REMATCH[1]}"
    if [[ -z "$latest_version" ]] || version_is_newer "$latest_version" "$package_version"; then
      latest_version="$package_version"
      latest_package="$package_candidate"
    fi
  done
  [[ -n "$latest_version" ]] || return 1
  if ! version_is_newer "$current_version" "$latest_version"; then
    printf 'UI_CURRENT\n'
    return 0
  fi

  choice="$(osascript - "$current_version" "$latest_version" <<'UI_UPDATE_DIALOG_EOF'
on run argv
  display dialog "Ein UI-Update ist verfügbar." & return & return & "Installiert: " & item 1 of argv & return & "Verfügbar: " & item 2 of argv & return & return & "Nur die UTUBE-MAC-Oberfläche wird aktualisiert. Dein Kurzbefehl bleibt unverändert." with title "UTUBE MAC – UI-Update" buttons {"Später", "UI-Update installieren"} default button "UI-Update installieren" with icon note
end run
UI_UPDATE_DIALOG_EOF
)"
  [[ "$choice" == *"UI-Update installieren"* ]] || { printf 'UI_LATER\n'; return 0; }

  unpacked_package="$temporary_directory/ui-package"
  /usr/bin/ditto -x -k "$latest_package" "$unpacked_package" || return 1
  for script_name in "${required_scripts[@]}"; do [[ -f "$unpacked_package/$script_name" ]] || return 1; done
  for script_name in "${required_scripts[@]}"; do /usr/bin/ditto "$unpacked_package/$script_name" "$HOME/Library/Application Support/UTUBE-MAC/scripts/$script_name"; chmod 755 "$HOME/Library/Application Support/UTUBE-MAC/scripts/$script_name"; done
  printf '%s\n' "$latest_version" > "$local_version_file"
  app_bundle="$(/bin/bash "$HOME/Library/Application Support/UTUBE-MAC/scripts/build_utube_mac_app.sh")" || return 1
  old_app_pids="$(pgrep -f '/Applications/UTUBE MAC.app/Contents/MacOS/UTUBE MAC' || true)"; [[ -z "$old_app_pids" ]] || kill $old_app_pids || true
  old_server_pids="$(lsof -tiTCP:8765 -sTCP:LISTEN 2>/dev/null || true)"; [[ -z "$old_server_pids" ]] || kill $old_server_pids || true
  open -n "$app_bundle"
  osascript -e 'display notification "UI-Update wurde installiert und UTUBE MAC neu geöffnet." with title "UTUBE MAC"' || true
  printf 'UI_UPDATED\n'
}

ui_update_result="$(install_latest_ui_release || printf 'UI_CHECK_FAILED')"
case "$ui_update_result" in
  *UI_UPDATED*) exit 0 ;;
  *UI_LATER*) exit 0 ;;
  *UI_CHECK_FAILED*) osascript -e 'display notification "GitHub-UI-Paket konnte nicht geprüft werden." with title "UTUBE MAC"' || true ;;
esac

if command -v brew >/dev/null 2>&1; then
  brew_path="$(command -v brew)"
elif [[ -x /opt/homebrew/bin/brew ]]; then
  brew_path="/opt/homebrew/bin/brew"
elif [[ -x /usr/local/bin/brew ]]; then
  brew_path="/usr/local/bin/brew"
else
  printf 'Homebrew ist nicht installiert. Bitte zuerst Einrichten auswählen.\n'
  exit 69
fi

eval "$("$brew_path" shellenv)"
"$brew_path" update
"$brew_path" upgrade yt-dlp ffmpeg beets chromaprint

beets_python="$("$brew_path" --prefix beets)/libexec/bin/python"
"$beets_python" -m pip install --user --upgrade pyacoustid

osascript -e 'display dialog "Alles aktuell — UTUBE MAC und seine Tools sind bereit." with title "UTUBE MAC" buttons {"OK"} default button "OK" with icon note'
snapshot_script="$HOME/Library/Application Support/UTUBE-MAC/scripts/snapshot_utube_scripts.sh"
[[ -x "$snapshot_script" ]] && "$snapshot_script" >/dev/null || true
