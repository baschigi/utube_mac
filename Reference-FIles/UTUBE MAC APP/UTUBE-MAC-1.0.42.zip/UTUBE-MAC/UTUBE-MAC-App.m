#import <Cocoa/Cocoa.h>
#import <WebKit/WebKit.h>
#import <mpv/client.h>
#import <mpv/render.h>

@interface MPVCanvas : NSView
- (void)openFile:(NSString *)path;
- (void)togglePause;
- (void)seek:(int)seconds;
@end

@implementation MPVCanvas {
  mpv_handle *_mpv;
  mpv_render_context *_renderer;
  NSTimer *_timer;
  NSMutableData *_pixels;
  BOOL _paused;
}
- (instancetype)initWithFrame:(NSRect)frame {
  if ((self = [super initWithFrame:frame])) {
    self.wantsLayer = YES;
    self.layer.backgroundColor = NSColor.blackColor.CGColor;
    _mpv = mpv_create();
    mpv_set_option_string(_mpv, "vo", "libmpv");
    mpv_set_option_string(_mpv, "hwdec", "auto-safe");
    mpv_set_option_string(_mpv, "keep-open", "no");
    mpv_set_option_string(_mpv, "osc", "no");
    mpv_initialize(_mpv);
    mpv_render_param parameters[] = {
      { MPV_RENDER_PARAM_API_TYPE, (void *)MPV_RENDER_API_TYPE_SW },
      { 0, NULL }
    };
    mpv_render_context_create(&_renderer, _mpv, parameters);
    _timer = [NSTimer scheduledTimerWithTimeInterval:1.0/60.0 target:self selector:@selector(renderFrame) userInfo:nil repeats:YES];
  }
  return self;
}
- (void)openFile:(NSString *)path {
  const char *command[] = { "loadfile", path.fileSystemRepresentation, "replace", NULL };
  mpv_command_async(_mpv, 0, command);
  _paused = NO;
}
- (void)togglePause {
  const char *command[] = { "cycle", "pause", NULL };
  mpv_command_async(_mpv, 0, command); _paused = !_paused;
}
- (void)seek:(int)seconds {
  NSString *amount = [NSString stringWithFormat:@"%d", seconds];
  const char *command[] = { "seek", amount.UTF8String, "relative", NULL };
  mpv_command_async(_mpv, 0, command);
}
- (void)renderFrame {
  if (!_renderer || self.bounds.size.width < 2 || self.bounds.size.height < 2) return;
  CGFloat scale = self.window.backingScaleFactor ?: 1.0;
  int width = MAX(2, (int)lrint(self.bounds.size.width * scale));
  int height = MAX(2, (int)lrint(self.bounds.size.height * scale));
  size_t stride = ((size_t)width * 4 + 63) & ~((size_t)63);
  NSUInteger needed = stride * (size_t)height;
  if (!_pixels || _pixels.length != needed) _pixels = [NSMutableData dataWithLength:needed];
  int size[] = { width, height };
  char format[] = "rgb0";
  mpv_render_param parameters[] = {
    { MPV_RENDER_PARAM_SW_SIZE, size },
    { MPV_RENDER_PARAM_SW_FORMAT, format },
    { MPV_RENDER_PARAM_SW_STRIDE, &stride },
    { MPV_RENDER_PARAM_SW_POINTER, _pixels.mutableBytes },
    { MPV_RENDER_PARAM_FLIP_Y, &(int){1} },
    { 0, NULL }
  };
  mpv_render_context_render(_renderer, parameters);
  [self setNeedsDisplay:YES];
}
- (void)drawRect:(NSRect)dirtyRect {
  [super drawRect:dirtyRect]; if (!_pixels) return;
  CGFloat scale = self.window.backingScaleFactor ?: 1.0;
  size_t width = MAX(2, (size_t)lrint(self.bounds.size.width * scale));
  size_t height = MAX(2, (size_t)lrint(self.bounds.size.height * scale));
  size_t stride = ((width * 4 + 63) & ~((size_t)63));
  CGColorSpaceRef space = CGColorSpaceCreateDeviceRGB();
  CGDataProviderRef provider = CGDataProviderCreateWithData(NULL, _pixels.bytes, _pixels.length, NULL);
  CGImageRef image = CGImageCreate(width, height, 8, 32, stride, space, kCGImageAlphaNoneSkipLast | kCGBitmapByteOrderDefault, provider, NULL, false, kCGRenderingIntentDefault);
  CGContextDrawImage(NSGraphicsContext.currentContext.CGContext, self.bounds, image);
  CGImageRelease(image); CGDataProviderRelease(provider); CGColorSpaceRelease(space);
}
- (void)mouseDown:(NSEvent *)event { [self togglePause]; }
- (void)dealloc { [_timer invalidate]; if (_renderer) mpv_render_context_free(_renderer); if (_mpv) mpv_terminate_destroy(_mpv); }
@end

@interface AppDelegate : NSObject <NSApplicationDelegate, NSWindowDelegate, WKScriptMessageHandler>
@property NSWindow *window; @property WKWebView *web; @property NSView *root; @property NSView *playerOverlay; @property MPVCanvas *player;
@end

@implementation AppDelegate
- (void)applicationDidFinishLaunching:(NSNotification *)notification {
  NSString *launcher = [NSHomeDirectory() stringByAppendingPathComponent:@"Library/Application Support/UTUBE-MAC/scripts/open_utube_dashboard.sh"];
  NSTask *task = [NSTask new]; task.launchPath = @"/bin/bash"; task.arguments = @[launcher, @"--serve"]; [task launch];
  WKWebViewConfiguration *configuration = [WKWebViewConfiguration new]; [configuration.userContentController addScriptMessageHandler:self name:@"nativePlayer"];
  _web = [[WKWebView alloc] initWithFrame:NSZeroRect configuration:configuration];
  _root = [NSView new]; _web.frame = _root.bounds; _web.autoresizingMask = NSViewWidthSizable|NSViewHeightSizable; [_root addSubview:_web];
  _window = [[NSWindow alloc] initWithContentRect:NSMakeRect(0,0,1320,860) styleMask:(NSWindowStyleMaskTitled|NSWindowStyleMaskClosable|NSWindowStyleMaskMiniaturizable|NSWindowStyleMaskResizable) backing:NSBackingStoreBuffered defer:NO];
  _window.title = @"UTUBE MAC"; _window.titleVisibility = NSWindowTitleHidden; _window.titlebarAppearsTransparent = YES; _window.minSize = NSMakeSize(980, 620); _window.delegate = self;
  [_window setFrameAutosaveName:@"UTUBE-MAC-MainWindow"];
  if (![_window setFrameUsingName:@"UTUBE-MAC-MainWindow"]) [_window center];
  _window.contentView = _root; [_window makeKeyAndOrderFront:nil]; [NSApp activateIgnoringOtherApps:YES];
  dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5*NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ [self.web loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"http://127.0.0.1:8765/"]]]; });
}
- (void)windowDidMove:(NSNotification *)notification {
  NSScreen *screen = self.window.screen ?: NSScreen.mainScreen;
  if (!screen) return;
  NSRect visible = screen.visibleFrame, frame = self.window.frame;
  CGFloat minimumVisibleWidth = MIN(360.0, frame.size.width);
  CGFloat minimumVisibleHeight = MIN(180.0, frame.size.height);
  CGFloat minX = NSMinX(visible) - frame.size.width + minimumVisibleWidth;
  CGFloat maxX = NSMaxX(visible) - minimumVisibleWidth;
  CGFloat minY = NSMinY(visible) - frame.size.height + minimumVisibleHeight;
  CGFloat maxY = NSMaxY(visible) - minimumVisibleHeight;
  NSPoint safeOrigin = NSMakePoint(MIN(MAX(frame.origin.x, minX), maxX), MIN(MAX(frame.origin.y, minY), maxY));
  if (!NSEqualPoints(safeOrigin, frame.origin)) [self.window setFrameOrigin:safeOrigin];
  [self.window saveFrameUsingName:@"UTUBE-MAC-MainWindow"];
}
- (NSButton *)button:(NSString *)title action:(SEL)action {
  NSButton *button = [NSButton buttonWithTitle:title target:self action:action]; button.bezelStyle = NSBezelStyleTexturedRounded; button.font = [NSFont systemFontOfSize:13 weight:NSFontWeightSemibold]; return button;
}
- (void)showPlayer:(NSString *)path {
  [self closePlayer];
  _playerOverlay = [[NSView alloc] initWithFrame:_root.bounds]; _playerOverlay.autoresizingMask = NSViewWidthSizable|NSViewHeightSizable; _playerOverlay.wantsLayer = YES; _playerOverlay.layer.backgroundColor = NSColor.blackColor.CGColor;
  _player = [[MPVCanvas alloc] initWithFrame:_playerOverlay.bounds]; _player.autoresizingMask = NSViewWidthSizable|NSViewHeightSizable; [_playerOverlay addSubview:_player];
  NSVisualEffectView *controls = [[NSVisualEffectView alloc] initWithFrame:NSMakeRect(0, 0, _playerOverlay.bounds.size.width, 52)]; controls.autoresizingMask = NSViewWidthSizable|NSViewMaxYMargin; controls.material = NSVisualEffectMaterialHUDWindow; controls.blendingMode = NSVisualEffectBlendingModeWithinWindow;
  NSArray *buttons = @[[self button:@"↶ 10 s" action:@selector(backward:)], [self button:@"Pause / Start" action:@selector(toggle:)], [self button:@"10 s ↷" action:@selector(forward:)], [self button:@"Kino schließen" action:@selector(close:)]];
  CGFloat x = 18; for (NSButton *button in buttons) { button.frame = NSMakeRect(x, 11, button.title.length > 10 ? 124 : 92, 30); [controls addSubview:button]; x += button.frame.size.width + 10; }
  [_playerOverlay addSubview:controls]; [_root addSubview:_playerOverlay]; [_player openFile:path];
}
- (void)closePlayer { [_playerOverlay removeFromSuperview]; _playerOverlay=nil; _player=nil; }
- (void)toggle:(id)sender { [_player togglePause]; } - (void)backward:(id)sender { [_player seek:-10]; } - (void)forward:(id)sender { [_player seek:10]; }
- (void)close:(id)sender { [self closePlayer]; [_web evaluateJavaScript:@"window.utubeNativeClosed&&window.utubeNativeClosed()" completionHandler:nil]; }
- (void)userContentController:(WKUserContentController *)controller didReceiveScriptMessage:(WKScriptMessage *)message {
  NSDictionary *payload = [message.body isKindOfClass:NSDictionary.class] ? message.body : nil; if (![message.name isEqualToString:@"nativePlayer"] || !payload) return;
  if ([payload[@"action"] isEqual:@"close"]) { [self close:nil]; return; }
  NSString *path = payload[@"path"]; if ([payload[@"action"] isEqual:@"play"] && path.length && [[NSFileManager defaultManager] fileExistsAtPath:path]) [self showPlayer:path];
}
- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)sender { return YES; }
@end

int main(int argc, const char * argv[]) { @autoreleasepool { NSApplication *app = NSApplication.sharedApplication; AppDelegate *delegate = [AppDelegate new]; app.delegate = delegate; [app setActivationPolicy:NSApplicationActivationPolicyRegular]; [app run]; } return 0; }
