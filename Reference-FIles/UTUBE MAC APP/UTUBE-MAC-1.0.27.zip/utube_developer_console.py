#!/usr/bin/env python3
# Last updated: 11. September 2026 · 22:16 CEST
import html
import hashlib
import json
import mimetypes
import os
import re
import shutil
import shlex
import signal
import subprocess
import threading
import time
import urllib.parse
import urllib.request
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

SUPPORT = Path.home() / "Library/Application Support/UTUBE-MAC"
SCRIPTS = SUPPORT / "scripts"
LOGS = SUPPORT / "History/Logs"
GENERAL = SUPPORT / "Settings/General"
DOWNLOADS = Path((GENERAL / "downloads_directory.txt").read_text().strip()) if (GENERAL / "downloads_directory.txt").exists() else Path.home() / "Downloads/UTUBE-MAC"
INSTALLER = SCRIPTS / "install_utube_tools.sh"
UPDATER = SCRIPTS / "update_utube_tools.sh"
DOWNLOADER = SCRIPTS / "utube_media_download.sh"
HISTORY = SUPPORT / "History"
SCRIPT_HISTORY = HISTORY / "Script History"
SHORTCUT_HISTORY = HISTORY / "Shortcut Versions"
SETTINGS = SUPPORT / "Settings"
EVENT_LOG = HISTORY / "Event Center.jsonl"
PROBLEM_REPORTS = SUPPORT / "Problem Reports"
RUNTIME = SUPPORT / "Runtime"
REPOSITORY = SUPPORT / "GitHub Repository"
DOWNLOAD_HISTORY = HISTORY / "Download History" / "DOWNLOAD-HISTORY.txt"
MEDIA_SOURCE_INDEX = HISTORY / "Download History" / "MEDIA-SOURCE-INDEX.tsv"
LIBRARY_METADATA = SETTINGS / "Library Metadata.json"
SAFARI_EXTENSION = SUPPORT / "Safari Extension"
# UI releases are independent from Shortcut releases.  Only this GitHub
# directory determines whether a newer UI package exists.
REMOTE_UI_PACKAGES_URL = "https://api.github.com/repos/baschigi/utube_mac/contents/Reference-FIles/UTUBE%20MAC%20APP"
LIBRARIES_FILE = GENERAL / "download-libraries.json"
DEFAULT_LIBRARY = Path.home() / "Downloads/UTUBE-MAC"
APPLE_MUSIC_LIBRARY = Path.home() / "Music/Music/Media.localized/Automatically Add to Music.localized"
PROTECTED_LIBRARIES = {str(DEFAULT_LIBRARY), str(APPLE_MUSIC_LIBRARY)}
PLAYLIST_COUNT_CACHE = {}
MEDIA_KIND_CACHE = {}
MEDIA_SOURCE_URL_CACHE = {}
MEDIA_OPTIMIZATION_RUNNING = set()

def make_program_backup():
    """Archive only the UTUBE MAC app and its scripts, never user media."""
    backup_root = HISTORY / "Backups"
    backup_root.mkdir(parents=True, exist_ok=True)
    archive = backup_root / f"UTUBE-MAC-program-backup-{time.strftime('%Y%m%d-%H%M%S')}.zip"
    app_bundle = Path.home() / "Applications/UTUBE MAC.app"
    sources = [(SCRIPTS, "UTUBE-MAC/scripts"), (app_bundle, "UTUBE-MAC/UTUBE MAC.app")]
    try:
        with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as bundle:
            for source, prefix in sources:
                if not source.exists():
                    continue
                for item in source.rglob("*"):
                    if item.is_file() and not item.name.startswith(".DS_Store"):
                        bundle.write(item, str(Path(prefix) / item.relative_to(source)))
        return archive if archive.exists() else None
    except OSError:
        return None

def open_targets():
    targets = {
        "support": SUPPORT, "scripts": SCRIPTS, "settings": SETTINGS, "history": HISTORY,
        "logs": LOGS, "script-history": SCRIPT_HISTORY, "shortcut-history": SHORTCUT_HISTORY,
        "repository": REPOSITORY, "runtime": RUNTIME, "temp": SUPPORT / "Temp",
        "downloads": DOWNLOADS, "dashboard": SUPPORT / "Developer Dashboard", "safari-extension": SAFARI_EXTENSION,
        "backups": HISTORY / "Backups", "reports": PROBLEM_REPORTS,
    }
    for folder in [SHORTCUT_HISTORY, SCRIPT_HISTORY]:
        if folder.exists():
            for item in folder.iterdir():
                if item.is_dir(): targets[f"version-{item.name}"] = item
    return targets

def safe_target_item(target, relative=""):
    root = open_targets().get(target)
    if not root: return None
    try:
        path = (root / relative).resolve()
        path.relative_to(root.resolve())
        return path if path.exists() else None
    except Exception: return None

def file_browser_page(target, relative=""):
    root = open_targets().get(target); path = safe_target_item(target, relative)
    if not root or not path: return layout("UTUBE MAC – Dateizentrale", "Der angefragte Ordner ist nicht verfügbar.", '<section class="panel"><a href="/developer">← Zur Entwicklung</a></section>')
    if path.name == "DOWNLOAD-HISTORY.txt": return download_history_page(path, target, relative)
    back = urllib.parse.quote(str(Path(relative).parent)) if relative else ""
    heading = path.name if relative else next((name for name, key in [("UTUBE MAC – Application Support", "support"), ("Skripte", "scripts"), ("Einstellungen", "settings"), ("Gesamte Historie", "history"), ("Setup-Berichte", "logs"), ("Skript-Historie", "script-history"), ("Shortcut-Versionen", "shortcut-history")] if key == target), root.name)
    if path.is_dir():
        entries = []
        for item in sorted(path.iterdir(), key=lambda item: (not item.is_dir(), item.name.lower())):
            if item.name.startswith("."): continue
            child = str(Path(relative) / item.name) if relative else item.name
            icon = "Ordner" if item.is_dir() else (item.suffix.upper()[1:] or "Datei")
            entries.append(f'<a class="file-entry" href="/browse?target={urllib.parse.quote(target)}&path={urllib.parse.quote(child)}"><span><b>{html.escape(item.name)}</b><small>{icon}</small></span><span>›</span></a>')
        body = f'<section class="panel"><a href="/developer">← Zur Entwicklung</a><h2>{html.escape(heading)}</h2><p class="sub">Dateien zuerst direkt in UTUBE MAC ansehen.</p><div class="file-list">{"".join(entries) or "<p class=\"sub\">Dieser Ordner ist leer.</p>"}</div></section>'
        return layout("UTUBE MAC – Dateizentrale", "Lokale Dateien und Versionen in der App ansehen.", body)
    is_text = path.suffix.lower() in {".txt", ".log", ".sh", ".py", ".md", ".json", ".yaml", ".yml", ""} and path.stat().st_size <= 350000
    preview = html.escape(path.read_text(errors="replace")) if is_text else "Für diesen Dateityp ist keine Textvorschau verfügbar."
    controls = f'<div class="actions"><a class="folder" href="/browse?target={urllib.parse.quote(target)}&path={back}">← Zum Ordner</a><a class="folder" href="/reveal-file?target={urllib.parse.quote(target)}&path={urllib.parse.quote(relative)}">Im Finder zeigen</a>'
    if path.suffix.lower() == ".shortcut": controls += f'<a class="folder" href="/launch-file?target={urllib.parse.quote(target)}&path={urllib.parse.quote(relative)}">Kurzbefehl hinzufügen</a>'
    controls += "</div>"
    log_summary = ""
    if path.suffix.lower() == ".log" and is_text:
        lines = [line.strip() for line in path.read_text(errors="replace").splitlines() if line.strip()]
        state = "Abgeschlossen" if any(word in " ".join(lines).lower() for word in ("fertig", "completed", "erfolgreich")) else "Protokoll"
        log_summary = f'<section class="grid">{card("Protokollstatus", state)}{card("Einträge", str(len(lines)))}{card("Letzte Änderung", time.strftime("%d.%m.%Y · %H:%M", time.localtime(path.stat().st_mtime)))}</section>'
    return layout("UTUBE MAC – Datei", "Vorschau aus deiner lokalen UTUBE-MAC-Dateizentrale.", f'{log_summary}<section class="panel"><h2>{html.escape(path.name)}</h2>{controls}<pre class="code-preview">{preview}</pre></section>')

def history_field(block, name):
    match = re.search(rf"^\s*{re.escape(name)}:\s*(.+)$", block, flags=re.MULTILINE)
    return match.group(1).strip() if match else ""

def download_history_page(history, target, relative):
    raw = history.read_text(errors="replace")
    entries = []
    for block in re.split(r"\nMEDIA FILE \d+\n", raw)[1:]:
        file_path, title, url = history_field(block, "File"), history_field(block, "Title"), history_field(block, "URL")
        if not file_path or not title: continue
        media = safe_media(file_path); fmt = history_field(block, "Format") or (Path(file_path).suffix[1:].upper())
        size = history_field(block, "File size"); modified = history_field(block, "File modified")
        thumbnail = thumbnail_for(Path(file_path), url)
        poster = f' poster="{html.escape(thumbnail, quote=True)}"' if thumbnail else ""
        if media and media.suffix.lower() in {".mp3", ".m4a", ".opus", ".flac", ".aac", ".ogg"}: player = f'<audio controls src="{media_url(media)}"></audio>'
        elif media: player = f'<video controls preload="metadata"{poster} src="{media_url(media)}"></video>'
        elif thumbnail: player = f'<img class="audio-art" src="{html.escape(thumbnail, quote=True)}" alt="Vorschaubild">'
        else: player = '<div class="missing-preview">Datei nicht mehr am gespeicherten Ort</div>'
        local_button = f'<a class="folder" href="/library">Lokal abspielen</a>' if media else '<span class="hint">Lokale Datei nicht gefunden</span>'
        youtube_button = f'<a class="folder" target="_blank" rel="noopener" href="{html.escape(url, quote=True)}">Auf YouTube öffnen</a>' if url.startswith("http") else ""
        try:
            sort_size = media.stat().st_size if media else int(float(re.search(r"[0-9.]+", size or "0").group()) * (1024 ** 2 if "MB" in size.upper() else 1024 ** 3 if "GB" in size.upper() else 1024))
        except Exception:
            sort_size = 0
        try:
            sort_date = media.stat().st_mtime if media else 0
        except OSError:
            sort_date = 0
        availability = "Lokal verfügbar" if media else "Datei nicht gefunden"
        entries.append(f'<article class="media-card media-{fmt.lower()}" data-history-size="{sort_size}" data-history-date="{sort_date}" data-history-title="{html.escape(title.casefold(), quote=True)}">{player}<span class="type-badge {fmt.lower()}">{html.escape(fmt)}</span><b>{html.escape(title)}</b><small>{html.escape(size) or "Größe unbekannt"} · {html.escape(modified) or "Datum unbekannt"}</small><small class="hint">{availability} · {html.escape(fmt)}</small><div class="actions compact">{local_button}{youtube_button}<a class="folder" href="/reveal?path={urllib.parse.quote(file_path)}">Im Finder zeigen</a></div></article>')
    successful = raw.count("Result: Completed") + raw.count("Recovered existing media files")
    controls = '''<div class="actions"><label class="hint" for="history-sort">Sortieren:</label><select id="history-sort" aria-label="Download-Verlauf sortieren"><option value="date">Neueste zuerst</option><option value="size">Größte Dateien zuerst</option><option value="title">Titel A–Z</option></select></div>'''
    history_script = '''<script>document.getElementById('history-sort')?.addEventListener('change',event=>{let grid=document.getElementById('history-grid'),cards=[...grid.querySelectorAll('[data-history-title]')],by=event.target.value;cards.sort((a,b)=>by==='title'?a.dataset.historyTitle.localeCompare(b.dataset.historyTitle,'de'):Number(b.dataset['history'+(by==='date'?'Date':'Size')])-Number(a.dataset['history'+(by==='date'?'Date':'Size')]));cards.forEach(card=>grid.appendChild(card))})</script>'''
    body = f'<section class="grid">{card("Historische Medien", str(len(entries)))}{card("Erfolgreiche Durchläufe", str(successful))}</section><section class="panel"><a href="/browse?target={urllib.parse.quote(target)}&path={urllib.parse.quote(str(Path(relative).parent))}">← Zum Ordner</a><h2>Download-Verlauf als Mediathek</h2><p class="sub">Gespeicherte Quellen, lokale Dateien, Format, Größe und Datum auf einen Blick.</p>{controls}<div class="media-grid" id="history-grid">{"".join(entries) or "<p class=\"sub\">Noch keine Medien im Verlauf gefunden.</p>"}</div></section>{history_script}'
    return layout("UTUBE MAC – Download-Verlauf", "Interaktive Übersicht deiner UTUBE-MAC-Medien.", body)

def download_activity_timeline():
    """Human-friendly timeline of complete download runs, including failures."""
    raw = DOWNLOAD_HISTORY.read_text(errors="replace") if DOWNLOAD_HISTORY.exists() else ""
    cards = []
    for block in [part.strip() for part in raw.split("------------------------------------------------------------") if "Result:" in part]:
        result = history_field(block, "Result") or "Unbekannt"
        title = history_field(block, "Title") or "Unbenannter Download"
        date = history_field(block, "Date") or "Datum unbekannt"
        mode, url = history_field(block, "Mode"), history_field(block, "URL")
        destination = history_field(block, "Destination")
        lowered = result.casefold()
        state = "completed" if "completed" in lowered or "erfolg" in lowered else "failed" if "failed" in lowered or "incomplete" in lowered else "cancelled" if "cancel" in lowered else "other"
        icon = {"completed": "✓", "failed": "⚠", "cancelled": "⊘", "other": "ⓘ"}[state]
        source = f'<a class="folder" target="_blank" rel="noopener" href="{html.escape(url, quote=True)}">YouTube öffnen</a>' if url.startswith("http") else ""
        cards.append(f'<article class="file-row history-run" data-state="{state}" data-search="{html.escape((title+" "+mode+" "+result).casefold(), quote=True)}"><div><b>{icon} {html.escape(title)}</b><small>{html.escape(date)} · {html.escape(mode or "Download")}</small><small>{html.escape(result)}{(" · " + html.escape(destination)) if destination else ""}</small></div><div class="row-actions">{source}<a class="folder" href="/library">Mediathek</a></div></article>')
    controls = '''<div class="actions"><input id="history-search" placeholder="Verlauf durchsuchen …"><button class="filter active" data-state="all">Alle</button><button class="filter" data-state="completed">Fertig</button><button class="filter" data-state="failed">Fehler</button><button class="filter" data-state="cancelled">Abgebrochen</button></div>'''
    script = '''<script>document.querySelectorAll('[data-state]').forEach(button=>button.onclick=()=>{document.querySelectorAll('[data-state]').forEach(item=>item.classList.toggle('active',item===button));let state=button.dataset.state,term=document.getElementById('history-search').value.toLowerCase();document.querySelectorAll('.history-run').forEach(row=>row.style.display=((state==='all'||row.dataset.state===state)&&row.dataset.search.includes(term))?'flex':'none')});document.getElementById('history-search').oninput=()=>document.querySelector('[data-state].active').click()</script>'''
    body = f'<section class="panel"><a href="/">← Zurück</a><h2>◷ Download-Verlauf</h2><p class="sub">Jeder Download-Durchlauf mit Ergebnis, Quelle und Zielordner.</p>{controls}<div class="file-list">{"".join(cards) or "<p class=\"sub\">Noch keine abgeschlossenen Download-Durchläufe vorhanden.</p>"}</div></section>{script}'
    return layout("UTUBE MAC – Download-Verlauf", "Timeline deiner Download-Aktivitäten.", body)

def test_center_page(selected="all"):
    checks = {
        "scripts": ("Skripte", all(path.exists() for path in (INSTALLER, DOWNLOADER, UPDATER)), "Einrichtung, Downloader und Updater sind vorhanden."),
        "library": ("Mediathek", bool(media_files()), "Mindestens eine lokale Medien-Datei wurde gefunden."),
        "history": ("Download-Verlauf", DOWNLOAD_HISTORY.exists() and DOWNLOAD_HISTORY.stat().st_size > 0, "Die lokale Download-History ist lesbar."),
        "player": ("Player-Dateien", any(path.suffix.lower() in {'.mp3', '.mp4', '.mkv', '.m4a'} for path in media_files()), "Audio- oder Videodateien sind für den Player verfügbar."),
        "folders": ("Download-Ordner", all(root.exists() and root.is_dir() for root in media_library_roots()), "Alle gespeicherten Medienordner sind erreichbar."),
        "tools": ("Werkzeuge", shutil.which("yt-dlp") is not None and shutil.which("ffmpeg") is not None, "yt-dlp und FFmpeg sind verfügbar."),
    }
    cards = []
    for key, (title, passed, description) in checks.items():
        state = "✓ Bereit" if passed else "⚠ Prüfen"
        selected_note = "<small>Gerade ausgeführt</small>" if selected in {"all", key} else ""
        cards.append(f'<article class="card"><small>TEST · {html.escape(title.upper())}</small><h2>{state}</h2><p>{html.escape(description)}</p>{selected_note}<a class="folder" href="/tester?run={key}">Diesen Test ausführen</a></article>')
    protocol = '''<section class="panel"><h2>Testprotokoll</h2><ol><li>Vor jedem Download: Link, Format und Zielordner prüfen.</li><li>Nach dem Download: Datei, Dateigröße und History-Eintrag prüfen.</li><li>Player-Test: Audio oder Video öffnen; nur eine Quelle darf gleichzeitig spielen.</li><li>Verschieben: Zielordner wählen, Erfolgsmeldung prüfen und Mediathek aktualisieren.</li><li>Fehlerfall: fehlende Datei oder nicht erreichbarer Ordner muss verständlich gemeldet werden.</li></ol></section>'''
    run_text = "Alle sicheren Prüfungen wurden ausgeführt." if selected == "all" else f"Prüfung „{checks.get(selected, ('Unbekannt',))[0]}“ wurde ausgeführt."
    body = f'<section class="panel"><a href="/developer">← Zur Entwicklung</a><h2>UTUBE MAC · Testzentrum</h2><p class="sub">{html.escape(run_text)} Keine Prüfung löscht Dateien oder startet Downloads.</p><div class="grid">{"".join(cards)}</div></section>{protocol}'
    return layout("UTUBE MAC – Testzentrum", "Sichere Funktionsprüfungen und ein nachvollziehbares Testprotokoll.", body)

def safari_extension_guide_page():
    body = '''<section class="panel"><h2>Safari-Erweiterung einrichten</h2><p class="sub">Die Erweiterung fügt auf YouTube einen Button „Zu UTUBE MAC hinzufügen“ hinzu. Sie schickt nur den gerade geöffneten YouTube-Link an deine lokale Warteschlange.</p><div class="grid"><div class="card"><div class="label">1 · Erweiterung installieren</div><div class="value">UTUBE MAC Extension</div><p class="hint">Öffne die vorbereitete Begleit-App.</p></div><div class="card"><div class="label">2 · Safari öffnen</div><div class="value">Safari-Einstellungen</div><p class="hint">Safari → Einstellungen → Erweiterungen</p></div><div class="card"><div class="label">3 · Einmal aktivieren</div><div class="value">UTUBE MAC einschalten</div><p class="hint">Danach erscheint der Button auf YouTube-Videos und Playlists.</p></div></div><div class="actions"><a class="folder" href="/install-safari-extension">Erweiterung installieren</a><a class="folder" href="/open?target=safari-extension">Erweiterungsdateien zeigen</a><a class="folder" href="/">Zurück zu UTUBE MAC</a></div><p class="hint">Safari verlangt diese eine Aktivierung selbst. UTUBE MAC kann sie nicht heimlich einschalten.</p></section>'''
    return layout("UTUBE MAC – Safari-Erweiterung", "Geführte Einrichtung für den YouTube-Queue-Button.", body)

def run_in_terminal(arguments):
    apple = '''on run argv
tell application "Terminal"
activate
do script item 1 of argv & " " & quoted form of item 2 of argv & " " & quoted form of item 3 of argv & " " & quoted form of item 4 of argv & " " & quoted form of item 5 of argv
end tell
end run'''
    command_prefix = "/bin/bash " + shlex.quote(str(arguments[0]))
    if Path(arguments[0]) == DOWNLOADER:
        command_prefix = "/usr/bin/env UTUBE_MAC_FORCE_DASHBOARD=1 " + command_prefix
    values = [command_prefix] + [str(value) for value in arguments[1:]]
    values += [""] * (5 - len(values))
    try:
        subprocess.Popen(["osascript", "-"] + values[:5], stdin=subprocess.PIPE, text=True).communicate(apple)
        return True
    except OSError:
        return False

def run_dashboard_in_background(mode, url, quality, subtitles):
    """Start the downloader without a visible starter terminal.
    The script detects the background launch and opens its one dashboard window.
    """
    try:
        environment = os.environ.copy()
        environment["UTUBE_MAC_FORCE_DASHBOARD"] = "1"
        subprocess.Popen(["/bin/bash", str(DOWNLOADER), mode, url, quality, subtitles], env=environment, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
        return True
    except OSError:
        return False

def run_silently(script):
    subprocess.Popen(["/bin/bash", str(script)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)

def run_download_in_background(mode, url, quality, subtitles):
    jobs = RUNTIME / "Download Progress" / "Jobs"; jobs.mkdir(parents=True, exist_ok=True)
    job_id = subprocess.check_output(["date", "+%Y%m%d-%H%M%S"], text=True).strip() + f"-{os.getpid()}"
    log = jobs / f"{job_id}.log"
    with log.open("w") as output:
        subprocess.Popen(["/usr/bin/env", "UTUBE_MAC_DOWNLOAD_WORKER=1", f"UTUBE_MAC_JOB_ID={job_id}", "/bin/bash", str(DOWNLOADER), mode, url, quality, subtitles], stdout=output, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, start_new_session=True)
    return job_id

def retry_failed_job(job_id):
    """Restart a failed local job from its saved log; no URL needs retyping."""
    if not re.fullmatch(r"[A-Za-z0-9._-]+", job_id): return ""
    jobs = RUNTIME / "Download Progress" / "Jobs"
    status_path, log_path = jobs / f"{job_id}.status", jobs / f"{job_id}.log"
    if not status_path.exists() or not log_path.exists(): return ""
    status, log = status_path.read_text(errors="replace"), log_path.read_text(errors="replace")
    mode = re.search(r"^MODE=(.+)$", status, re.M)
    url = re.search(r"Extracting URL: (https?://\S+)", log)
    if not mode or not url: return ""
    return run_download_in_background(mode.group(1).strip(), url.group(1).strip(), "720", "none")

def run_queue_in_terminal(items):
    queue_file = SUPPORT / "Temp" / "utube-mac-download-queue.sh"
    queue_file.parent.mkdir(parents=True, exist_ok=True)
    lines = ["#!/bin/bash", "set -e"]
    for item in items:
        lines.append("/bin/bash " + " ".join(shlex.quote(str(value)) for value in [DOWNLOADER, item["mode"], item["url"], item["quality"], item["subtitles"]]))
    queue_file.write_text("\n".join(lines) + "\n")
    queue_file.chmod(0o755)
    run_in_terminal([queue_file])

def run_queue_in_background(items):
    """Run queued items one after another without relying on a Terminal window."""
    queue_dir = RUNTIME / "Download Progress" / "Queue"; queue_dir.mkdir(parents=True, exist_ok=True)
    queue_id = time.strftime("%Y%m%d-%H%M%S") + f"-{os.getpid()}"
    worker = queue_dir / f"queue-{queue_id}.sh"
    lines = ["#!/bin/bash", "set +e"]
    for index, item in enumerate(items, 1):
        job_id = f"queue-{queue_id}-{index}"
        log = RUNTIME / "Download Progress" / "Jobs" / f"{job_id}.log"
        command = " ".join(shlex.quote(str(value)) for value in [DOWNLOADER, item["mode"], item["url"], item["quality"], item["subtitles"]])
        lines.append(f"UTUBE_MAC_DOWNLOAD_WORKER=1 UTUBE_MAC_JOB_ID={shlex.quote(job_id)} /bin/bash {command} >> {shlex.quote(str(log))} 2>&1")
    status_dir = RUNTIME / "Download Progress" / "Jobs"
    summary = RUNTIME / "Download Progress" / "Queue" / f"queue-{queue_id}-summary.txt"
    lines.extend([
        f"summary_file={shlex.quote(str(summary))}",
        f'status_dir={shlex.quote(str(status_dir))}; {{ echo "UTUBE MAC – Warteschlange abgeschlossen"; echo; for status in "$status_dir"/queue-{queue_id}-*.status; do title=$(sed -n "s/^TITLE=//p" "$status" | head -n 1); result=$(sed -n "s/^RESULT=//p" "$status" | head -n 1); phase=$(sed -n "s/^PHASE=//p" "$status" | head -n 1); case "$result" in completed) icon="✓";; failed) icon="⚠";; cancelled) icon="⊘";; *) icon="•";; esac; echo "$icon $title — $phase"; done; }} > "$summary_file"',
        'osascript - "$summary_file" <<\'QUEUE_SUMMARY_EOF\'\non run argv\n  set summaryText to read POSIX file (item 1 of argv)\n  display dialog summaryText with title "UTUBE MAC" buttons {"Fertig", "Übersicht öffnen"} default button "Fertig"\n  if button returned of result is "Übersicht öffnen" then open location "http://127.0.0.1:8765/download-notifications"\nend run\nQUEUE_SUMMARY_EOF',
    ])
    worker.write_text("\n".join(lines) + "\n"); worker.chmod(0o700)
    subprocess.Popen(["/bin/bash", str(worker)], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    return queue_id

def find_tool(command):
    paths = [Path("/opt/homebrew/bin") / command, Path("/usr/local/bin") / command]
    for path in paths:
        if path.exists(): return str(path)
    return command

def tool_version(command, argument):
    try:
        return subprocess.check_output([find_tool(command), argument], text=True, stderr=subprocess.DEVNULL).splitlines()[0]
    except Exception:
        return "Nicht installiert"

def local_version():
    version_file = GENERAL / "utube-mac-version.txt"
    return version_file.read_text().strip() if version_file.exists() else "Nicht verfügbar"

def library_locations():
    try: saved = json.loads(LIBRARIES_FILE.read_text())
    except Exception: saved = []
    paths = [str(DOWNLOADS), str(DEFAULT_LIBRARY)] + [str(item) for item in saved if isinstance(item, str)]
    # A completed download records its destination.  Rebuild the list of
    # previously used libraries from that history, including folders selected
    # before the dashboard was introduced.
    if DOWNLOAD_HISTORY.exists():
        for line in DOWNLOAD_HISTORY.read_text(errors="replace").splitlines():
            if line.startswith("Destination: "):
                paths.append(str(library_root(line.removeprefix("Destination: ").strip())))
    return list(dict.fromkeys(paths))

def library_root(value):
    path = Path(value).expanduser()
    for index, part in enumerate(path.parts):
        if part in {"MP3", "MP4", "MKV"}:
            return Path(*path.parts[:index])
    return path

def short_library_label(value):
    path = Path(value)
    parts = path.parts[-2:]
    return "/".join(parts) if parts else str(path)

def media_library_roots():
    return [Path(path) for path in library_locations() if path and Path(path).is_dir() and Path(path) != APPLE_MUSIC_LIBRARY]

def media_library_for(path):
    resolved = path.resolve()
    for root in media_library_roots():
        try:
            resolved.relative_to(root.resolve())
            return root
        except ValueError:
            pass
    return None

def remember_library(path):
    location = str(Path(path).expanduser())
    existing = library_locations()
    if location not in existing: existing.append(location)
    GENERAL.mkdir(parents=True, exist_ok=True); LIBRARIES_FILE.write_text(json.dumps(existing, indent=2))
    return location

def forget_library(path):
    if str(path) in PROTECTED_LIBRARIES: return
    remaining = [item for item in library_locations() if item != str(path)]
    LIBRARIES_FILE.write_text(json.dumps(list(dict.fromkeys(remaining)), indent=2))

def choose_library_folder():
    script = 'set chosenFolder to choose folder with prompt "UTUBE MAC: Download-Ordner auswählen"\nreturn POSIX path of chosenFolder'
    result = subprocess.run(["osascript", "-e", script], capture_output=True, text=True)
    return result.stdout.strip() if result.returncode == 0 else ""

def newer_version(available, installed):
    try: return tuple(map(int, available.split("."))) > tuple(map(int, installed.split(".")))
    except Exception: return False

def remote_ui_release():
    cache = SUPPORT / "Temp" / "remote-ui-release-cache.json"
    try:
        if cache.exists() and (time.time() - cache.stat().st_mtime) < 300:
            entries = json.loads(cache.read_text())
        else:
            request = urllib.request.Request(REMOTE_UI_PACKAGES_URL, headers={"Accept": "application/vnd.github+json", "User-Agent": "UTUBE-MAC"})
            entries = json.loads(urllib.request.urlopen(request, timeout=5).read().decode())
            cache.parent.mkdir(parents=True, exist_ok=True); cache.write_text(json.dumps(entries))
        versions = []
        for entry in entries if isinstance(entries, list) else []:
            name = str(entry.get("name", ""))
            match = re.fullmatch(r"UTUBE-MAC-([0-9]+(?:\.[0-9]+){1,3})\.zip", name)
            if match:
                versions.append((tuple(map(int, match.group(1).split("."))), match.group(1)))
        return max(versions, default=((), ""))[1]
    except Exception:
        return ""

def remote_update():
    available = remote_ui_release()
    return available if available and newer_version(available, local_version()) else ""

def shortcut_version():
    """Read the installed Shortcut version, independently from the UI."""
    installer = SCRIPTS / "install_utube_tools.sh"
    if installer.exists():
        match = re.search(r"^# Setup script version:\s*([0-9]+(?:\.[0-9]+){1,3})", installer.read_text(errors="replace"), re.MULTILINE)
        if match: return match.group(1)
    version_file = SUPPORT / "UI-VERSION-6.2.0.json"
    try:
        value = json.loads(version_file.read_text()).get("shortcutVersion", "")
        if re.fullmatch(r"[0-9]+(?:\.[0-9]+){1,3}", str(value)):
            return str(value)
    except Exception:
        pass
    match = re.search(r"([0-9]+(?:\.[0-9]+){1,3})", (GENERAL / "version.txt").read_text(errors="replace") if (GENERAL / "version.txt").exists() else "")
    return match.group(1) if match else "Unbekannt"

def remote_shortcut_release():
    """Use GitHub's Shortcut Versions folder only; never local history."""
    cache = SUPPORT / "Temp" / "remote-shortcut-release-cache.json"
    try:
        if cache.exists() and time.time() - cache.stat().st_mtime < 300:
            entries = json.loads(cache.read_text())
        else:
            endpoint = "https://api.github.com/repos/baschigi/utube_mac/contents/Shortcut%20Versions"
            request = urllib.request.Request(endpoint, headers={"Accept": "application/vnd.github+json", "User-Agent": "UTUBE-MAC"})
            entries = json.loads(urllib.request.urlopen(request, timeout=5).read().decode())
            cache.parent.mkdir(parents=True, exist_ok=True); cache.write_text(json.dumps(entries))
        releases = []
        for entry in entries if isinstance(entries, list) else []:
            match = re.fullmatch(r"UTUBE MAC ([0-9]+(?:\.[0-9]+){1,3})", str(entry.get("name", "")))
            if match: releases.append((tuple(map(int, match.group(1).split("."))), match.group(1)))
        return max(releases, default=((), ""))[1]
    except Exception:
        return ""

def library_stats():
    counts = {"MP4": 0, "MKV": 0, "MP3": 0}
    for item in media_files():
        if item.suffix.lower() in {".mp3", ".m4a", ".opus", ".flac", ".aac", ".ogg"}: counts["MP3"] += 1
        elif item.suffix.lower() == ".mkv": counts["MKV"] += 1
        else: counts["MP4"] += 1
    try:
        free = shutil.disk_usage(DOWNLOADS).free // (1024 * 1024 * 1024)
    except Exception:
        free = 0
    return counts, free

def library_chart():
    counts, _ = library_stats()
    maximum = max(1, *counts.values())
    colors = {"MP4": "#6ea8fe", "MKV": "#b28cff", "MP3": "#55d6a8"}
    return "".join(f'<a class="bar-item" href="/library?filter={name}"><div class="bar-label"><span>{name}</span><b>{amount}</b></div><div class="bar-track"><div class="bar" style="width:{max(8, amount * 100 // maximum)}%;background:{colors[name]}"></div></div></a>' for name, amount in counts.items())

def media_files():
    extensions = {".mp4", ".mkv", ".webm", ".mp3", ".m4a", ".opus", ".flac", ".aac", ".ogg"}
    files = {}
    for root in media_library_roots():
        try:
            for path in root.rglob("*"):
                # Download helpers and old intermediate streams live here.  They
                # remain available for recovery, but must never become library
                # entries or slow down the visible collection.
                if (path.is_file()
                        and path.suffix.lower() in extensions
                        and ".utube-mac-assets" not in path.parts
                        and not path.name.endswith(".part")):
                    files[path.resolve()] = path
        except OSError:
            continue
    return sorted(files.values(), key=lambda p: p.stat().st_mtime, reverse=True)

def media_is_audio(path):
    """Some interrupted YouTube downloads are WebM audio, not video."""
    if path.suffix.lower() in {".mp3", ".m4a", ".opus", ".flac", ".aac", ".ogg"}:
        return True
    if path.suffix.lower() != ".webm":
        return False
    try:
        stat = path.stat(); cache_key = (str(path), stat.st_mtime_ns, stat.st_size)
        if cache_key in MEDIA_KIND_CACHE:
            return MEDIA_KIND_CACHE[cache_key]
        probe = shutil.which("ffprobe")
        if not probe:
            return False
        result = subprocess.run([probe, "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=codec_type", "-of", "default=nw=1:nk=1", str(path)], capture_output=True, text=True, timeout=3)
        audio_only = result.stdout.strip() != "video"
        MEDIA_KIND_CACHE[cache_key] = audio_only
        return audio_only
    except (OSError, subprocess.SubprocessError):
        return False

def safe_media(value):
    try:
        path = Path(value).resolve()
        return path if path.is_file() and media_library_for(path) else None
    except Exception: return None

def move_media_to_library(value, target_value):
    source = safe_media(value)
    if not source:
        return None
    current_root = media_library_for(source)
    target_root = next((root for root in media_library_roots() if str(root) == str(target_value)), None)
    if not current_root or not target_root or current_root.resolve() == target_root.resolve():
        return None
    try:
        destination = target_root / source.resolve().relative_to(current_root.resolve())
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.exists():
            index = 2
            while destination.exists():
                destination = destination.with_name(f"{source.stem} ({index}){source.suffix}")
                index += 1
        shutil.move(str(source), str(destination))
        return destination
    except (OSError, ValueError):
        return None

def optimize_media_for_seeking(value):
    """Make an MP4 start quickly and play reliably in the macOS WebKit view."""
    source = safe_media(value)
    if not source or source.suffix.lower() != ".mp4" or not shutil.which("ffmpeg"):
        return False
    key = str(source.resolve())
    if key in MEDIA_OPTIMIZATION_RUNNING:
        return True
    MEDIA_OPTIMIZATION_RUNNING.add(key)
    temporary = source.with_name(source.stem + ".utube-mac-faststart.mp4")
    def work():
        try:
            probe = subprocess.run([shutil.which("ffprobe") or "ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=codec_name", "-of", "default=nw=1:nk=1", str(source)], capture_output=True, text=True, timeout=30)
            codec = probe.stdout.strip().lower()
            # AV1-in-MP4 is small but commonly stays black in macOS WebKit.
            # Re-encode only incompatible files; regular H.264 MP4s are copied.
            # Exclude attached artwork/data streams: some YouTube MP4s carry
            # PNG streams that cannot be written with a H.264 video stream.
            command = [shutil.which("ffmpeg"), "-hide_banner", "-loglevel", "error", "-y", "-i", str(source), "-map", "0:v:0", "-map", "0:a?"]
            if codec in {"av1", "vp9", "vp8"}:
                command += ["-c:v", "libx264", "-preset", "veryfast", "-crf", "22", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart"]
            else:
                command += ["-c", "copy", "-movflags", "+faststart"]
            result = subprocess.run(command + [str(temporary)], timeout=7200)
            if result.returncode == 0 and temporary.exists() and temporary.stat().st_size > 0:
                os.replace(temporary, source)
            elif temporary.exists():
                temporary.unlink()
        except (OSError, subprocess.SubprocessError):
            if temporary.exists(): temporary.unlink()
        finally:
            MEDIA_OPTIMIZATION_RUNNING.discard(key)
    threading.Thread(target=work, daemon=True).start()
    return True

def media_url(path): return "/media?path=" + urllib.parse.quote(str(path))

def readable_size(size):
    if size >= 1024 ** 3: return f"{size / 1024 ** 3:.2f} GB"
    if size >= 1024 ** 2: return f"{size / 1024 ** 2:.0f} MB"
    return f"{size / 1024:.0f} KB"

def file_digest(path):
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()

def duplicate_groups(files):
    by_size = {}
    for path in files:
        by_size.setdefault(path.stat().st_size, []).append(path)
    groups = []
    for same_size in by_size.values():
        if len(same_size) < 2: continue
        by_hash = {}
        for path in same_size:
            try: by_hash.setdefault(file_digest(path), []).append(path)
            except OSError: pass
        groups.extend(group for group in by_hash.values() if len(group) > 1)
    return sorted(groups, key=lambda group: sum(path.stat().st_size for path in group), reverse=True)

def normal_title(value):
    return "".join(char.lower() for char in value if char.isalnum())

def custom_metadata_for(path):
    try:
        saved = json.loads(LIBRARY_METADATA.read_text()) if LIBRARY_METADATA.exists() else {}
        value = saved.get(str(path.resolve()), {})
        return value if isinstance(value, dict) else {}
    except (OSError, json.JSONDecodeError):
        return {}

def save_custom_metadata(path, values):
    safe_path = safe_media(path)
    if not safe_path:
        return False
    cleaned = {key: str(values.get(key, "")).strip()[:600] for key in ("title", "channel", "source_url")}
    if cleaned["source_url"] and not cleaned["source_url"].startswith(("https://", "http://")):
        return False
    try:
        saved = json.loads(LIBRARY_METADATA.read_text()) if LIBRARY_METADATA.exists() else {}
        saved[str(safe_path.resolve())] = cleaned
        LIBRARY_METADATA.parent.mkdir(parents=True, exist_ok=True)
        LIBRARY_METADATA.write_text(json.dumps(saved, ensure_ascii=False, indent=2))
        return True
    except (OSError, json.JSONDecodeError):
        return False

def smart_media_title(path):
    """Make imported filenames readable without renaming the user's file."""
    title = path.stem
    title = re.sub(r"^\s*\d{1,4}\s*[-_.]\s*", "", title)
    title = re.sub(r"\.(?:f\d{2,4}|source|temp|part)(?:-\d+)?$", "", title, flags=re.IGNORECASE)
    title = re.sub(r"\s{2,}", " ", title).strip(" -_.")
    return title or path.stem

def playlist_name_for(path):
    """Read the playlist identity from .../FORMAT/Playlists/PLAYLIST NAME/file."""
    parts = path.parts
    try:
        return parts[parts.index("Playlists") + 1]
    except (ValueError, IndexError):
        return ""

def playlist_info_for(path):
    """Read the local playlist record written next to downloaded media."""
    info_file = path.parent / "UTUBE-MAC-PLAYLIST.txt"
    if not info_file.exists():
        return {}, None
    values = {}
    try:
        for line in info_file.read_text(errors="replace").splitlines():
            if ": " not in line:
                continue
            key, value = line.split(": ", 1)
            if key in {"Playlist-URL", "Titel", "Kanal", "Kanal-URL", "Playlist-ID", "Erstellt am", "Gewählte Qualität"} and value and value != "NA":
                values.setdefault(key, value)
    except OSError:
        return {}, None
    return values, info_file

def playlist_total_for(path):
    """Read the original playlist size from UTUBE-MAC-PLAYLIST.txt when known."""
    if not path:
        return 0
    info_file = path.parent / "UTUBE-MAC-PLAYLIST.txt"
    try:
        totals = [int(value) for value in re.findall(r"^Video\s+\d+\s+von\s+(\d+)", info_file.read_text(errors="replace"), flags=re.MULTILINE)]
        return max(totals, default=0)
    except OSError:
        return 0

def playlist_video_url_for(path):
    """Recover a video's URL from the playlist record written beside it."""
    info_file = path.parent / "UTUBE-MAC-PLAYLIST.txt"
    try:
        blocks = re.split(r"(?=^Video\s+\d+\s+von\s+\d+\s*$)", info_file.read_text(errors="replace"), flags=re.MULTILINE)
        wanted = normal_title(smart_media_title(path))
        for block in blocks:
            title = re.search(r"^Titel:\s*(.+)$", block, re.MULTILINE)
            url = re.search(r"^Video-URL:\s*(https?://\S+)$", block, re.MULTILINE)
            if title and url and (wanted == normal_title(title.group(1)) or wanted in normal_title(title.group(1)) or normal_title(title.group(1)) in wanted):
                return url.group(1)
    except OSError:
        pass
    return ""

def source_url_for(path):
    try:
        identity = f"{path.stat().st_dev}:{path.stat().st_ino}"
        if identity in MEDIA_SOURCE_URL_CACHE:
            return MEDIA_SOURCE_URL_CACHE[identity]
        if MEDIA_SOURCE_INDEX.exists():
            for line in reversed(MEDIA_SOURCE_INDEX.read_text(errors="replace").splitlines()):
                parts = line.split("\t", 2)
                if len(parts) >= 2 and parts[0] == identity and parts[1].startswith("http"):
                    MEDIA_SOURCE_URL_CACHE[identity] = parts[1]
                    return parts[1]
    except OSError: pass
    playlist_url = playlist_video_url_for(path)
    if playlist_url:
        try:
            MEDIA_SOURCE_URL_CACHE[identity] = playlist_url
        except UnboundLocalError:
            pass
        return playlist_url
    if not DOWNLOAD_HISTORY.exists(): return ""
    wanted = normal_title(path.stem)
    blocks = DOWNLOAD_HISTORY.read_text(errors="replace").split("------------------------------------------------------------")
    for block in reversed(blocks):
        title = next((line[7:] for line in block.splitlines() if line.startswith("Title: ")), "")
        url = next((line[5:] for line in block.splitlines() if line.startswith("URL: ")), "")
        if url and (wanted == normal_title(title) or wanted in normal_title(title) or normal_title(title) in wanted):
            source = url.strip()
            try:
                MEDIA_SOURCE_INDEX.parent.mkdir(parents=True, exist_ok=True)
                with MEDIA_SOURCE_INDEX.open("a") as index: index.write(f"{path.stat().st_dev}:{path.stat().st_ino}\t{source}\t{path}\n")
            except OSError: pass
            MEDIA_SOURCE_URL_CACHE[identity] = source
            return source
    try: MEDIA_SOURCE_URL_CACHE[identity] = ""
    except UnboundLocalError: pass
    return ""

def youtube_identity(url):
    """Stable identity for the same YouTube video/playlist despite extra URL parameters."""
    try:
        parsed = urllib.parse.urlparse(url)
        query = urllib.parse.parse_qs(parsed.query)
        if query.get("list"):
            return "playlist:" + query["list"][0]
        if query.get("v"):
            return "video:" + query["v"][0]
        if "youtu.be" in parsed.netloc and parsed.path.strip("/"):
            return "video:" + parsed.path.strip("/").split("/")[0]
        match = re.search(r"/shorts/([^/?]+)", parsed.path)
        if match:
            return "video:" + match.group(1)
    except Exception:
        pass
    return ""

def library_match_for_url(url):
    identity = youtube_identity(url)
    if not identity:
        return None
    indexed_inodes = set()
    try:
        for line in MEDIA_SOURCE_INDEX.read_text(errors="replace").splitlines():
            parts = line.split("\t", 2)
            if len(parts) >= 2 and youtube_identity(parts[1]) == identity:
                indexed_inodes.add(parts[0])
    except OSError:
        pass
    for path in media_files():
        custom = custom_metadata_for(path)
        inode = f"{path.stat().st_dev}:{path.stat().st_ino}"
        if youtube_identity(custom.get("source_url", "")) == identity or inode in indexed_inodes:
            return {"title": smart_media_title(path), "path": str(path)}
        if identity.startswith("playlist:"):
            info, _ = playlist_info_for(path)
            if youtube_identity(info.get("Playlist-URL", "")) == identity:
                return {"title": info.get("Titel") or playlist_name_for(path) or smart_media_title(path), "path": str(path)}
    return None

def thumbnail_for(path, source_url=""):
    for extension in (".webp", ".jpg", ".jpeg", ".png"):
        candidate = path.with_suffix(extension)
        if candidate.exists(): return media_url(candidate)
        hidden_candidate = path.parent / ".utube-mac-assets" / (path.stem + extension)
        if hidden_candidate.exists(): return media_url(hidden_candidate)
    match = re.search(r"(?:[?&]v=|youtu\.be/|shorts/)([^?&/]+)", source_url)
    if match: return f"https://i.ytimg.com/vi/{match.group(1)}/hqdefault.jpg"
    # Never invoke FFmpeg while rendering the library.  Generating dozens of
    # frames here makes opening the page appear frozen; downloads already save
    # their artwork and files without one keep a lightweight fallback tile.
    return ""

def progress_jobs():
    jobs = RUNTIME / "Download Progress" / "Jobs"; results = []
    if not jobs.exists(): return results
    for status in sorted(jobs.glob("*.status"), key=lambda p: p.stat().st_mtime, reverse=True)[:10]:
        data = {}
        for line in status.read_text(errors="replace").splitlines():
            if "=" in line:
                key, value = line.split("=", 1); data[key] = value
        job_id = status.stem
        data["id"] = job_id; data["active"] = (jobs / f"{job_id}.active").exists(); data["done"] = (jobs / f"{job_id}.done").exists()
        results.append(data)
    return results

def cancel_background_download(job_id):
    """Stop only an active, verified UTUBE-MAC worker process group."""
    if not re.fullmatch(r"[A-Za-z0-9._-]+", job_id): return False
    jobs = RUNTIME / "Download Progress" / "Jobs"
    active = jobs / f"{job_id}.active"
    status = jobs / f"{job_id}.status"
    if not active.exists() or not status.exists(): return False
    values = dict(line.split("=", 1) for line in status.read_text(errors="replace").splitlines() if "=" in line)
    pid_text = values.get("PID", "")
    if not pid_text.isdigit(): return False
    pid = int(pid_text)
    try:
        command = subprocess.run(["ps", "-p", str(pid), "-o", "command="], capture_output=True, text=True, timeout=2).stdout
        if "utube_media_download.sh" not in command: return False
        os.killpg(pid, signal.SIGTERM)
        return True
    except (OSError, subprocess.SubprocessError, ProcessLookupError):
        return False

def setup_progress():
    logs = sorted(LOGS.glob("setup-*.log"), key=lambda path: path.stat().st_mtime, reverse=True)
    if not logs: return {"ready": False, "stage": "Einrichtung wird vorbereitet", "lines": []}
    log = logs[0]
    raw = log.read_text(errors="replace")[-18000:]
    clean = re.sub(r"\x1b\[[0-?]*[ -/]*[@-~]", "", raw).replace("\r", "\n")
    lines = [line.strip() for line in clean.splitlines() if line.strip()]
    stage_lines = [line for line in lines if "SCHRITT" in line and "VON 8" in line]
    meaningful = [line for line in lines if any(token in line.lower() for token in ("✅", "⚠", "❌", "ℹ", "⠹", "install", "homebrew", "yt-dlp", "ffmpeg", "apple-werkzeuge", "musicbrainz", "aktualis"))]
    stage = stage_lines[-1] if stage_lines else "Einrichtung läuft"
    done = any("einrichtung abgeschlossen" in line.lower() or "alles ist bereit" in line.lower() for line in lines[-30:])
    failed = any("einrichtung wurde nicht abgeschlossen" in line.lower() for line in lines[-20:])
    return {"ready": True, "stage": stage, "lines": meaningful[-7:], "done": done, "failed": failed, "log": log.name}

def library_page(initial_filter="ALL", selected_playlist=""):
    grouped_media = {}
    audio_extensions = {".mp3", ".m4a", ".opus", ".flac", ".aac", ".ogg"}
    for path in media_files():
        library_root_path = media_library_for(path)
        if not library_root_path:
            continue
        # A download can have its MP3 and MP4 in different previously used
        # locations.  Match by title across all known UTUBE-MAC libraries.
        playlist_name = playlist_name_for(path)
        # Same-named files in different playlists must not be merged together.
        group_key = (f"playlist:{playlist_name.casefold()}:{path.stem.casefold()}" if playlist_name else f"single:{path.stem.casefold()}")
        grouped_media.setdefault(group_key, {"roots": set(), "title": smart_media_title(path), "playlist": playlist_name, "audio": None, "video": None})
        grouped_media[group_key]["roots"].add(library_root_path)
        variant = "audio" if path.suffix.lower() in audio_extensions or media_is_audio(path) else "video"
        existing = grouped_media[group_key][variant]
        if existing is None or path.stat().st_mtime > existing.stat().st_mtime:
            grouped_media[group_key][variant] = path

    playlist_summaries = {}
    for group in grouped_media.values():
        if group.get("playlist"):
            playlist_summaries.setdefault(group["playlist"], []).append(group)

    if initial_filter == "PLAYLISTS" and not selected_playlist:
        playlist_cards = []
        for playlist_name, items in sorted(playlist_summaries.items(), key=lambda item: item[0].casefold()):
            primary = next((entry.get("video") or entry.get("audio") for entry in items if entry.get("video") or entry.get("audio")), None)
            cover = thumbnail_for(primary, source_url_for(primary)) if primary else ""
            image = f'<img src="{html.escape(cover, quote=True)}" alt="" class="playlist-cover">' if cover else '<div class="playlist-cover playlist-fallback">📚</div>'
            href = "/library?filter=PLAYLISTS&playlist=" + urllib.parse.quote(playlist_name)
            total = playlist_total_for(primary)
            progress = f'{len(items)} von {total} Videos gespeichert' if total else f'{len(items)} {"Video" if len(items) == 1 else "Videos"} in deiner Mediathek'
            local_info, _ = playlist_info_for(primary)
            playlist_url = local_info.get("Playlist-URL", "")
            source_button = f'<button type="button" onclick="fetch(\'/open-external?url={urllib.parse.quote(playlist_url)}\')">▶ Auf YouTube öffnen</button>' if playlist_url.startswith("http") else ""
            playlist_cards.append(f'<article class="playlist-overview-card"> <a class="playlist-main" href="{href}">{image}<div><span class="type-badge mp4">☰ PLAYLIST</span><h2>{html.escape(playlist_name)}</h2><p class="sub">{html.escape(progress)}</p></div></a><details class="playlist-more"><summary title="Weitere Playlist-Optionen">⋯</summary><div><a class="folder" href="{href}">Playlist öffnen</a>{source_button}</div></details></article>')
        overview = '<section class="panel"><a href="/library">← Alle Downloads</a><h2>📚 Deine Playlists</h2><p class="sub">Eine Karte pro Playlist – unabhängig davon, ob sie MP3 oder MP4 enthält.</p><div class="playlist-overview-grid">' + ''.join(playlist_cards or ['<p class="sub">Noch keine Playlists vorhanden.</p>']) + '</div></section>'
        overview_style = '''<style>.playlist-overview-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(270px,1fr));gap:16px}.playlist-overview-card{position:relative;padding:14px;border:1px solid #38648a;border-radius:16px;background:#102033;color:#edf3f8}.playlist-overview-card:hover{border-color:#78b9ff;transform:translateY(-1px)}.playlist-main{display:grid;grid-template-columns:130px 1fr;gap:14px;color:#edf3f8;text-decoration:none}.playlist-cover{width:130px;height:90px;border-radius:10px;object-fit:cover;background:#07111b}.playlist-fallback{display:grid;place-items:center;font-size:34px}.playlist-overview-card h2{margin:2px 34px 7px 0;font-size:17px}.playlist-overview-card .folder{padding:7px 9px;margin-top:8px;width:max-content;font-size:12px}.playlist-more{position:absolute;right:12px;top:12px}.playlist-more summary{list-style:none;cursor:pointer;font-size:21px;font-weight:900}.playlist-more summary::-webkit-details-marker{display:none}.playlist-more>div{position:absolute;right:0;top:27px;z-index:5;display:grid;gap:7px;min-width:185px;padding:9px;border:1px solid #4d799f;border-radius:11px;background:#0b1724;box-shadow:0 14px 32px #000b}.playlist-more button{width:100%;padding:8px}</style>'''
        return layout("UTUBE MAC – Playlists", "Deine Playlists als eigene Übersicht.", overview_style + overview)

    playlist_detail = ""
    if selected_playlist:
        selected_items = playlist_summaries.get(selected_playlist, [])
        selected_primary = next((entry.get("video") or entry.get("audio") for entry in selected_items if entry.get("video") or entry.get("audio")), None)
        selected_total = playlist_total_for(selected_primary)
        local_info, local_info_file = playlist_info_for(selected_primary) if selected_primary else ({}, None)
        metadata = youtube_playlist_metadata(local_info.get("Playlist-URL") or source_url_for(selected_primary)) if selected_primary else {}
        cover = metadata.get("cover") or (thumbnail_for(selected_primary, source_url_for(selected_primary)) if selected_primary else "")
        description = metadata.get("description") or "Beschreibung dieser Playlist ist lokal nicht verfügbar."
        channel = local_info.get("Kanal") or metadata.get("channel") or "YouTube-Playlist"
        cover_html = f'<img src="{html.escape(cover, quote=True)}" class="playlist-detail-cover" alt="">' if cover else '<div class="playlist-detail-cover playlist-fallback">📚</div>'
        source_link = f'<a class="folder" href="{html.escape(local_info.get("Playlist-URL"), quote=True)}">YouTube-Playlist öffnen</a>' if local_info.get("Playlist-URL", "").startswith("http") else ""
        info_link = f'<a class="folder" href="/reveal?path={urllib.parse.quote(str(local_info_file))}">Lokale Playlist-Daten im Finder</a>' if local_info_file else ""
        repair_button = ""
        playlist_url = local_info.get("Playlist-URL", "")
        if selected_total and len(selected_items) < selected_total and playlist_url.startswith("http"):
            quality = local_info.get("Gewählte Qualität") or "720"
            repair_button = f'<button type="button" class="secondary" onclick="repairPlaylist({html.escape(json.dumps(playlist_url), quote=True)},{html.escape(json.dumps(quality), quote=True)})">↻ Fehlende Videos laden</button>'
        local_details = f'<p class="hint">Lokale Daten · {html.escape(local_info.get("Erstellt am", ""))} · Qualität: {html.escape(local_info.get("Gewählte Qualität", ""))}</p>' if local_info else ''
        saved_label = f'{len(selected_items)} von {selected_total} Videos gespeichert' if selected_total else f'{len(selected_items)} Videos gespeichert'
        playlist_detail = f'<section class="playlist-detail"><aside>{cover_html}<h2>{html.escape(local_info.get("Titel") or selected_playlist)}</h2><p class="sub">{html.escape(channel)} · {html.escape(saved_label)}</p>{local_details}<p class="playlist-description">{html.escape(description)}</p><div class="actions compact">{repair_button}{source_link}{info_link}</div><a class="folder" href="/library?filter=PLAYLISTS">← Alle Playlists</a></aside><div class="playlist-detail-list"><h2>Videos in dieser Playlist</h2><p class="sub">Wähle ein Video zum Abspielen, Verschieben oder Löschen.</p>'

    cards = []
    for group in grouped_media.values():
        if selected_playlist and group.get("playlist") != selected_playlist:
            continue
        audio_path, video_path = group["audio"], group["video"]
        primary_path = video_path or audio_path
        primary_kind = "video" if video_path else "audio"
        playlist_name = group.get("playlist", "")
        custom_metadata = custom_metadata_for(primary_path)
        display_title = custom_metadata.get("title") or group["title"]
        source_url = custom_metadata.get("source_url") or source_url_for(primary_path)
        channel_name = custom_metadata.get("channel", "")
        thumbnail = thumbnail_for(primary_path, source_url)
        types = []
        if audio_path: types.append("MP3")
        if video_path: types.append("MKV" if video_path.suffix.lower() == ".mkv" else "MP4")
        type_text = " + ".join(types)
        video_url = media_url(video_path) if video_path else ""
        audio_url = media_url(audio_path) if audio_path else ""
        # The MP3 and MP4 often belong to the same download group.  Use the
        # group's saved YouTube link for the MP3 too, otherwise its cover and
        # its information button lose the source metadata.
        audio_thumbnail = thumbnail_for(audio_path, source_url) if audio_path else ""
        video_root = str(media_library_for(video_path)) if video_path else ""
        audio_root = str(media_library_for(audio_path)) if audio_path else ""
        preview = f'<div class="media-preview" data-title="{html.escape(display_title, quote=True)}" data-source-url="{html.escape(source_url, quote=True)}" data-video-src="{html.escape(video_url, quote=True)}" data-audio-src="{html.escape(audio_url, quote=True)}" data-video-root="{html.escape(video_root, quote=True)}" data-audio-root="{html.escape(audio_root, quote=True)}" data-video-poster="{html.escape(thumbnail if video_path else "", quote=True)}" data-audio-poster="{html.escape(audio_thumbnail, quote=True)}"></div>'
        switches = ""
        if audio_path and video_path:
            switches = '<div class="variant-switch"><button type="button" class="variant active" data-variant="video" onclick="setMediaVariant(this)">🎬 Video</button><button type="button" class="variant" data-variant="audio" onclick="setMediaVariant(this)">🎵 Audio</button></div>'
        primary_file_type = "MP4" if video_path else "MP3"
        alternative = "Als MP4 herunterladen" if primary_kind == "audio" else "Als MP3 herunterladen"
        alternative_mode = "single-mp4" if primary_kind == "audio" else "single-mp3"
        alternative_args = f'{html.escape(json.dumps(source_url), quote=True)}, {html.escape(json.dumps(alternative_mode), quote=True)}'
        alternative_button = '' if audio_path and video_path else (f'<button type="button" class="secondary alternative" onclick="downloadAlternative({alternative_args})">{alternative}</button>' if source_url else '<span class="hint">Quell-Link für diese ältere Datei nicht gespeichert.</span>')
        current_size = readable_size(primary_path.stat().st_size)
        library_values = "|".join(sorted(str(root) for root in group["roots"]))
        move_options = '<option value="">📁 Zielordner auswählen …</option>' + ''.join(f'<option value="{html.escape(str(root), quote=True)}">📁 {html.escape(short_library_label(root))} — {html.escape(str(root))}</option>' for root in media_library_roots())
        mover = f'<details class="menu-move"><summary>Ordner ändern</summary><div class="move-media"><select class="move-target" aria-label="Neuer Downloadpfad">{move_options}</select><button type="button" class="secondary" onclick="moveSelectedMedia(this)">Verschieben</button></div></details>'
        playlist_badge = f'<small class="playlist-group"><span class="playlist-icon">☰</span> Playlist: {html.escape(playlist_name)}</small>' if playlist_name else ''
        channel_badge = f'<small class="hint">Kanal: {html.escape(channel_name)}</small>' if channel_name else ''
        cards.append(f'<article class="media-card media-{primary_file_type.lower()}" data-playlist-name="{html.escape(playlist_name, quote=True)}" data-primary-path="{html.escape(str(primary_path), quote=True)}" data-meta-title="{html.escape(display_title, quote=True)}" data-meta-channel="{html.escape(channel_name, quote=True)}" data-meta-url="{html.escape(source_url, quote=True)}" data-types="{" ".join(types)}" data-libraries="{html.escape(library_values, quote=True)}" data-video-path="{html.escape(str(video_path) if video_path else "", quote=True)}" data-audio-path="{html.escape(str(audio_path) if audio_path else "", quote=True)}">{preview}{switches}<span class="type-badge {primary_file_type.lower()}">{type_text}</span><b>{html.escape(display_title)}</b>{playlist_badge}{channel_badge}<small class="variant-details">{primary_file_type} · {current_size}</small><div class="actions compact"><a class="folder media-folder" href="/reveal?path={urllib.parse.quote(str(primary_path))}">Im Finder zeigen</a>{alternative_button}{mover}<form method="post" action="/action" onsubmit="return confirm(\'Diese Datei in den Papierkorb legen?\');"><input type="hidden" name="action" value="trash"><input type="hidden" name="path" value="{html.escape(str(primary_path), quote=True)}"><button type="submit" class="danger">Papierkorb</button></form></div></article>')
    filters = '<div class="filters"><button class="filter active" type="button" data-filter="ALL">Alle</button><button class="filter mp3" type="button" data-filter="MP3">Audio</button><button class="filter mp4" type="button" data-filter="MP4">Videos</button><button class="filter mkv" type="button" data-filter="MKV">MKV</button><input id="library-search" placeholder="Mediathek durchsuchen …" aria-label="Mediathek durchsuchen"></div>'
    playlist_options = ['<option value="ALL">Alle Playlists</option>'] + [f'<option value="{html.escape(name, quote=True)}">{html.escape(name)}</option>' for name in sorted(playlist_summaries, key=str.casefold)]
    playlist_filter = '<select id="library-playlist-filter" aria-label="Playlist filtern">' + ''.join(playlist_options) + '</select>'
    location_options = ['<option value="ALL">Alle Downloadpfade</option>']
    for root in media_library_roots():
        location_options.append(f'<option value="{html.escape(str(root), quote=True)}">{html.escape(short_library_label(root))}</option>')
    location_filter = '<label class="label" for="library-path-filter">Downloadpfad</label><select id="library-path-filter">' + ''.join(location_options) + '</select>'
    import_panel = '<div class="actions"><button type="button" class="secondary" id="import-media-folder">📁 Bestehenden Medienordner importieren</button><span class="hint">Dateien werden nicht kopiert oder verändert.</span></div>'
    advanced_controls = '<details class="library-advanced"><summary>Filter &amp; Sortieren</summary><div class="library-advanced-grid">' + import_panel + '<label class="label" for="library-sort">Sortierung</label><select id="library-sort" aria-label="Mediathek sortieren"><option value="recent">Neu hinzugefügt</option><option value="title">Titel A–Z</option><option value="size">Größte Dateien</option></select>' + location_filter + playlist_filter + '</div></details>'
    selected_filter = json.dumps(initial_filter if initial_filter in {"ALL", "MP3", "MP4", "MKV"} else "ALL")
    cinema_stage = '''<section id="cinema-player" class="cinema-stage" hidden aria-label="Video-Player"><header><span>UTUBE MAC · Kino-Modus</span><button type="button" id="cinema-close" class="cinema-close">Schließen ✕</button></header><h2 id="cinema-title"></h2><div id="cinema-media-host"><video id="cinema-video" playsinline></video><iframe id="cinema-youtube" hidden title="YouTube-Video" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe><div id="cinema-loading" aria-live="polite"><span class="cinema-spinner"></span><b id="cinema-loading-text">Video wird vorbereitet …</b><button type="button" id="cinema-optimize" class="secondary" hidden>Vorbereitung</button></div></div><div class="custom-player-controls"><button type="button" id="cinema-toggle" aria-label="Wiedergabe">▶</button><span id="cinema-time">0:00 / 0:00</span><input id="cinema-seek" type="range" min="0" max="1000" value="0" aria-label="Position"><button type="button" id="cinema-mute" aria-label="Ton">🔊</button><input id="cinema-volume" type="range" min="0" max="1" step="0.05" value="1" aria-label="Lautstärke"><button type="button" id="cinema-fullscreen">Vollbild</button></div><div class="cinema-actions"><button type="button" id="cinema-pause" class="secondary">❚❚ Pause</button><button type="button" id="cinema-native" class="secondary">🍎 Apple-Player im Kino</button><button type="button" id="cinema-youtube-toggle" class="secondary" hidden>Mit YouTube ansehen</button><button type="button" id="cinema-minimize" class="secondary">Zurück zur Mediathek</button></div><details id="cinema-information" class="cinema-information"><summary>ⓘ Beschreibung &amp; Informationen</summary><div id="cinema-info-content" class="hint">Für dieses Video sind noch keine YouTube-Informationen gespeichert.</div></details><p class="hint">Tastatur: Leertaste = Pause/Start · ← / → = 5 Sekunden · F = Vollbild · Esc = Schließen.</p></section>'''
    script = '''<script>let typeFilter=__FILTER__;function pauseOtherMedia(current){document.querySelectorAll('audio,video').forEach(media=>{if(media!==current&&!media.paused)media.pause()})}function createPreview(card,variant){let preview=card.querySelector('.media-preview'),src=preview.dataset[variant==='video'?'videoSrc':'audioSrc'];preview.replaceChildren();if(variant==='audio'){if(preview.dataset.audioPoster){let cover=document.createElement('img');cover.className='audio-art';cover.src=preview.dataset.audioPoster;cover.alt='Audio-Cover';preview.appendChild(cover)}else{let cover=document.createElement('div');cover.className='audio-art audio-art-fallback';cover.setAttribute('aria-label','Audio-Cover');cover.textContent='♫';preview.appendChild(cover)}let audio=document.createElement('audio');audio.controls=true;audio.preload='metadata';audio.src=src;audio.addEventListener('play',()=>pauseOtherMedia(audio));preview.appendChild(audio)}else{let launch=document.createElement('button');launch.type='button';launch.className='media-launch';launch.onclick=()=>openCinema(src,preview.dataset.title);let video=document.createElement('video');video.muted=true;video.preload='metadata';video.src=src;if(preview.dataset.videoPoster)video.poster=preview.dataset.videoPoster;let play=document.createElement('span');play.className='media-play';play.textContent='▶';let label=document.createElement('span');label.className='media-cinema-label';label.textContent='Im Kino ansehen';launch.append(video,play,label);preview.appendChild(launch)}let folder=card.querySelector('.media-folder');let filePath=card.dataset[variant==='video'?'videoPath':'audioPath'];if(folder&&filePath)folder.href='/reveal?path='+encodeURIComponent(filePath);let moveTarget=card.querySelector('.move-target'),currentRoot=preview.dataset[variant==='video'?'videoRoot':'audioRoot'];if(moveTarget){Array.from(moveTarget.options).forEach(option=>option.disabled=Boolean(option.value&&option.value===currentRoot));moveTarget.value=''}let details=card.querySelector('.variant-details');if(details)details.textContent=variant==='video'?'MP4 · Video ausgewählt':'MP3 · Audio ausgewählt'}function setMediaVariant(button){let card=button.closest('.media-card'),variant=button.dataset.variant;card.querySelectorAll('.variant').forEach(item=>item.classList.toggle('active',item===button));createPreview(card,variant)}async function moveSelectedMedia(button){let card=button.closest('.media-card'),active=card.querySelector('.variant.active'),variant=active?active.dataset.variant:(card.dataset.videoPath?'video':'audio'),path=card.dataset[variant==='video'?'videoPath':'audioPath'],target=card.querySelector('.move-target').value;if(!path)return;if(!target){alert('Bitte wähle zuerst einen anderen Downloadpfad aus.');return}if(!confirm('Diese '+(variant==='video'?'Videodatei':'Audiodatei')+' in den gewählten Downloadordner verschieben?'))return;let response=await fetch('/move-media',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({path,target})});if(response.ok)location.reload();else alert('Die Datei wurde nicht verschoben. Wähle einen anderen Downloadpfad aus.')}document.querySelectorAll('.media-card').forEach(card=>createPreview(card,card.dataset.videoPath?'video':'audio'));function applyFilters(){let pathFilter=document.getElementById('library-path-filter').value;document.querySelectorAll('.media-card').forEach(card=>{let typeMatches=typeFilter==='ALL'||card.dataset.types.split(' ').includes(typeFilter);let pathMatches=pathFilter==='ALL'||card.dataset.libraries.split('|').includes(pathFilter);card.style.display=typeMatches&&pathMatches?'grid':'none'})}function setFilter(choice){typeFilter=choice;document.querySelectorAll('.filter').forEach(button=>{button.classList.toggle('active',button.dataset.filter===choice)});applyFilters()}document.querySelectorAll('.filter').forEach(button=>button.onclick=()=>setFilter(button.dataset.filter));document.getElementById('library-path-filter').onchange=applyFilters;setFilter(typeFilter);let cinema=document.getElementById('cinema-player'),cinemaVideo=document.getElementById('cinema-video'),cinemaTitle=document.getElementById('cinema-title'),mediaGrid=document.getElementById('library-media-grid');function closeCinema(){cinemaVideo.pause();cinemaVideo.removeAttribute('src');cinemaVideo.load();cinema.hidden=true;mediaGrid.classList.remove('cinema-active')}function openCinema(src,title){pauseOtherMedia(cinemaVideo);cinemaTitle.textContent=title;cinemaVideo.preload='auto';cinemaVideo.src=src;cinemaVideo.load();cinema.hidden=false;mediaGrid.classList.add('cinema-active');cinema.scrollIntoView({behavior:'smooth',block:'start'});cinemaVideo.play().catch(()=>{})}cinemaVideo.addEventListener('play',()=>pauseOtherMedia(cinemaVideo));document.getElementById('cinema-close').onclick=closeCinema;document.getElementById('cinema-minimize').onclick=closeCinema;document.getElementById('cinema-fullscreen').onclick=()=>{if(cinemaVideo.requestFullscreen)cinemaVideo.requestFullscreen();else if(cinemaVideo.webkitEnterFullscreen)cinemaVideo.webkitEnterFullscreen()};document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!cinema.hidden)closeCinema()});async function downloadAlternative(url,mode){if(!url){alert('Für diese Datei ist kein gespeicherter YouTube-Link vorhanden.');return}if(!confirm('Alternative Version im Hintergrund laden?'))return;let r=await fetch('/download-background',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({url,mode,quality:'best',subtitles:'none'})});if(r.ok){location.href='/?message=Alternative%20Version%20wurde%20gestartet.'}else alert('Download konnte nicht gestartet werden.') }</script>'''.replace("__FILTER__", selected_filter)
    script = script.replace("</script>", '''function moveFeedback(message,failed=false){let notice=document.getElementById('move-feedback');if(!notice){notice=document.createElement('div');notice.id='move-feedback';document.body.appendChild(notice)}notice.textContent=message;notice.style.cssText='position:fixed;z-index:9999;left:50%;bottom:24px;transform:translateX(-50%);max-width:min(540px,90vw);padding:13px 17px;border-radius:12px;background:'+(failed?'#7b2639':'#176842')+';border:1px solid '+(failed?'#df7186':'#62d69b')+';color:#fff;font-weight:800;box-shadow:0 12px 35px #0009';clearTimeout(window.moveFeedbackTimer);window.moveFeedbackTimer=setTimeout(()=>notice.remove(),5000)}async function moveSelectedMedia(button){let card=button.closest('.media-card'),active=card.querySelector('.variant.active'),variant=active?active.dataset.variant:(card.dataset.videoPath?'video':'audio'),path=card.dataset[variant==='video'?'videoPath':'audioPath'],select=card.querySelector('.move-target'),target=select.value;if(!path)return;if(!target){moveFeedback('Bitte zuerst einen anderen Downloadpfad auswählen.',true);return}if(!confirm('Diese '+(variant==='video'?'Videodatei':'Audiodatei')+' in den gewählten Downloadordner verschieben?'))return;let originalLabel=button.textContent;button.disabled=true;button.textContent='Verschiebe …';try{let response=await fetch('/move-media',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({path,target})}),result=await response.json().catch(()=>({}));if(!response.ok)throw new Error(result.error||'Die Datei konnte nicht verschoben werden.');moveFeedback('✓ Datei verschoben nach '+select.selectedOptions[0].textContent+'. Mediathek wird aktualisiert.');setTimeout(()=>location.reload(),1800)}catch(error){moveFeedback(error.message||'Die Datei konnte nicht verschoben werden.',true);button.disabled=false;button.textContent=originalLabel}}</script>''')
    script = script.replace("</script>", '''function selectMoveTarget(option){let card=option.closest('.media-card'),preview=card.querySelector('.media-preview'),active=card.querySelector('.variant.active'),variant=active?active.dataset.variant:(card.dataset.videoPath?'video':'audio'),currentRoot=preview.dataset[variant==='video'?'videoRoot':'audioRoot'];if(option.dataset.target===currentRoot){moveFeedback('Diese Datei liegt bereits in diesem Ordner.',true);return}card.dataset.moveTarget=option.dataset.target;let label=card.querySelector('.move-target-label');label.textContent=option.dataset.label;card.querySelector('.move-picker').removeAttribute('open')}async function moveSelectedMedia(button){let card=button.closest('.media-card'),active=card.querySelector('.variant.active'),variant=active?active.dataset.variant:(card.dataset.videoPath?'video':'audio'),path=card.dataset[variant==='video'?'videoPath':'audio'),target=card.dataset.moveTarget,label=card.querySelector('.move-target-label').textContent;if(!path)return;if(!target){moveFeedback('Bitte zuerst einen Zielordner auswählen.',true);return}if(!confirm('Diese '+(variant==='video'?'Videodatei':'Audiodatei')+' nach '+label+' verschieben?'))return;let originalLabel=button.textContent;button.disabled=true;button.textContent='Verschiebe …';try{let response=await fetch('/move-media',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({path,target})}),result=await response.json().catch(()=>({}));if(!response.ok)throw new Error(result.error||'Die Datei konnte nicht verschoben werden.');moveFeedback('✓ Datei verschoben nach '+label+'. Mediathek wird aktualisiert.');setTimeout(()=>location.reload(),1800)}catch(error){moveFeedback(error.message||'Die Datei konnte nicht verschoben werden.',true);button.disabled=false;button.textContent=originalLabel}}</script>''')
    script = script.replace("path=card.dataset[variant==='video'?'videoPath':'audio')", "path=card.dataset[variant==='video'?'videoPath':'audioPath']")
    script = script.replace("</script>", '''function moveSelectedMedia(button){let card=button.closest('.media-card'),active=card.querySelector('.variant.active'),variant=active?active.dataset.variant:(card.dataset.videoPath?'video':'audio'),path=card.dataset[variant==='video'?'videoPath':'audioPath'],select=card.querySelector('.move-target'),target=select?.value;if(!path)return;if(!target){moveFeedback('Bitte zuerst einen Zielordner auswählen.',true);return}if(!confirm('Diese '+(variant==='video'?'Videodatei':'Audiodatei')+' in den gewählten Downloadordner verschieben?'))return;let originalLabel=button.textContent;button.disabled=true;button.textContent='Verschiebe …';try{let response=await fetch('/move-media',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({path,target})}),result=await response.json().catch(()=>({}));if(!response.ok)throw new Error(result.error||'Die Datei konnte nicht verschoben werden.');moveFeedback('✓ Datei verschoben nach '+select.selectedOptions[0].textContent+'. Mediathek wird aktualisiert.');setTimeout(()=>location.reload(),1500)}catch(error){moveFeedback(error.message||'Die Datei konnte nicht verschoben werden.',true);button.disabled=false;button.textContent=originalLabel}}document.addEventListener('keydown',event=>{if(cinema.hidden||event.metaKey||event.ctrlKey||event.altKey)return;let tag=document.activeElement?.tagName;if(tag==='INPUT'||tag==='SELECT'||tag==='TEXTAREA')return;if(event.code==='Space'){event.preventDefault();cinemaVideo.paused?cinemaVideo.play():cinemaVideo.pause()}else if(event.key==='ArrowRight'){event.preventDefault();cinemaVideo.currentTime=Math.min(cinemaVideo.duration||Infinity,cinemaVideo.currentTime+5)}else if(event.key==='ArrowLeft'){event.preventDefault();cinemaVideo.currentTime=Math.max(0,cinemaVideo.currentTime-5)}else if(event.key.toLowerCase()==='f'){event.preventDefault();document.getElementById('cinema-fullscreen').click()}})</script>''')
    # Keep the stable, original media controller. Earlier experimental menu code
    # may have added duplicate handlers, so remove it before adding shortcuts.
    script = re.sub(r"function moveFeedback.*?</script>", "</script>", script, flags=re.DOTALL)
    script = script.replace("</script>", '''document.addEventListener('keydown',event=>{if(cinema.hidden||event.metaKey||event.ctrlKey||event.altKey)return;let tag=document.activeElement&&document.activeElement.tagName;if(tag==='INPUT'||tag==='SELECT'||tag==='TEXTAREA')return;if(event.code==='Space'){event.preventDefault();cinemaVideo.paused?cinemaVideo.play():cinemaVideo.pause()}else if(event.key==='ArrowRight'){event.preventDefault();cinemaVideo.currentTime=Math.min(cinemaVideo.duration||Infinity,cinemaVideo.currentTime+5)}else if(event.key==='ArrowLeft'){event.preventDefault();cinemaVideo.currentTime=Math.max(0,cinemaVideo.currentTime-5)}else if(event.key.toLowerCase()==='f'){event.preventDefault();document.getElementById('cinema-fullscreen').click()}})</script>''')
    # One small, clean controller for every library card.  Keeping it here
    # avoids old experimental handlers disabling all card buttons at once.
    script = '''<script>let typeFilter=__FILTER__;function pauseOthers(current){document.querySelectorAll('audio,video').forEach(item=>{if(item!==current)item.pause()})}function preview(card,kind){let box=card.querySelector('.media-preview'),src=box.dataset[kind==='video'?'videoSrc':'audioSrc'];box.replaceChildren();if(kind==='audio'){let art=box.dataset.audioPoster;if(art){let image=document.createElement('img');image.className='audio-art';image.src=art;image.alt='Audio-Cover';box.appendChild(image)}let audio=document.createElement('audio');audio.controls=true;audio.src=src;audio.onplay=()=>pauseOthers(audio);box.appendChild(audio)}else{let button=document.createElement('button');button.type='button';button.className='media-launch';let video=document.createElement('video');video.muted=true;video.preload='metadata';video.src=src;video.poster=box.dataset.videoPoster||'';let icon=document.createElement('span');icon.className='media-play';icon.textContent='▶';let text=document.createElement('span');text.className='media-cinema-label';text.textContent='Im Kino ansehen';button.append(video,icon,text);button.onclick=()=>openCinema(src,box.dataset.title);box.appendChild(button)}let path=card.dataset[kind==='video'?'videoPath':'audioPath'],finder=card.querySelector('.media-folder'),target=card.querySelector('.move-target');if(finder&&path)finder.href='/reveal?path='+encodeURIComponent(path);if(target){[...target.options].forEach(option=>option.disabled=Boolean(option.value&&option.value===box.dataset[kind==='video'?'videoRoot':'audioRoot']));target.value=''}}function setMediaVariant(button){let card=button.closest('.media-card'),kind=button.dataset.variant;card.querySelectorAll('.variant').forEach(item=>item.classList.toggle('active',item===button));preview(card,kind)}function activeKind(card){let button=card.querySelector('.variant.active');return button?button.dataset.variant:(card.dataset.videoPath?'video':'audio')}function notice(text,bad){let old=document.getElementById('library-notice');if(!old){old=document.createElement('div');old.id='library-notice';document.body.appendChild(old)}old.textContent=text;old.style.cssText='position:fixed;z-index:9999;bottom:24px;left:50%;transform:translateX(-50%);padding:12px 16px;border-radius:10px;background:'+(bad?'#7b2639':'#176842')+';color:white;font-weight:800;box-shadow:0 12px 35px #0009';setTimeout(()=>old.remove(),4500)}async function moveSelectedMedia(button){let card=button.closest('.media-card'),kind=activeKind(card),path=card.dataset[kind==='video'?'videoPath':'audioPath'],select=card.querySelector('.move-target');if(!select.value){notice('Bitte zuerst einen Zielordner auswählen.',true);return}button.disabled=true;try{let response=await fetch('/move-media',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({path:path,target:select.value})});if(!response.ok)throw Error();notice('✓ Datei verschoben. Mediathek wird aktualisiert.');setTimeout(()=>location.reload(),1200)}catch(error){notice('Die Datei konnte nicht verschoben werden.',true);button.disabled=false}}function applyFilters(){let location=document.getElementById('library-path-filter').value;document.querySelectorAll('.media-card').forEach(card=>{let match=(typeFilter==='ALL'||card.dataset.types.split(' ').includes(typeFilter))&&(location==='ALL'||card.dataset.libraries.split('|').includes(location));card.style.display=match?'grid':'none'})}document.querySelectorAll('.media-card').forEach(card=>preview(card,card.dataset.videoPath?'video':'audio'));document.querySelectorAll('.filter').forEach(button=>button.onclick=()=>{typeFilter=button.dataset.filter;document.querySelectorAll('.filter').forEach(item=>item.classList.toggle('active',item===button));applyFilters()});document.getElementById('library-path-filter').onchange=applyFilters;applyFilters();let cinema=document.getElementById('cinema-player'),cinemaVideo=document.getElementById('cinema-video'),cinemaTitle=document.getElementById('cinema-title'),grid=document.getElementById('library-media-grid');function closeCinema(){cinemaVideo.pause();cinemaVideo.removeAttribute('src');cinemaVideo.load();cinema.hidden=true;grid.classList.remove('cinema-active')}function openCinema(src,title){pauseOthers(cinemaVideo);cinemaTitle.textContent=title;cinemaVideo.src=src;cinema.hidden=false;grid.classList.add('cinema-active');cinema.scrollIntoView({behavior:'smooth',block:'start'});cinemaVideo.play().catch(()=>{})}cinemaVideo.onplay=()=>pauseOthers(cinemaVideo);document.getElementById('cinema-close').onclick=closeCinema;document.getElementById('cinema-minimize').onclick=closeCinema;document.getElementById('cinema-fullscreen').onclick=()=>{if(cinemaVideo.requestFullscreen)cinemaVideo.requestFullscreen();else if(cinemaVideo.webkitEnterFullscreen)cinemaVideo.webkitEnterFullscreen()};document.addEventListener('keydown',event=>{if(cinema.hidden)return;if(event.key==='Escape')closeCinema();if(event.code==='Space'){event.preventDefault();cinemaVideo.paused?cinemaVideo.play():cinemaVideo.pause()}if(event.key==='ArrowRight')cinemaVideo.currentTime+=5;if(event.key==='ArrowLeft')cinemaVideo.currentTime=Math.max(0,cinemaVideo.currentTime-5)});async function downloadAlternative(url,mode){if(!url){notice('Kein gespeicherter YouTube-Link für diese Datei.',true);return}notice('Alternative Version wird gestartet …');let response=await fetch('/download-background',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({url:url,mode:mode,quality:'best',subtitles:'none'})});notice(response.ok?'✓ Download wurde gestartet.':'Download konnte nicht gestartet werden.',!response.ok)}</script>'''.replace('__FILTER__', selected_filter)
    cinema_style = '''<style>.media-launch{position:relative;border:0;padding:0;background:#070b10;border-radius:10px;overflow:hidden;cursor:pointer}.media-launch video{display:block;width:100%;max-height:180px;border-radius:10px;background:#070b10}.media-preview audio{width:100%;margin-top:8px}.media-play{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:54px;height:54px;display:grid;place-items:center;border-radius:50%;background:#09131edb;border:1px solid #78b9ff;color:#fff;font-size:22px;padding-left:3px}.media-cinema-label{position:absolute;right:8px;bottom:8px;padding:5px 8px;border-radius:999px;background:#09131edb;color:#d7ecff;font-size:11px;font-weight:800}.variant-switch{display:flex;gap:6px;margin-top:8px}.variant{width:auto;padding:6px 9px;border-radius:8px;background:#14263a;border:1px solid #345775;color:#cce4ff;font-weight:800;cursor:pointer}.variant.active{background:#1d5e87;border-color:#78b9ff;color:#fff}.move-media{display:flex;gap:7px;align-items:flex-start;grid-column:1/-1}.move-media>button{width:auto;padding:9px 10px;font-size:11px;white-space:nowrap}.cinema-stage{margin:18px 0;padding:18px;border:1px solid #4b759d;border-radius:18px;background:#0b1724;box-shadow:0 18px 55px #0008}.cinema-stage[hidden]{display:none}.cinema-stage header{display:flex;justify-content:space-between;align-items:center;padding:0 0 12px;border:0}.cinema-stage h2{margin:0 0 12px}.cinema-stage video{width:100%;max-height:64vh;background:#000;border-radius:12px}.cinema-actions{display:flex;gap:10px;margin-top:12px}.cinema-actions button,.cinema-close{width:auto}.cinema-close{padding:9px 12px;background:#203a53;border:1px solid #426c97;border-radius:10px;color:#fff;font-weight:800;cursor:pointer}#library-media-grid.cinema-active{display:flex;grid-template-columns:none;gap:14px;overflow-x:auto;overflow-y:hidden;padding:4px 2px 14px;scroll-snap-type:x mandatory}#library-media-grid.cinema-active .media-card{display:grid!important;flex:0 0 min(270px,76vw);scroll-snap-align:start}</style>'''
    library_enhancement = '''<script>document.addEventListener('DOMContentLoaded',()=>{let grid=document.getElementById('library-media-grid'),filters=document.querySelector('.filters');let playlist=document.createElement('button');playlist.type='button';playlist.className='filter';playlist.textContent='📚 Playlists';filters.appendChild(playlist);function show(predicate){grid.querySelectorAll('.media-card').forEach(card=>card.style.display=predicate(card)?'grid':'none')}playlist.onclick=()=>{document.querySelectorAll('.filter').forEach(button=>button.classList.toggle('active',button===playlist));show(card=>(card.dataset.videoPath||card.dataset.audioPath||'').includes('/Playlists/'))};grid.querySelectorAll('.media-card').forEach(card=>{let path=card.dataset.videoPath||card.dataset.audioPath||'';if(!path.includes('/Playlists/'))return;let key=path.split('/Playlists/')[1].split('/')[0],actions=card.querySelector('.actions'),button=document.createElement('button');button.type='button';button.className='secondary';button.textContent='📚 Playlist ansehen';button.onclick=()=>{document.querySelectorAll('.filter').forEach(item=>item.classList.remove('active'));show(other=>{let otherPath=other.dataset.videoPath||other.dataset.audioPath||'';return otherPath.includes('/Playlists/'+key+'/')});grid.scrollIntoView({behavior:'smooth',block:'start'})};actions.prepend(button)})})</script>'''
    # The playlist link above opens a real overview; do not add the former
    # client-side filter that only hid individual video cards.
    library_enhancement = '''<script>document.addEventListener('DOMContentLoaded',()=>{let search=document.getElementById('library-search'),grid=document.getElementById('library-media-grid'),importButton=document.getElementById('import-media-folder');if(importButton)importButton.onclick=async()=>{let original=importButton.textContent;importButton.disabled=true;importButton.textContent='Ordner auswählen …';try{let response=await fetch('/choose-library',{method:'POST'}),result=await response.json();if(result.path){location.href='/library?message='+encodeURIComponent('✓ Medienordner importiert. Die Dateien bleiben am ursprünglichen Ort.')}else{importButton.disabled=false;importButton.textContent=original}}catch(error){alert('Der Medienordner konnte nicht ausgewählt werden.');importButton.disabled=false;importButton.textContent=original}};if(!search||!grid)return;search.oninput=()=>{let term=search.value.toLowerCase();if(!term){document.querySelector('.filter.active')?.click();return}grid.querySelectorAll('.media-card').forEach(card=>{let text=(card.textContent+' '+card.dataset.playlistName).toLowerCase();card.style.display=text.includes(term)?'grid':'none'})}})</script>'''
    metadata_editor = '''<script>window.editMediaMetadata=async function(button){let card=button.closest('.media-card'),title=prompt('Titel in der Mediathek:',card.dataset.metaTitle||'');if(title===null)return;let channel=prompt('Kanal oder Künstler (optional):',card.dataset.metaChannel||'');if(channel===null)return;let source_url=prompt('YouTube- oder Quell-Link (optional):',card.dataset.metaUrl||'');if(source_url===null)return;button.disabled=true;try{let response=await fetch('/media-metadata',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({path:card.dataset.primaryPath,title,channel,source_url})});if(!response.ok)throw Error();location.reload()}catch(error){button.disabled=false;alert('Die Informationen konnten nicht gespeichert werden. Ein Link muss mit https:// beginnen.')}};</script>'''
    # Use a visible in-app form instead of browser prompt dialogs.  Those are
    # unreliable in the macOS web-app wrapper.
    metadata_editor = '''<style>.metadata-dialog{border:1px solid #4c789f;border-radius:18px;background:#0c1a29;color:#eef6ff;max-width:min(520px,92vw);padding:0;box-shadow:0 24px 80px #000b}.metadata-dialog::backdrop{background:#02070caa}.metadata-dialog form{display:grid;gap:12px;padding:20px}.metadata-dialog label{display:grid;gap:6px;font-weight:800}.metadata-dialog input{width:100%;box-sizing:border-box}.metadata-dialog menu{display:flex;justify-content:flex-end;gap:9px;margin:4px 0 0;padding:0}.metadata-dialog button{width:auto}</style><script>window.editMediaMetadata=function(button){let card=button.closest('.media-card'),dialog=document.getElementById('media-metadata-dialog');if(!dialog){dialog=document.createElement('dialog');dialog.id='media-metadata-dialog';dialog.className='metadata-dialog';dialog.innerHTML='<form method="dialog"><h2>Infos bearbeiten</h2><p class="sub">Diese Angaben erscheinen nur in UTUBE MAC.</p><label>Titel<input name="title"></label><label>Kanal oder Künstler<input name="channel"></label><label>YouTube- oder Quell-Link<input name="source_url" placeholder="https://…"></label><menu><button value="cancel" class="secondary">Abbrechen</button><button value="save">Speichern</button></menu></form>';document.body.appendChild(dialog);dialog.querySelector('form').addEventListener('submit',async event=>{if(event.submitter&&event.submitter.value==='cancel')return;event.preventDefault();let form=event.currentTarget,data={path:dialog.dataset.path,title:form.title.value,channel:form.channel.value,source_url:form.source_url.value};let response=await fetch('/media-metadata',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});if(response.ok){dialog.close();location.reload()}else alert('Bitte nutze für einen Link https:// oder lasse das Feld frei.')})}dialog.dataset.path=card.dataset.primaryPath;dialog.querySelector('[name=title]').value=card.dataset.metaTitle||'';dialog.querySelector('[name=channel]').value=card.dataset.metaChannel||'';dialog.querySelector('[name=source_url]').value=card.dataset.metaUrl||'';dialog.showModal();dialog.querySelector('[name=title]').focus()}</script>'''
    seek_optimizer = ''''''
    playlist_close = '</div></section>' if selected_playlist else ''
    detail_style = '''<style>.playlist-detail{display:grid;grid-template-columns:minmax(240px,320px) 1fr;gap:20px;margin:16px 0}.playlist-detail aside{padding:17px;border:1px solid #3b6686;border-radius:18px;background:linear-gradient(160deg,#284474,#101b2a)}.playlist-detail-cover{width:100%;max-height:210px;object-fit:cover;border-radius:12px;background:#07111b}.playlist-detail h2{margin-top:13px}.playlist-description{white-space:pre-line;color:#d4dfeb;line-height:1.45;font-size:14px;max-height:260px;overflow:auto}.playlist-detail-list{min-width:0}.playlist-detail-list #library-media-grid{grid-template-columns:1fr}.playlist-detail-list .media-card{grid-template-columns:170px 1fr;align-items:start}.playlist-detail-list .media-preview{min-width:150px}.playlist-detail-list .actions{grid-template-columns:repeat(2,minmax(120px,1fr))}@media(max-width:720px){.playlist-detail{grid-template-columns:1fr}.playlist-detail-list .media-card{grid-template-columns:1fr}}</style>''' if selected_playlist else ''
    import_panel = '<div class="actions"><button type="button" class="secondary" id="import-media-folder">📁 Bestehenden Medienordner importieren</button><span class="hint">Dateien werden nicht kopiert oder verändert.</span></div>'
    # The shared shell supplies navigation on every screen, including this one.
    library_sidebar = ''
    inner = '<section class="panel library-shell">' + library_sidebar + '<div class="library-content"><h2>Deine Downloads</h2>' + filters + advanced_controls + cinema_stage + playlist_detail + '<div id="library-media-grid" class="media-grid">' + "".join(cards or ['<p class="sub">Noch keine Medien vorhanden.</p>']) + "</div>" + playlist_close + "</div></section>"
    library_tv_layout = '''<style>
    /* Use the identical full-width canvas as the start page.  The former
       1540px cap was a leftover from the previous, separate library UI. */
    .wrap{box-sizing:border-box;width:100%!important;max-width:none!important;padding-left:28px!important;padding-right:28px!important}
    /* Navigation is shared in the left sidebar; do not repeat an app title
       or the obsolete design selector above the library. */
    .app-main > header{display:none!important}
    .library-shell{display:grid;grid-template-columns:minmax(0,1fr);gap:26px;max-width:none;margin:18px 0;padding:20px;background:linear-gradient(135deg,#101e2d,#09131e)}
    .library-content{min-width:0}.library-content>h2{font-size:24px;letter-spacing:-.03em;margin-top:7px}.library-sidebar{position:sticky;top:18px;align-self:start;display:grid;gap:6px;padding:8px 12px 14px;border-right:1px solid #294b65}.library-brand{padding:8px 10px 19px;color:#f3f8ff;font-weight:900;font-size:20px;line-height:.82;letter-spacing:-.08em}.library-brand span{color:#79c8ff}.library-sidebar a,.library-sidebar button{display:flex;align-items:center;gap:10px;width:100%;box-sizing:border-box;padding:10px;border:0;border-radius:10px;background:transparent;color:#a9c1d3;text-align:left;font:700 14px -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;text-decoration:none}.library-sidebar a:hover,.library-sidebar button:hover,.library-sidebar .is-current{background:#193a56;color:#f1f8ff}.library-sidebar .is-current{box-shadow:inset 3px 0 #73baff}.library-content .media-grid{grid-template-columns:repeat(auto-fill,minmax(245px,1fr));gap:17px;align-items:stretch;margin-top:20px}.library-content .media-card{min-height:0;padding:10px 10px 46px;border-radius:15px;background:linear-gradient(145deg,#132b40,#0b1724);transition:transform .16s ease,border-color .16s ease,box-shadow .16s ease}.library-content .media-card:hover{transform:translateY(-3px);border-color:#70b8ed;box-shadow:0 18px 38px #0008}.library-content .media-launch,.library-content .media-launch video{width:100%;max-height:none;aspect-ratio:16/9;object-fit:cover;border-radius:10px}.library-content .media-card>b{font-size:15px;line-height:1.22;letter-spacing:-.015em;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}.library-content .playlist-group,.library-content .variant-details,.library-content .hint{font-size:12px}.library-content .type-badge{top:18px;right:18px}.library-content .filters{display:grid;grid-template-columns:auto auto auto auto minmax(180px,1fr) minmax(140px,190px);align-items:center}.library-content .filters input,.library-content .filters select{margin:0}.library-settings-dialog{border:1px solid #4e7ea6;border-radius:18px;background:#0b1724;color:#edf6ff;box-shadow:0 28px 80px #000c;padding:0;width:min(460px,92vw)}.library-settings-dialog::backdrop{background:#02070bb8}.library-settings-dialog form{display:grid;gap:16px;padding:22px}.library-settings-dialog h2{margin:0}.library-settings-dialog label{display:grid;gap:7px;font-weight:800}.library-settings-dialog menu{display:flex;justify-content:flex-end;gap:9px;margin:4px 0 0;padding:0}.library-settings-dialog button{width:auto}.library-settings-dialog .checkline{display:flex;align-items:center;color:#c7d9e8}.library-settings-dialog .checkline input{width:auto;margin:0 9px 0 0}
    body[data-library-density="compact"] .library-content .media-grid{grid-template-columns:repeat(auto-fill,minmax(205px,1fr));gap:12px}body[data-library-density="compact"] .library-content .media-card>b{font-size:13px}body[data-library-density="compact"] .library-content .media-card{padding:8px 8px 43px}
    @media(max-width:900px){.wrap{padding:16px!important}.library-shell{grid-template-columns:1fr;padding:14px;gap:13px}.library-sidebar{position:static;grid-template-columns:repeat(4,minmax(0,1fr));border-right:0;border-bottom:1px solid #294b65;padding:0 0 12px}.library-brand{display:none}.library-sidebar a,.library-sidebar button{justify-content:center}.library-sidebar span{display:none}.library-content .filters{grid-template-columns:repeat(4,auto) minmax(150px,1fr)}.library-content .filters input{grid-column:1/-1}.library-content .filters select{grid-column:span 2}}
    .library-content .filters{grid-template-columns:auto auto auto auto minmax(220px,1fr);margin:12px 0}.library-content .filters input{margin:0}.library-advanced{margin:0 0 16px}.library-advanced summary{display:inline-flex;padding:7px 10px;color:#a9c7df;font-size:13px;font-weight:800;cursor:pointer;list-style:none}.library-advanced summary::-webkit-details-marker{display:none}.library-advanced summary:before{content:'⌘ ';color:#75c1ff}.library-advanced-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;padding:12px;border:1px solid #294b65;border-radius:13px;background:#0b1724}.library-advanced-grid .actions{grid-column:1/-1;display:flex;align-items:center;margin:0}.library-advanced-grid .actions button{max-width:360px}.library-advanced-grid .actions .hint{margin-left:10px}.library-advanced-grid select{margin:0}
    @media(max-width:560px){.library-content .media-grid{grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:10px}.library-content .filters{display:flex}.library-content .filters input{width:100%}.library-advanced-grid{grid-template-columns:1fr}.library-advanced-grid .actions{display:grid}.library-advanced-grid .actions .hint{margin:8px 0 0}.library-sidebar{grid-template-columns:repeat(4,1fr)}.library-sidebar a,.library-sidebar button{font-size:18px;padding:9px 4px}}
    </style><script>document.addEventListener('DOMContentLoaded',()=>{let dialog=document.createElement('dialog');dialog.className='library-settings-dialog';dialog.innerHTML='<form method="dialog"><h2>⚙ Einstellungen</h2><p class="sub">Darstellung und Mediathek auf diesem Mac anpassen.</p><label>Kartengröße<select id="library-density"><option value="large">Groß &amp; übersichtlich</option><option value="compact">Kompakt</option></select></label><label class="checkline"><input id="library-resume-visible" type="checkbox">Weitersehen anzeigen</label><p class="hint">Weitere Video-Aktionen bleiben im Menü ⋯ jeder Karte.</p><menu><button value="cancel" class="secondary">Abbrechen</button><button value="save">Fertig</button></menu></form>';document.body.appendChild(dialog);let density=dialog.querySelector('#library-density'),resume=dialog.querySelector('#library-resume-visible'),apply=()=>{document.body.dataset.libraryDensity=localStorage.getItem('utube-mac-library-density')||'large';let hidden=localStorage.getItem('utube-mac-hide-resume')==='1';document.querySelectorAll('.continue-watching').forEach(node=>node.hidden=hidden)};apply();document.getElementById('library-settings-open')?.addEventListener('click',()=>{density.value=localStorage.getItem('utube-mac-library-density')||'large';resume.checked=localStorage.getItem('utube-mac-hide-resume')!=='1';dialog.showModal()});dialog.addEventListener('close',()=>{if(dialog.returnValue!=='save')return;localStorage.setItem('utube-mac-library-density',density.value);localStorage.setItem('utube-mac-hide-resume',resume.checked?'0':'1');apply()})})</script>'''
    player_ui = '''<style>.custom-player-controls{display:flex;align-items:center;gap:9px;margin-top:10px;padding:9px;border:1px solid #315979;border-radius:11px;background:#07111b}.custom-player-controls button{width:auto;padding:8px 10px}.custom-player-controls input{margin:0;padding:0;border:0;accent-color:#5e96ff}.custom-player-controls #cinema-seek{flex:1}.custom-player-controls #cinema-volume{width:78px}.custom-player-controls #cinema-time{font:12px ui-monospace,monospace;color:#cce1f3;white-space:nowrap}@media(max-width:600px){.custom-player-controls{flex-wrap:wrap}.custom-player-controls #cinema-seek{flex-basis:100%;order:3}}</style><script>document.addEventListener('DOMContentLoaded',()=>{let video=document.getElementById('cinema-video'),toggle=document.getElementById('cinema-toggle'),seek=document.getElementById('cinema-seek'),time=document.getElementById('cinema-time'),mute=document.getElementById('cinema-mute'),volume=document.getElementById('cinema-volume');let format=value=>{value=Math.floor(value||0);return Math.floor(value/60)+':'+String(value%60).padStart(2,'0')};let update=()=>{let duration=video.duration||0;seek.value=duration?Math.round(video.currentTime/duration*1000):0;time.textContent=format(video.currentTime)+' / '+format(duration);toggle.textContent=video.paused?'▶':'❚❚';mute.textContent=video.muted||video.volume===0?'🔇':'🔊'};toggle.onclick=()=>video.paused?video.play():video.pause();video.addEventListener('timeupdate',update);video.addEventListener('loadedmetadata',update);video.addEventListener('play',update);video.addEventListener('pause',update);seek.oninput=()=>{if(video.duration)video.currentTime=video.duration*(seek.value/1000)};volume.oninput=()=>{video.volume=Number(volume.value);video.muted=video.volume===0;update()};mute.onclick=()=>{video.muted=!video.muted;update()}})</script>'''
    # Card thumbnails already have a poster image. Never attach a video URL
    # to every card; that competes with the movie the user actually selects.
    script = script.replace("video.preload='metadata';video.src=src;video.poster=box.dataset.videoPoster||''", "video.preload='none';video.poster=box.dataset.videoPoster||''")
    # Cards must never fetch metadata for every large video at once.  On a
    # library with many downloads that competes with the selected movie.
    # Metadata preload gives the local player duration/seek data without
    # decoding complete movies in every card.
    player_loading_guard = '''<script>(()=>{})()</script>'''
    player_boost = '''<script>(()=>{let original=window.openCinema;if(!original)return;let key=src=>'utube-mac-playback:'+src,lastSaved=0;function note(text){let title=document.getElementById('cinema-title'),old=document.getElementById('cinema-resume-note');if(!old){old=document.createElement('small');old.id='cinema-resume-note';old.className='hint';title.after(old)}old.textContent=text}function save(video,src){if(!src||!isFinite(video.currentTime))return;let duration=video.duration||0;if(duration&&video.currentTime>=duration-12)localStorage.removeItem(key(src));else localStorage.setItem(key(src),JSON.stringify({position:video.currentTime,updated:Date.now()}))}window.openCinema=(src,title)=>{let video=document.getElementById('cinema-video');video.controls=true;video.preload='auto';video.onloadedmetadata=()=>{let saved;try{saved=JSON.parse(localStorage.getItem(key(src))||'null')}catch(error){}if(saved&&saved.position>4&&saved.position<(video.duration||Infinity)-12){video.currentTime=saved.position;note('↻ Fortsetzung bei '+Math.floor(saved.position/60)+':'+String(Math.floor(saved.position%60)).padStart(2,'0'))}else note('')};video.ontimeupdate=()=>{if(Date.now()-lastSaved>5000){save(video,src);lastSaved=Date.now()}};video.onpause=()=>save(video,src);video.onended=()=>localStorage.removeItem(key(src));original(src,title)};window.addEventListener('pagehide',()=>{let video=document.getElementById('cinema-video');if(video&&video.currentSrc)save(video,video.currentSrc)})})()</script>'''
    native_player_style = '''<style>.custom-player-controls{display:none!important}.cinema-stage video{outline:none;box-shadow:0 16px 44px #0009}.cinema-stage{background:linear-gradient(145deg,#0d1a29,#071018)}</style>'''
    player_keyboard = '''<script>document.addEventListener('keydown',event=>{let cinema=document.getElementById('cinema-player'),video=document.getElementById('cinema-video');if(!cinema||cinema.hidden||!video)return;if(event.code==='Space'||event.code==='KeyK'){event.preventDefault();event.stopImmediatePropagation();video.paused?video.play():video.pause()}},true)</script>'''
    continue_watching = '''<style>.continue-watching{margin:0 0 18px;padding:15px;border:1px solid #35668e;border-radius:15px;background:linear-gradient(135deg,#102b42,#0a1725)}.continue-watching header{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px}.continue-watching h3{margin:0}.continue-list{display:flex;gap:10px;overflow-x:auto;padding-bottom:3px}.continue-item{flex:0 0 min(250px,72vw);padding:11px;border:1px solid #315b7c;border-radius:11px;background:#0b1622;color:#eff7ff;text-align:left;cursor:pointer}.continue-item:hover{border-color:#7abaff}.continue-item b,.continue-item small{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.continue-item small{margin-top:5px;color:#a9c7df}.continue-progress{height:6px;border-radius:999px;background:#152d42;overflow:hidden;margin-top:9px}.continue-progress span{display:block;height:100%;background:linear-gradient(90deg,#50d1ae,#669cff)}</style><script>document.addEventListener('DOMContentLoaded',()=>{let grid=document.getElementById('library-media-grid');if(!grid)return;let entries=[];for(let index=0;index<localStorage.length;index++){let storageKey=localStorage.key(index);if(!storageKey||!storageKey.startsWith('utube-mac-playback:'))continue;try{let saved=JSON.parse(localStorage.getItem(storageKey));if(saved&&saved.position>4)entries.push({src:storageKey.slice('utube-mac-playback:'.length),...saved})}catch(error){}}let cards=[...grid.querySelectorAll('.media-card')],items=entries.map(entry=>{let card=cards.find(item=>item.querySelector('.media-preview')?.dataset.videoSrc===entry.src);if(!card)return null;return {...entry,title:card.dataset.metaTitle||card.querySelector('b')?.textContent||'Video'}}).filter(Boolean).sort((a,b)=>b.updated-a.updated).slice(0,12);if(!items.length)return;let section=document.createElement('section');section.className='continue-watching';section.innerHTML='<header><h3>▶ Weitersehen</h3><button type="button" class="secondary">Liste leeren</button></header><div class="continue-list"></div>';section.querySelector('button').onclick=()=>{items.forEach(item=>localStorage.removeItem('utube-mac-playback:'+item.src));section.remove()};let list=section.querySelector('.continue-list');items.forEach(item=>{let button=document.createElement('button');button.type='button';button.className='continue-item';let minutes=Math.floor(item.position/60),seconds=String(Math.floor(item.position%60)).padStart(2,'0');button.innerHTML='<b>'+item.title.replace(/</g,'&lt;')+'</b><small>Fortsetzen bei '+minutes+':'+seconds+'</small><div class="continue-progress"><span style="width:'+Math.min(96,Math.max(3,(item.position/(item.duration||item.position*2))*100))+'%"></span></div>';button.onclick=()=>window.openCinema&&window.openCinema(item.src,item.title);list.appendChild(button)});grid.before(section)})</script>'''
    card_resume_status = '''<style>.resume-chip{display:block;width:max-content;max-width:100%;margin-top:7px;padding:4px 7px;border-radius:999px;background:#173d52;border:1px solid #397b96;color:#aeefff;font-size:11px;font-weight:800}</style><script>document.addEventListener('DOMContentLoaded',()=>{document.querySelectorAll('.media-card').forEach(card=>{let src=card.querySelector('.media-preview')?.dataset.videoSrc,saved;try{saved=JSON.parse(localStorage.getItem('utube-mac-playback:'+src)||'null')}catch(error){}if(!saved||saved.position<5)return;let minutes=Math.floor(saved.position/60),seconds=String(Math.floor(saved.position%60)).padStart(2,'0'),chip=document.createElement('small');chip.className='resume-chip';chip.textContent='▶ Fortsetzen bei '+minutes+':'+seconds;card.querySelector('b')?.after(chip)})})</script>'''
    reset_playback = '''<script>document.addEventListener('DOMContentLoaded',()=>{document.querySelectorAll('.media-card').forEach(card=>{let src=card.querySelector('.media-preview')?.dataset.videoSrc;if(!src||!localStorage.getItem('utube-mac-playback:'+src))return;let button=document.createElement('button');button.type='button';button.className='secondary';button.textContent='↺ Wiedergabe zurücksetzen';button.onclick=()=>{localStorage.removeItem('utube-mac-playback:'+src);card.querySelector('.resume-chip')?.remove();button.remove()};card.querySelector('.actions.compact')?.appendChild(button)})})</script>'''
    library_sorting = r'''<script>document.addEventListener('DOMContentLoaded',()=>{let grid=document.getElementById('library-media-grid'),select=document.getElementById('library-sort');if(!grid||!select)return;let original=[...grid.querySelectorAll('.media-card')],size=card=>{let text=card.querySelector('.variant-details')?.textContent||'',match=text.match(/([\d.,]+)\s*(GB|MB|KB)/i);if(!match)return 0;let value=Number(match[1].replace(',','.')),unit=match[2].toUpperCase();return value*(unit==='GB'?1e9:unit==='MB'?1e6:1e3)};select.onchange=()=>{let cards=[...grid.querySelectorAll('.media-card')];if(select.value==='title')cards.sort((a,b)=>(a.querySelector('b')?.textContent||'').localeCompare(b.querySelector('b')?.textContent||'',undefined,{sensitivity:'base'}));else if(select.value==='size')cards.sort((a,b)=>size(b)-size(a));else cards.sort((a,b)=>original.indexOf(a)-original.indexOf(b));cards.forEach(card=>grid.appendChild(card))}})</script>'''
    playlist_filter_script = '''<script>document.addEventListener('DOMContentLoaded',()=>{let select=document.getElementById('library-playlist-filter'),grid=document.getElementById('library-media-grid');if(!select||!grid)return;let apply=()=>{let wanted=select.value;if(wanted==='ALL')return;grid.querySelectorAll('.media-card').forEach(card=>{if(card.dataset.playlistName!==wanted)card.style.display='none'})};select.onchange=()=>{document.querySelector('.filter.active')?.click();apply()};document.querySelectorAll('.filter,#library-path-filter,#library-search').forEach(control=>{let event=control.matches('.filter')?'click':control.id==='library-search'?'input':'change';control.addEventListener(event,()=>setTimeout(apply,0))})})</script>'''
    favorites_ui = '''<style>.favorite-toggle{margin-left:auto;width:auto!important;padding:7px 9px!important;border-color:#82673a!important;color:#ffd66d!important}.favorite-toggle.is-favorite{background:#634b18!important;color:#fff0b0!important}.filter.favorites{border-color:#82673a;color:#ffe49a}</style><script>document.addEventListener('DOMContentLoaded',()=>{let grid=document.getElementById('library-media-grid'),filters=document.querySelector('.filters');if(!grid||!filters)return;let key='utube-mac-favorites',read=()=>new Set(JSON.parse(localStorage.getItem(key)||'[]')),write=set=>localStorage.setItem(key,JSON.stringify([...set]));let favorites=read(),favoriteFilter=document.createElement('button');favoriteFilter.type='button';favoriteFilter.className='filter favorites';favoriteFilter.textContent='★ Favoriten';filters.appendChild(favoriteFilter);function refresh(card){let path=card.dataset.primaryPath,button=card.querySelector('.favorite-toggle'),selected=favorites.has(path);button.textContent=selected?'★ Favorit':'☆ Favorit';button.classList.toggle('is-favorite',selected)}grid.querySelectorAll('.media-card').forEach(card=>{let button=document.createElement('button');button.type='button';button.className='secondary favorite-toggle';button.onclick=()=>{let path=card.dataset.primaryPath;if(favorites.has(path))favorites.delete(path);else favorites.add(path);write(favorites);refresh(card);if(favoriteFilter.classList.contains('active')&&!favorites.has(path))card.style.display='none'};card.querySelector('.actions.compact')?.appendChild(button);refresh(card)});favoriteFilter.onclick=()=>{document.querySelectorAll('.filter').forEach(item=>item.classList.toggle('active',item===favoriteFilter));grid.querySelectorAll('.media-card').forEach(card=>card.style.display=favorites.has(card.dataset.primaryPath)?'grid':'none')}})</script>'''
    missing_source_filter = '''<style>.filter.missing-source{border-color:#7b688f;color:#dfcffd}</style><script>document.addEventListener('DOMContentLoaded',()=>{let grid=document.getElementById('library-media-grid'),filters=document.querySelector('.filters');if(!grid||!filters)return;let button=document.createElement('button');button.type='button';button.className='filter missing-source';button.textContent='◇ Ohne Quelle';filters.appendChild(button);button.onclick=()=>{document.querySelectorAll('.filter').forEach(item=>item.classList.toggle('active',item===button));grid.querySelectorAll('.media-card').forEach(card=>card.style.display=card.dataset.metaUrl?'none':'grid')}})</script>'''
    playlist_repair = '''<script>window.repairPlaylist=async function(url,quality){if(!confirm('Nur die fehlenden Videos dieser Playlist nachladen? Bereits vorhandene Dateien werden übersprungen.'))return;let response=await fetch('/download-background',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({url,mode:'playlist-mp4',quality:quality||'720',subtitles:'none'})});if(response.ok)alert('✓ Prüfung und Nachladen der fehlenden Videos wurde im Hintergrund gestartet.');else alert('Die Playlist konnte nicht gestartet werden. Bitte versuche es später erneut.')};</script>'''
    macos_player = '''<script>document.addEventListener('DOMContentLoaded',()=>{document.querySelectorAll('.media-card').forEach(card=>{let path=card.dataset.videoPath||card.dataset.audioPath;if(!path)return;let button=document.createElement('button');button.type='button';button.className='secondary';button.textContent='↗ In macOS öffnen';button.title='Mit der Standard-App deines Macs öffnen';button.onclick=()=>fetch('/open-media?path='+encodeURIComponent(path));card.querySelector('.actions.compact')?.appendChild(button)})})</script>'''
    source_link_ui = r'''<style>.media-info-dialog{width:min(620px,92vw);border:1px solid #4a759b;border-radius:16px;background:#0b1724;color:#edf6ff;box-shadow:0 22px 70px #000b;padding:0}.media-info-dialog::backdrop{background:#02070bb8}.media-info-dialog>div{padding:20px}.media-info-dialog h2{margin:0 0 8px}.media-info-dialog .facts{display:flex;flex-wrap:wrap;gap:7px;margin:12px 0}.media-info-dialog .facts span{padding:5px 8px;border-radius:999px;background:#17334a;border:1px solid #315979}.media-info-dialog .description{white-space:pre-wrap;max-height:38vh;overflow:auto;line-height:1.5;color:#d5e1ed}</style><script>document.addEventListener('DOMContentLoaded',()=>{let dialog;function esc(value){return String(value||'').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]))}function showInfo(card){if(!dialog){dialog=document.createElement('dialog');dialog.className='media-info-dialog';document.body.append(dialog)}let url=card.dataset.metaUrl||'',title=card.dataset.metaTitle||'Informationen',channel=card.dataset.metaChannel||'';dialog.innerHTML='<div><h2>'+esc(title)+'</h2><p class="sub">Informationen werden geladen …</p><button type="button" class="secondary">Schließen</button></div>';dialog.querySelector('button').onclick=()=>dialog.close();dialog.showModal();if(!/^https?:\/\//.test(url)){dialog.querySelector('.sub').textContent=channel?'Kanal: '+channel:'Für diese Datei ist kein YouTube-Link gespeichert.';return}fetch('/video-info?url='+encodeURIComponent(url)).then(response=>response.json()).then(data=>{let facts=[];if(data.channel)facts.push('👤 '+data.channel);if(data.published)facts.push('📅 '+data.published.slice(6)+'.'+data.published.slice(4,6)+'.'+data.published.slice(0,4));if(data.views)facts.push('▶ '+Number(data.views).toLocaleString('de-DE')+' Aufrufe');dialog.innerHTML='<div><h2>'+esc(data.title||title)+'</h2><div class="facts">'+facts.map(item=>'<span>'+esc(item)+'</span>').join('')+'</div><p class="description">'+esc(data.description||'Keine Beschreibung verfügbar.')+'</p><div class="actions"><button type="button" class="secondary" id="info-youtube">Auf YouTube öffnen</button><button type="button" class="secondary" id="info-close">Schließen</button></div></div>';dialog.querySelector('#info-close').onclick=()=>dialog.close();dialog.querySelector('#info-youtube').onclick=()=>fetch('/open-external?url='+encodeURIComponent(data.url||url))}).catch(()=>dialog.querySelector('.sub').textContent='Informationen konnten gerade nicht geladen werden.')}document.querySelectorAll('.media-card').forEach(card=>{let actions=card.querySelector('.actions.compact'),url=card.dataset.metaUrl;if(!actions)return;let info=document.createElement('button');info.type='button';info.className='secondary';info.textContent='ⓘ Informationen';info.onclick=()=>showInfo(card);actions.prepend(info);if(/^https?:\/\//.test(url||'')){let button=document.createElement('button');button.type='button';button.className='secondary';button.textContent='▶ Auf YouTube öffnen';button.onclick=()=>fetch('/open-external?url='+encodeURIComponent(url));actions.appendChild(button)}})})</script>'''
    info_corner = '''<style>.media-preview{position:relative}.media-info-corner{position:absolute;z-index:12;top:7px;right:7px;width:24px;height:24px;padding:0!important;border-radius:50%!important;background:#07121de8!important;border:1px solid #86bfff!important;color:#fff!important;font-size:13px!important;line-height:1!important;box-shadow:0 3px 12px #0009}.media-info-corner:hover{background:#245d88!important}</style><script>document.addEventListener('DOMContentLoaded',()=>{document.querySelectorAll('.media-card').forEach(card=>{let preview=card.querySelector('.media-preview'),menuInfo=[...card.querySelectorAll('.actions.compact button')].find(button=>button.textContent.includes('Informationen'));if(!preview||!menuInfo)return;menuInfo.style.display='none';let corner=document.createElement('button');corner.type='button';corner.className='media-info-corner';corner.title='Informationen zu diesem Video';corner.setAttribute('aria-label','Informationen zu diesem Video');corner.textContent='ⓘ';corner.onclick=event=>{event.preventDefault();event.stopPropagation();menuInfo.click()};preview.appendChild(corner)})})</script>'''
    info_corner += '''<style>.media-info-corner{left:7px!important;right:auto!important}</style>'''
    compact_card_actions = '''<style>.media-card{position:relative;content-visibility:auto;contain-intrinsic-size:0 350px}.media-more{position:absolute;right:12px;bottom:12px;z-index:20}.media-more summary{list-style:none;display:grid;place-items:center;width:34px;height:34px;border:1px solid #426a8c;border-radius:10px;background:#193650;color:#eef7ff;font-size:21px;font-weight:900;line-height:1;cursor:pointer}.media-more summary::-webkit-details-marker{display:none}.media-more[open] summary{background:#2a5a7f;border-color:#81baff}.media-menu-panel{position:absolute;right:0;bottom:42px;width:min(260px,78vw);display:grid;gap:7px;padding:10px;border:1px solid #4d799f;border-radius:13px;background:#0b1724;box-shadow:0 16px 42px #000b}.media-menu-panel button,.media-menu-panel a,.media-menu-panel form{width:100%;box-sizing:border-box;margin:0}.media-menu-panel .move-media{display:grid;grid-template-columns:1fr;gap:7px}.media-menu-panel .move-media>button{width:100%}.media-menu-panel .favorite-toggle{margin:0!important}.media-menu-panel .folder{display:block;text-align:center}.media-card .actions.compact{display:none}</style><script>document.addEventListener('DOMContentLoaded',()=>{document.querySelectorAll('.media-card').forEach(card=>{let actions=card.querySelector('.actions.compact');if(!actions||actions.dataset.compacted)return;actions.dataset.compacted='1';let details=document.createElement('details'),summary=document.createElement('summary'),panel=document.createElement('div');details.className='media-more';summary.title='Weitere Optionen';summary.textContent='⋯';panel.className='media-menu-panel';[...actions.children].forEach(item=>panel.appendChild(item));details.append(summary,panel);actions.replaceWith(details);document.addEventListener('click',event=>{if(!details.contains(event.target))details.removeAttribute('open')})})})</script>'''
    menu_polish = '''<style>
    #library-media-grid,.media-card,.media-more{overflow:visible!important}.media-card{content-visibility:visible!important;contain:none!important}.media-more{z-index:100!important}
    .media-menu-panel{width:min(220px,72vw)!important;gap:2px!important;padding:6px!important;border-radius:11px!important}
    .media-menu-panel button,.media-menu-panel a,.media-menu-panel form>button,.media-menu-panel .menu-move>summary{display:block;width:100%!important;min-height:30px!important;box-sizing:border-box!important;padding:6px 8px!important;margin:0!important;border:0!important;border-radius:7px!important;background:transparent!important;color:#d8e9f7!important;text-align:left!important;font-size:12px!important;font-weight:700!important;line-height:1.2!important;box-shadow:none!important}
    .media-menu-panel button:hover,.media-menu-panel a:hover,.media-menu-panel .menu-move>summary:hover{background:#1b3952!important}.media-menu-panel form>button.danger{background:#542334!important;color:#ffe4e9!important}.media-menu-panel .menu-move{margin:1px 0}.media-menu-panel .menu-move>summary{cursor:pointer;list-style:none}.media-menu-panel .menu-move>summary::-webkit-details-marker{display:none}.media-menu-panel .move-media{padding:5px 2px!important;gap:5px!important}.media-menu-panel .move-media select{font-size:11px!important;padding:5px!important}.media-menu-panel .move-media>button{background:#1b3952!important;text-align:center!important}.media-menu-panel .favorite-toggle{color:#ffda76!important}
    </style>'''
    youtube_cinema = r'''<style>#cinema-media-host iframe{width:100%;aspect-ratio:16/9;max-height:64vh;border:0;border-radius:12px;background:#000}.cinema-information{margin-top:14px;padding:11px 13px;border:1px solid #315979;border-radius:11px;background:#0a1520}.cinema-information summary{cursor:pointer;font-weight:800;color:#dceeff}.cinema-information p{white-space:pre-wrap;line-height:1.5;color:#d5e1ed}.cinema-info-facts{display:flex;gap:7px;flex-wrap:wrap;margin:10px 0}.cinema-info-facts span{padding:4px 7px;border-radius:999px;background:#17334a;border:1px solid #315979;font-size:12px}</style><script>document.addEventListener('DOMContentLoaded',()=>{let original=window.openCinema,video=document.getElementById('cinema-video'),frame=document.getElementById('cinema-youtube'),toggle=document.getElementById('cinema-youtube-toggle'),controls=document.querySelector('.custom-player-controls'),info=document.getElementById('cinema-info-content'),current={src:'',title:'',url:''};let escape=value=>String(value||'').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));let readableDate=value=>value&&/^\d{8}$/.test(value)?value.slice(6)+'.'+value.slice(4,6)+'.'+value.slice(0,4):'';let readableNumber=value=>Number(value||0).toLocaleString('de-DE');function videoId(url){try{let parsed=new URL(url),id=parsed.searchParams.get('v')||(/youtu\.be$/.test(parsed.hostname)?parsed.pathname.slice(1):'');return /^[\w-]{6,}$/.test(id)?id:''}catch(error){return''}}function showLocal(){frame.hidden=true;frame.src='';video.hidden=false;controls.hidden=false;toggle.textContent='Mit YouTube ansehen';video.play().catch(()=>{})}function showYouTube(){let id=videoId(current.url);if(!id)return;video.pause();video.hidden=true;controls.hidden=true;frame.src='https://www.youtube-nocookie.com/embed/'+encodeURIComponent(id)+'?autoplay=1&rel=0';frame.hidden=false;toggle.textContent='Lokal abspielen'}async function loadInfo(url){if(!url){info.textContent='Für diese ältere Datei ist kein YouTube-Link gespeichert.';return}info.textContent='YouTube-Informationen werden geladen …';try{let data=await fetch('/video-info?url='+encodeURIComponent(url)).then(response=>response.json());if(url!==current.url)return;let facts=[];if(data.channel)facts.push('👤 '+data.channel);if(data.published)facts.push('📅 '+readableDate(data.published));if(data.views)facts.push('▶ '+readableNumber(data.views)+' Aufrufe');let description=data.description||'Keine Beschreibung von YouTube verfügbar.';let channel=data.channel_url&&/^https?:/.test(data.channel_url)?'<p><a class="folder" target="_blank" rel="noopener" href="'+escape(data.channel_url)+'">Kanal auf YouTube öffnen</a> <a class="folder" target="_blank" rel="noopener" href="'+escape(data.url||url)+'">Kommentare auf YouTube lesen</a></p>':'<p><a class="folder" target="_blank" rel="noopener" href="'+escape(data.url||url)+'">Kommentare auf YouTube lesen</a></p>';info.innerHTML=(facts.length?'<div class="cinema-info-facts">'+facts.map(item=>'<span>'+escape(item)+'</span>').join('')+'</div>':'')+'<p>'+escape(description)+'</p>'+channel}catch(error){if(url===current.url)info.textContent='Die YouTube-Informationen konnten gerade nicht geladen werden.'}}window.openCinema=function(src,title,sourceUrl){current={src:src,title:title,url:sourceUrl||''};frame.hidden=true;frame.src='';video.hidden=false;controls.hidden=false;toggle.hidden=!videoId(current.url);toggle.textContent='Mit YouTube ansehen';original(src,title);loadInfo(current.url)};toggle.onclick=()=>frame.hidden?showYouTube():showLocal();let grid=document.getElementById('library-media-grid');grid?.querySelectorAll('.media-preview').forEach(preview=>{let button=preview.querySelector('.media-launch');if(button)button.onclick=()=>window.openCinema(preview.dataset.videoSrc,preview.dataset.title,preview.dataset.sourceUrl)});document.getElementById('cinema-close').addEventListener('click',()=>{frame.src='';frame.hidden=true;video.hidden=false;controls.hidden=false});document.getElementById('cinema-minimize').addEventListener('click',()=>{frame.src='';frame.hidden=true;video.hidden=false;controls.hidden=false})})</script>'''
    cinema_loader = '''<style>#cinema-media-host{position:relative;min-height:180px}#cinema-loading{position:absolute;right:14px;bottom:14px;display:flex;align-items:center;gap:8px;border-radius:999px;background:#06101be8;color:#e6f3ff;text-align:left;padding:9px 12px;z-index:2;pointer-events:none;box-shadow:0 6px 22px #0009;font-size:12px}#cinema-loading[hidden],#cinema-optimize[hidden]{display:none!important}.cinema-spinner{width:19px;height:19px;border:3px solid #315979;border-top-color:#74bdff;border-radius:50%;animation:cinema-spin .75s linear infinite;flex:0 0 auto}@keyframes cinema-spin{to{transform:rotate(360deg)}}#cinema-optimize{width:auto;font-size:12px;pointer-events:auto}</style><script>document.addEventListener('DOMContentLoaded',()=>{let video=document.getElementById('cinema-video'),loading=document.getElementById('cinema-loading'),label=document.getElementById('cinema-loading-text'),optimize=document.getElementById('cinema-optimize'),pause=document.getElementById('cinema-pause'),currentPath='',autoStarted=false,stalledTimer;let show=(text,repair)=>{label.textContent=text;loading.hidden=false;optimize.hidden=!repair},hide=()=>loading.hidden=true,refreshPause=()=>pause.textContent=video.paused?'▶ Weiter':'❚❚ Pause';pause.onclick=()=>{if(video.paused)video.play().catch(()=>{});else video.pause()};async function optimizeCurrent(){if(!currentPath||autoStarted)return;autoStarted=true;optimize.disabled=true;optimize.textContent='Vorbereitung läuft …';let response=await fetch('/optimize-media',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({path:currentPath})});if(response.ok){label.textContent='Die MP4 wird automatisch für schnellere Sprünge vorbereitet.';optimize.hidden=true}else{autoStarted=false;optimize.disabled=false;optimize.textContent='⚡ Für schnelleres Spulen vorbereiten'}}video.addEventListener('loadstart',()=>show('Video wird geladen …',false));video.addEventListener('waiting',()=>{if(video.paused)show('Video puffert …',false)});video.addEventListener('seeking',()=>show('Springe zur gewählten Stelle …',false));video.addEventListener('stalled',()=>{if(video.paused)show('Video benötigt noch Daten …',true);clearTimeout(stalledTimer);stalledTimer=setTimeout(()=>{if(!autoStarted&&currentPath&&video.readyState<3)optimizeCurrent()},2800)});video.addEventListener('canplay',hide);video.addEventListener('playing',()=>{hide();refreshPause()});video.addEventListener('pause',refreshPause);video.addEventListener('timeupdate',hide);video.addEventListener('seeked',hide);video.addEventListener('error',()=>show('Dieses Video konnte nicht direkt geöffnet werden.',true));let original=window.openCinema;window.openCinema=function(src,title,sourceUrl){clearTimeout(stalledTimer);autoStarted=false;currentPath=[...document.querySelectorAll('.media-preview')].find(item=>item.dataset.videoSrc===src)?.closest('.media-card')?.dataset.videoPath||'';show('Video wird vorbereitet …',false);refreshPause();original(src,title,sourceUrl)};optimize.onclick=()=>optimizeCurrent()})</script>'''
    native_player_bridge = '''<style>.cinema-actions #cinema-native,#cinema-optimize{display:none!important}</style>'''
    stability_guard = '''<script>document.addEventListener('DOMContentLoaded',()=>{let video=document.getElementById('cinema-video');if(!video)return;video.addEventListener('stalled',event=>{event.stopImmediatePropagation()},true)})</script>'''
    native_playback_guard = ''''''
    performance_mode = '''<script>document.addEventListener('DOMContentLoaded',()=>setTimeout(()=>{document.querySelectorAll('.media-card video').forEach(video=>{video.preload='none';video.pause();video.removeAttribute('src');video.load()});document.querySelectorAll('.media-card audio').forEach(audio=>audio.preload='none');window.downloadAlternative=async function(url,mode,quality='480'){if(!url){alert('Für diese Datei ist kein YouTube-Link gespeichert.');return}let label=quality==='480'?'kleine 480p-Version':'Alternative Version';if(!confirm(label+' im Hintergrund laden?'))return;let response=await fetch('/download-background',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({url:url,mode:mode,quality:quality,subtitles:'none'})});alert(response.ok?'✓ Download gestartet – die kleinere Datei erscheint anschließend in der Mediathek.':'Download konnte nicht gestartet werden.')};document.querySelectorAll('.media-card').forEach(card=>{let url=card.dataset.metaUrl,panel=card.querySelector('.media-menu-panel');if(!url||!panel)return;let fast=document.createElement('button');fast.type='button';fast.className='secondary';fast.textContent='⚡ Klein & schnell · 480p';fast.title='Lädt eine deutlich kleinere MP4-Datei für schnelles Abspielen';fast.onclick=()=>window.downloadAlternative(url,'single-mp4','480');panel.prepend(fast)})},250))</script>'''
    unified_settings_redirect = '''<script>document.addEventListener('click',event=>{let button=event.target.closest('#library-settings-open');if(!button)return;event.preventDefault();event.stopImmediatePropagation();location.href='/?settings=1'},true)</script>'''
    return layout("UTUBE MAC – Mediathek", "Abspielen, anhören und im Finder verwalten.", library_tv_layout + cinema_style + detail_style + native_player_style + inner + player_loading_guard + script + player_boost + player_keyboard + player_ui + youtube_cinema + cinema_loader + stability_guard + native_player_bridge + native_playback_guard + library_enhancement + metadata_editor + seek_optimizer + continue_watching + card_resume_status + reset_playback + library_sorting + playlist_filter_script + favorites_ui + missing_source_filter + playlist_repair + macos_player + source_link_ui + info_corner + compact_card_actions + menu_polish + performance_mode + unified_settings_redirect)

def storage_page():
    files = media_files(); total = sum(p.stat().st_size for p in files); largest = sorted(files, key=lambda p:p.stat().st_size, reverse=True)[:15]; duplicates = duplicate_groups(files)
    rows = "".join(f'<article class="file-row"><div><b>{html.escape(p.name)}</b><small>{readable_size(p.stat().st_size)} · {html.escape(str(p.relative_to(DOWNLOADS)))}</small></div><div class="row-actions"><a href="/reveal?path={urllib.parse.quote(str(p))}">Im Finder</a><form method="post" action="/action" onsubmit="return confirm(\'Diese Datei in den Papierkorb legen?\');"><input type="hidden" name="action" value="trash"><input type="hidden" name="path" value="{html.escape(str(p), quote=True)}"><button class="danger">Papierkorb</button></form></div></article>' for p in largest)
    duplicate_html = ""
    for index, group in enumerate(duplicates, 1):
        size = group[0].stat().st_size
        members = "".join(f'<article class="file-row"><div><b>{html.escape(p.name)}</b><small>{html.escape(str(p.relative_to(DOWNLOADS)))}</small></div><div class="row-actions"><a href="/reveal?path={urllib.parse.quote(str(p))}">Im Finder</a><form method="post" action="/action" onsubmit="return confirm(\'Diese doppelte Datei in den Papierkorb legen?\');"><input type="hidden" name="action" value="trash"><input type="hidden" name="path" value="{html.escape(str(p), quote=True)}"><button class="danger">Papierkorb</button></form></div></article>' for p in group)
        duplicate_html += f'<div class="duplicate-group"><b>Duplikat-Gruppe {index} · {len(group)} identische Dateien · jeweils {readable_size(size)}</b>{members}</div>'
    duplicate_card = card("Exakte Duplikate", str(sum(len(group) - 1 for group in duplicates)), "Vollständig verglichen – nur identische Dateien.")
    return layout("UTUBE MAC – Speicheranalyse", "Finde große Dateien und exakte Duplikate. Jede Bereinigung fragt einzeln nach.", f'<section class="grid">{card("Mediendateien", str(len(files)))}{card("Belegter Speicher", readable_size(total))}{duplicate_card}</section><section class="panel"><a href="/">← Zurück</a><h2>Größte Downloads</h2><div class="file-list">{rows or "<p class=\"sub\">Keine Dateien vorhanden.</p>"}</div></section><section class="panel"><h2>Exakte Duplikate</h2><p class="sub">Diese Dateien wurden nach Inhalt verglichen, nicht nur nach Namen. Lege nur die Kopie in den Papierkorb, die du nicht behalten möchtest.</p>{duplicate_html or "<p class=\"message\">Keine exakten Duplikate gefunden.</p>"}</section>')

def safari_youtube_tabs():
    script = '''tell application "Safari"
    set output to ""
    repeat with w in windows
        repeat with t in tabs of w
            set tabURL to URL of t
            if (tabURL contains "youtube.com/watch?v=") or (tabURL contains "youtube.com/shorts/") or (tabURL contains "youtube.com/playlist?list=") or (tabURL contains "youtu.be/") then
                set output to output & (name of t) & (ASCII character 9) & tabURL & linefeed
            end if
        end repeat
    end repeat
    return output
end tell'''
    try:
        result = subprocess.run(["osascript", "-e", script], capture_output=True, text=True, timeout=10)
        return [{"title": title.strip() or "YouTube", "url": url.strip()} for line in result.stdout.splitlines() if "\t" in line for title, url in [line.split("\t", 1)] if url.strip().startswith("http")]
    except Exception:
        return []

def safari_page_playlists():
    """Find public playlists for the YouTube page currently open in Safari."""
    safari_script = '''tell application "Safari"
        if not (exists front window) then return ""
        return URL of current tab of front window
    end tell'''
    try:
        safari = subprocess.run(["osascript", "-e", safari_script], capture_output=True, text=True, timeout=8)
        page_url = safari.stdout.strip()
        if safari.returncode != 0 or "youtube.com" not in page_url:
            return []

        # A single playlist page already is the only useful choice.
        if "/playlist?" in page_url and "list=" in page_url:
            preview = youtube_preview(page_url)
            return [{"url": page_url, "title": preview.get("title", "Diese YouTube-Playlist"), "thumbnail": preview.get("thumbnail", "")}]

        tool = shutil.which("yt-dlp")
        if not tool:
            return []
        result = subprocess.run(
            [tool, "--skip-download", "--flat-playlist", "--dump-json", page_url],
            capture_output=True, text=True, timeout=40,
        )
        found, seen = [], set()
        for line in result.stdout.splitlines():
            try:
                item = json.loads(line)
            except json.JSONDecodeError:
                continue
            playlist_id = str(item.get("id") or "")
            url = str(item.get("url") or item.get("webpage_url") or "")
            if "list=" not in url and playlist_id:
                url = f"https://www.youtube.com/playlist?list={playlist_id}"
            query = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
            identity = (query.get("list") or [playlist_id])[0]
            if not identity or identity in seen or not url.startswith("http"):
                continue
            thumbnails = item.get("thumbnails") or []
            thumbnail = str(item.get("thumbnail") or "")
            if not thumbnail and thumbnails:
                thumbnail = str(max(thumbnails, key=lambda image: int(image.get("width") or 0)).get("url") or "")
            seen.add(identity)
            found.append({"url": url, "title": str(item.get("title") or "YouTube-Playlist"), "thumbnail": thumbnail})
        for playlist in found:
            playlist["count"] = youtube_playlist_count(playlist["url"])
        return found[:80]
    except Exception:
        return []

def clipboard_youtube_link():
    try:
        value = subprocess.run(["pbpaste"], capture_output=True, text=True, timeout=2).stdout.strip()
        if value.startswith(("https://www.youtube.com/", "https://youtube.com/", "https://youtu.be/")):
            return value
    except Exception:
        pass
    return ""

def youtube_preview(url):
    if not url.startswith(("https://www.youtube.com/", "https://youtube.com/", "https://youtu.be/")): return {}
    tool = shutil.which("yt-dlp")
    if not tool: return {}
    try:
        result = subprocess.run([tool, "--skip-download", "--flat-playlist", "--playlist-items", "1", "--dump-single-json", url], capture_output=True, text=True, timeout=15)
        info = json.loads(result.stdout or "{}")
        thumbnails = info.get("thumbnails") or []
        thumbnail = info.get("thumbnail") or (max(thumbnails, key=lambda image: int(image.get("width") or 0)).get("url", "") if thumbnails else "")
        return {"title": str(info.get("playlist_title") or info.get("title") or "YouTube-Playlist"), "thumbnail": str(thumbnail), "playlist": bool(info.get("_type") == "playlist" or info.get("playlist_title") or "list=" in url), "channel": str(info.get("channel") or info.get("uploader") or ""), "duration": int(info.get("duration") or 0), "count": int(info.get("playlist_count") or info.get("n_entries") or 0)}
    except Exception:
        return {}

def youtube_video_metadata(url):
    """Fetch presentation data only when somebody opens one video."""
    if not url.startswith(("https://www.youtube.com/", "https://youtube.com/", "https://youtu.be/")):
        return {}
    # The bundled app can be launched with a minimal PATH that omits Homebrew.
    # Fall back explicitly so information buttons still work in the web app.
    tool = shutil.which("yt-dlp") or ("/opt/homebrew/bin/yt-dlp" if Path("/opt/homebrew/bin/yt-dlp").exists() else None)
    if not tool:
        return {}
    try:
        result = subprocess.run([tool, "--skip-download", "--no-warnings", "--dump-single-json", url], capture_output=True, text=True, timeout=25)
        info = json.loads(result.stdout or "{}")
        return {
            "title": str(info.get("title") or ""),
            "description": str(info.get("description") or "")[:12000],
            "channel": str(info.get("channel") or info.get("uploader") or ""),
            "channel_url": str(info.get("channel_url") or info.get("uploader_url") or ""),
            "published": str(info.get("upload_date") or ""),
            "views": int(info.get("view_count") or 0),
            "duration": int(info.get("duration") or 0),
            "id": str(info.get("id") or ""),
            "url": str(info.get("webpage_url") or url),
        }
    except Exception:
        return {}

def youtube_playlist_metadata(url):
    """Read public playlist presentation data without downloading media."""
    if "list=" not in url or not url.startswith(("https://www.youtube.com/", "https://youtube.com/")):
        return {}
    tool = shutil.which("yt-dlp")
    if not tool:
        return {}
    try:
        result = subprocess.run([tool, "--skip-download", "--flat-playlist", "--playlist-items", "1", "--dump-single-json", url], capture_output=True, text=True, timeout=20)
        info = json.loads(result.stdout or "{}")
        thumbnails = info.get("thumbnails") or []
        cover = info.get("thumbnail") or (max(thumbnails, key=lambda image: int(image.get("width") or 0)).get("url", "") if thumbnails else "")
        return {"title": str(info.get("playlist_title") or info.get("title") or ""), "description": str(info.get("description") or ""), "channel": str(info.get("uploader") or info.get("channel") or ""), "cover": str(cover)}
    except Exception:
        return {}

def youtube_playlist_items(url):
    if "list=" not in url or not url.startswith(("https://www.youtube.com/", "https://youtube.com/")): return []
    tool = shutil.which("yt-dlp")
    if not tool: return []
    try:
        result = subprocess.run([tool, "--skip-download", "--flat-playlist", "--playlist-end", "100", "--dump-json", url], capture_output=True, text=True, timeout=25)
        entries = []
        for line in result.stdout.splitlines():
            info = json.loads(line)
            video_id = str(info.get("id", ""))
            if video_id:
                thumbnails = info.get("thumbnails") or []
                thumbnail = info.get("thumbnail") or (max(thumbnails, key=lambda image: int(image.get("width") or 0)).get("url", "") if thumbnails else f"https://i.ytimg.com/vi/{video_id}/hqdefault.jpg")
                entries.append({"id": video_id, "title": str(info.get("title") or "Unbenanntes Video"), "thumbnail": str(thumbnail)})
        return entries
    except Exception:
        return []

def youtube_playlist_count(url):
    """Return the actual video count for one public YouTube playlist."""
    if "list=" not in url or not url.startswith(("https://www.youtube.com/", "https://youtube.com/")):
        return None
    if url in PLAYLIST_COUNT_CACHE:
        return PLAYLIST_COUNT_CACHE[url]
    tool = shutil.which("yt-dlp")
    if not tool:
        return None
    try:
        result = subprocess.run([tool, "--skip-download", "--flat-playlist", "--playlist-items", "1", "--dump-single-json", url], capture_output=True, text=True, timeout=20)
        count = json.loads(result.stdout or "{}").get("playlist_count")
        count = int(count) if count is not None else None
        PLAYLIST_COUNT_CACHE[url] = count
        return count
    except (Exception, ValueError, TypeError):
        return None

def queue_progress(queue_id):
    if not re.fullmatch(r"[A-Za-z0-9._-]+", queue_id): return []
    return [item for item in progress_jobs() if item.get("id", "").startswith(f"queue-{queue_id}-")]

def queue_is_running():
    """Avoid two queues writing the same playlist files at the same time."""
    return any(job.get("id", "").startswith("queue-") and job.get("active") and not job.get("done") for job in progress_jobs())

def health():
    rows = []
    for file in [INSTALLER, UPDATER, DOWNLOADER]:
        result = subprocess.run(["bash", "-n", str(file)], capture_output=True, text=True) if file.exists() else None
        rows.append((file.name, "Bereit" if result and result.returncode == 0 else "Fehlt oder fehlerhaft"))
    return rows

def utube_processes():
    """Return only local processes that belong to UTUBE MAC."""
    try:
        result = subprocess.run(["ps", "-axo", "pid=,command="], capture_output=True, text=True, timeout=4)
    except OSError:
        return []
    processes = []
    for line in result.stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        pid, _, command = line.partition(" ")
        lowered = command.lower()
        if "utube" in lowered or "127.0.0.1:8765" in lowered:
            processes.append((pid, command.strip()))
    return processes[:16]

def card(label, value, note=""):
    return f'<div class="card"><div class="label">{html.escape(label)}</div><div class="value">{html.escape(value)}</div><div class="note">{html.escape(note)}</div></div>'

def record_event(kind, text, details=""):
    EVENT_LOG.parent.mkdir(parents=True, exist_ok=True)
    with EVENT_LOG.open("a") as log:
        log.write(json.dumps({"time": time.time(), "kind": kind, "text": text, "details": details}, ensure_ascii=False) + "\n")

def support_file_events():
    """Surface meaningful local history from support files, without build noise."""
    allowed_suffixes = {".log", ".txt", ".json", ".jsonl", ".status"}
    ignored_parts = {"Build", "Products", "Intermediates.noindex", "Temp", "GitHub Repository"}
    keywords = ("download", "geladen", "fertig", "completed", "erfolg", "failed", "fehler", "abgebrochen", "cancel", "setup", "install", "update", "aktual", "shortcut", "ordner", "verschob", "papierkorb", "delete", "playlist", "safari")
    events = []
    for path in SUPPORT.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in allowed_suffixes or any(part in ignored_parts for part in path.parts):
            continue
        try:
            if path.stat().st_size > 1_000_000:
                continue
            relative = str(path.relative_to(SUPPORT))
            lowered = relative.lower()
            kind = "runtime" if relative.startswith("Runtime/") else "history" if relative.startswith("History/") else "settings" if relative.startswith("Settings/") else "support"
            raw = path.read_text(errors="replace")
            lines = [line.strip() for line in raw.splitlines() if line.strip()]
            matches = [line for line in lines if any(word in line.lower() for word in keywords)]
            if not matches:
                matches = [f"Datei aktualisiert: {path.name}"]
            for line in matches[-4:]:
                events.append({"time": path.stat().st_mtime, "kind": kind, "text": line[:260], "details": f"Quelle: {relative}", "support_path": relative})
        except (OSError, UnicodeError):
            continue
    return events

def save_problem_report(category, description, source):
    """Keep each user report as its own local, inspectable support file."""
    PROBLEM_REPORTS.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    report = PROBLEM_REPORTS / f"problem-{stamp}.json"
    payload = {
        "time": time.time(), "category": category or "Allgemein", "description": description,
        "source": source or "UTUBE MAC", "downloads_folder": str(DOWNLOADS),
    }
    report.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n")
    record_event("problem", f"Problem gemeldet: {payload['category']}", description)
    return report

def notification_events():
    events = []
    if EVENT_LOG.exists():
        for line in EVENT_LOG.read_text(errors="replace").splitlines()[-200:]:
            try: events.append(json.loads(line))
            except Exception: pass
    for job in progress_jobs():
        status = job.get("RESULT", "active")
        if status == "waiting" and str(job.get("PHASE", "")).lower().startswith("fertig"):
            status = "completed"
        label = "Download abgeschlossen" if status == "completed" else "Download fehlgeschlagen" if status == "failed" else "Download abgebrochen" if status == "cancelled" else "Download läuft"
        events.append({"time": (RUNTIME / "Download Progress" / "Jobs" / f"{job['id']}.status").stat().st_mtime, "kind": status, "text": f"{label}: {job.get('TITLE', 'Download')}", "job": job["id"], "details": job.get("PHASE", "")})
    for path in sorted(LOGS.glob("setup-*.log"), key=lambda p:p.stat().st_mtime, reverse=True)[:8]:
        events.append({"time": path.stat().st_mtime, "kind": "setup", "text": f"Setup-Bericht erstellt: {path.name}", "log": path.name, "details": "Installations- und Werkzeugprotokoll"})
    for path in sorted(PROBLEM_REPORTS.glob("problem-*.json"), key=lambda p:p.stat().st_mtime, reverse=True)[:80] if PROBLEM_REPORTS.exists() else []:
        try:
            report = json.loads(path.read_text(errors="replace"))
            events.append({"time": report.get("time", path.stat().st_mtime), "kind": "problem", "text": f"Problem gemeldet: {report.get('category', 'Allgemein')}", "report": path.name, "details": report.get("description", "")})
        except Exception:
            pass
    events.extend(support_file_events())
    return sorted(events, key=lambda event:event.get("time", 0), reverse=True)[:400]

def explain_notification(event):
    """Give each entry a concrete explanation instead of repeating its group name."""
    text = str(event.get("text", "UTUBE MAC Ereignis"))
    details = str(event.get("details", "")).strip()
    if event.get("job"):
        return f"Dieser Hintergrund-Download betrifft „{text}“. Aktueller bzw. letzter Schritt: {details or 'keine zusätzliche Statusangabe'}."
    if event.get("report"):
        return "Dies ist eine von dir gespeicherte Problemmeldung. Sie wurde als eigene Datei abgelegt und kann über „Problembericht öffnen“ vollständig gelesen werden."
    if event.get("log"):
        return "Diese Meldung verweist auf einen konkreten Setup-Bericht. Darin stehen die einzelnen Installations- und Werkzeugschritte."
    if event.get("support_path"):
        return f"Diese Information wurde aus der lokalen Datei „{event['support_path']}“ gelesen. {details}"
    lowered = text.lower()
    if "fehl" in lowered or "failed" in lowered:
        return "Der zugehörige Vorgang konnte nicht fertiggestellt werden. Öffne die Details oder das Protokoll, um die genaue Ursache zu sehen."
    if "abgeschlossen" in lowered or "completed" in lowered:
        return "Der Vorgang wurde erfolgreich beendet. Die fertige Datei sollte in der Mediathek sichtbar sein."
    if "abgebrochen" in lowered or "cancel" in lowered:
        return "Der Vorgang wurde beendet, bevor er fertig war. Bereits vollständig erzeugte Dateien bleiben erhalten."
    return details or "Dies ist ein lokal erfasstes UTUBE-MAC-Ereignis. Über Details kannst du zur passenden Quelldatei springen."

def notifications_page():
    category_names = {"problem": "⚠️ Gemeldete Probleme", "failed": "✕ Fehler", "cancelled": "⊘ Abgebrochene Downloads", "completed": "✓ Abgeschlossene Downloads", "download": "↓ Gestartete Downloads", "runtime": "◉ Laufzeit & Warteschlange", "history": "◷ Download-Verlauf", "settings": "⚙ Einstellungen & Updates", "setup": "⌘ Einrichtung", "support": "▤ Weitere Support-Dateien", "active": "◌ Laufende Downloads"}
    category_info = {"problem": "Eine von dir gespeicherte Problembeschreibung.", "failed": "Ein Download oder Verarbeitungsschritt konnte nicht erfolgreich beendet werden.", "cancelled": "Ein Download wurde bewusst abgebrochen; fertige Dateien bleiben erhalten.", "completed": "Ein Download wurde erfolgreich beendet und sollte in der Mediathek erscheinen.", "download": "Ein neuer Download wurde gestartet.", "runtime": "Automatisch erfasste Ereignisse aus Laufzeit, Warteschlange und Hintergrunddiensten.", "history": "Eintrag aus dem lokalen Download- und Skriptverlauf.", "settings": "Änderung oder Information aus den lokalen Einstellungen bzw. der Update-Prüfung.", "setup": "Information aus der Einrichtung von UTUBE MAC und seinen Werkzeugen.", "support": "Relevante Meldung aus einer lokalen Application-Support-Datei.", "active": "Ein Download ist aktuell noch in Bearbeitung."}
    grouped = {}
    events = notification_events()
    for event in events:
        kind = str(event.get("kind", "info")); when = time.strftime("%d.%m.%Y · %H:%M:%S", time.localtime(float(event.get("time", 0))))
        actions = '<a class="folder" href="/library">Mediathek</a><a class="folder" href="/browse?target=history&path=Download%20History/DOWNLOAD-HISTORY.txt">Verlauf</a>'
        if event.get("job"):
            actions = f'<a class="folder" href="/browse?target=runtime&path=Download%20Progress/Jobs/{urllib.parse.quote(event["job"])}.log">Protokoll öffnen</a><a class="folder" href="/library">Mediathek</a>'
        if event.get("log"):
            actions = f'<a class="folder" href="/browse?target=logs&path={urllib.parse.quote(event["log"])}">Setup-Protokoll öffnen</a>'
        if event.get("report"):
            actions = f'<a class="folder" href="/browse?target=reports&path={urllib.parse.quote(event["report"])}">Problembericht öffnen</a><a class="folder" href="/library">Mediathek</a>'
        if event.get("support_path"):
            actions = f'<a class="folder" href="/browse?target=support&path={urllib.parse.quote(event["support_path"])}">Quelldatei öffnen</a><a class="folder" href="/developer">Entwicklung</a>'
        meaning = explain_notification(event)
        row = f'<article class="file-row notification"><div><b>{html.escape(str(event.get("text", "UTUBE MAC Ereignis")))}</b><small>{when}</small><details class="event-info"><summary>ⓘ Was bedeutet das?</summary><p class="hint">{html.escape(meaning)}</p></details><details><summary>Details & Aktionen</summary><p class="hint">{html.escape(str(event.get("details", "Keine weiteren Details gespeichert.")))}</p><div class="actions compact">{actions}</div></details></div></article>'
        grouped.setdefault(kind, []).append(row)
    sections = []
    ordered_kinds = sorted(grouped, key=lambda kind: next((event.get("time", 0) for event in events if str(event.get("kind", "info")) == kind), 0), reverse=True)
    for kind in ordered_kinds:
        label = category_names.get(kind, "ⓘ Weitere Ereignisse")
        is_open = " open" if kind in {"problem", "failed", "cancelled"} else ""
        sections.append(f'<details class="notification-group" data-kind="{html.escape(kind, quote=True)}"{is_open}><summary>{html.escape(label)} <span>{len(grouped[kind])} Meldungen</span></summary><div class="file-list">{"".join(grouped[kind])}</div></details>')
    filters = '<div class="filters" id="notification-filters"><button class="filter active" data-kind="all">Alle</button><button class="filter" data-kind="problem">Probleme</button><button class="filter" data-kind="completed">Fertig</button><button class="filter" data-kind="failed">Fehler</button><button class="filter" data-kind="cancelled">Abgebrochen</button><button class="filter" data-kind="runtime">Laufzeit</button><button class="filter" data-kind="history">Verlauf</button><button class="filter" data-kind="settings">Einstellungen</button><button class="filter" data-kind="setup">Setup</button><button class="filter" data-kind="download">Downloads</button></div>'
    script = '''<style>.notification-group{margin:10px 0;border:1px solid #315878;border-radius:12px;background:#0b1824}.notification-group>summary{cursor:pointer;padding:13px 15px;font-weight:850;color:#dcecff}.notification-group>summary span{float:right;color:#93b9dc;font-size:12px}.notification-group>.file-list{padding:0 10px 10px}.event-info{display:inline-block;margin:8px 0;color:#87c6ff}.event-info summary{cursor:pointer;font-size:13px}.event-info p{margin:7px 0}</style><script>document.querySelectorAll('#notification-filters button').forEach(button=>button.onclick=()=>{let kind=button.dataset.kind;document.querySelectorAll('#notification-filters button').forEach(item=>item.classList.toggle('active',item===button));document.querySelectorAll('.notification-group').forEach(group=>{let show=kind==='all'||group.dataset.kind===kind;group.style.display=show?'block':'none';if(show&&kind!=='all')group.open=true})})</script>'''
    general_info = '<details class="event-info"><summary>ⓘ Wie lese ich diese Meldungszentrale?</summary><p class="hint">Die Kategorien dienen nur der Übersicht und lassen sich auf- und zuklappen. Jede einzelne Meldung hat ihre eigene Erklärung unter „ⓘ Was bedeutet das?“ und zeigt bei Bedarf die passende lokale Quelle, ein Protokoll oder die Mediathek.</p></details>'
    return layout("UTUBE MAC – Meldungen", "Alle lokalen Ereignisse nach Datum und Uhrzeit.", f'<section class="panel"><a href="/developer">← Zur Entwicklung</a><h2>🔔 Meldungszentrale</h2><p class="sub">Aufklappbare Kategorien, Filter und Erklärungen zu jeder Meldung.</p>{general_info}{filters}<div class="file-list">{"".join(sections) or "<p class=\"sub\">Noch keine Meldungen vorhanden.</p>"}</div></section>{script}')

def download_notifications_page():
    """A small, non-technical inbox for the person using UTUBE MAC."""
    relevant = [event for event in notification_events() if event.get("kind") in {"active", "download", "completed", "failed", "cancelled"}]
    rows = []
    for event in relevant[:80]:
        kind = str(event.get("kind", ""))
        icon, label = {
            "active": ("↓", "Läuft"), "download": ("↓", "Gestartet"), "completed": ("✓", "Fertig"),
            "failed": ("⚠", "Fehler"), "cancelled": ("⊘", "Abgebrochen"),
        }.get(kind, ("ⓘ", "Information"))
        when = time.strftime("%d.%m.%Y · %H:%M", time.localtime(float(event.get("time", 0))))
        title_hint = str(event.get("text", "")).split(":", 1)[-1].strip()
        wanted = normal_title(title_hint)
        match = next((path for path in media_files() if wanted and (wanted in normal_title(path.stem) or normal_title(path.stem) in wanted)), None)
        cover = thumbnail_for(match) if match else ""
        thumbnail = f'<img class="download-thumb" src="{html.escape(cover, quote=True)}" alt="" loading="lazy">' if cover else ('<div class="download-thumb download-thumb-fallback">♫</div>' if "MP3" in title_hint.upper() or "AUDIO" in title_hint.upper() else '<div class="download-thumb download-thumb-fallback">↓</div>')
        actions = '<a class="folder" href="/library">In Mediathek ansehen</a>'
        if kind in {"failed", "cancelled"}:
            if event.get("job"):
                actions += f'<a class="folder" href="/retry-download?job={urllib.parse.quote(event["job"])}">↻ Erneut versuchen / Reparieren</a>'
            actions += '<a class="folder" href="/report-problem?source=Download-Meldungen">Problem melden</a>'
        if event.get("job"):
            actions += f'<a class="folder" href="/browse?target=runtime&path=Download%20Progress/Jobs/{urllib.parse.quote(event["job"])}.log">Details</a>'
        rows.append(f'<article class="file-row download-row">{thumbnail}<div><b>{icon} {html.escape(str(event.get("text", "Download")))}</b><small>{label} · {when}</small></div><div class="row-actions">{actions}</div></article>')
    body = f'''<style>.download-row{{display:grid;grid-template-columns:112px minmax(0,1fr) auto;gap:14px}}.download-thumb{{width:112px;height:63px;object-fit:cover;border-radius:9px;background:#08121c}}.download-thumb-fallback{{display:grid;place-items:center;font-size:26px;background:linear-gradient(135deg,#244d72,#1a2940)}}@media(max-width:650px){{.download-row{{grid-template-columns:84px 1fr}}.download-thumb{{width:84px;height:47px}}.download-row .row-actions{{grid-column:1/-1}}}}</style><section class="panel"><a href="/">← Zurück</a><h2>↓ Deine Downloads</h2><p class="sub">Nur das Wichtige: laufende Downloads, fertige Dateien und einfache Fehlerhinweise.</p><p><a class="folder" href="/history">◷ Gesamten Download-Verlauf öffnen</a></p><div class="file-list">{"".join(rows) or '<p class="sub">Noch keine Download-Meldungen vorhanden.</p>'}</div><p class="hint">Die ausführliche technische Historie findest du in <a href="/notifications">Entwicklung → Meldungszentrale</a>.</p></section>'''
    return layout("UTUBE MAC – Deine Downloads", "Einfache Download-Meldungen.", body)

def problem_report_page(source="", message=""):
    source = html.escape(source, quote=True)
    body = f'''<section class="panel"><a href="javascript:history.back()">← Zurück</a><h2>⚠️ Problem melden</h2><p class="sub">Deine Beschreibung bleibt lokal auf diesem Mac. Sie wird als eigene Datei gespeichert und in der Meldungszentrale angezeigt.</p><form method="post" action="/report-problem"><input type="hidden" name="source" value="{source}"><label class="label">Bereich</label><select name="category"><option>Download</option><option>Warteschlange</option><option>Playlist / Mediathek</option><option>Vorschau / Thumbnail</option><option>Einrichtung / Update</option><option>Andere Oberfläche</option></select><label class="label">Was ist passiert?</label><textarea name="description" required maxlength="5000" placeholder="Bitte kurz beschreiben, was du gemacht hast und was statt dessen passiert ist …" style="box-sizing:border-box;width:100%;min-height:140px;padding:12px;border-radius:11px;border:1px solid #365b77;background:#09131e;color:white;margin-bottom:10px"></textarea><button>Problem lokal speichern</button></form></section>'''
    return layout("UTUBE MAC – Problem melden", "Eine lokale Fehlermeldung erstellen.", body, message if message and "?" not in message else "")

def safari_extension_status():
    heartbeat = RUNTIME / "Safari Extension Heartbeat.json"
    if heartbeat.exists() and time.time() - heartbeat.stat().st_mtime < 300:
        return "Aktiv auf YouTube", "Die Safari-Erweiterung hat sich gerade bei UTUBE MAC gemeldet."
    return "Noch nicht bestätigt", "Nicht aktiviert oder gerade nicht auf einer YouTube-Seite geöffnet."

def dock_app_bundle():
    return Path.home() / "Applications/UTUBE MAC.app"

def dock_app_status():
    app = dock_app_bundle()
    executable = app / "Contents/MacOS/UTUBE MAC"
    if app.is_dir() and executable.is_file():
        return "Installiert", "Eigene UTUBE-MAC-App ist in Programme bereit."
    return "Nicht installiert", "Klicke hier, um die App zu erstellen und zum Dock hinzuzufügen."

def add_dock_entry(app):
    if not app or not app.is_dir():
        return False
    dockutil = shutil.which("dockutil") or "/opt/homebrew/bin/dockutil"
    if not Path(dockutil).is_file():
        return False
    subprocess.run([dockutil, "--remove", "UTUBE MAC", "--no-restart"], capture_output=True, text=True)
    result = subprocess.run([dockutil, "--add", str(app), "--label", "UTUBE MAC"], capture_output=True, text=True, timeout=12)
    return result.returncode == 0

def install_dock_app():
    builder = Path(__file__).with_name("build_utube_mac_app.sh")
    if not builder.exists():
        return False
    result = subprocess.run(["/bin/bash", str(builder)], capture_output=True, text=True)
    app = Path(result.stdout.strip().splitlines()[-1]) if result.returncode == 0 and result.stdout.strip() else None
    if not add_dock_entry(app):
        return False
    subprocess.Popen(["open", str(app)])
    return True

def open_dock_app():
    app = dock_app_bundle()
    if not app.is_dir():
        return False
    subprocess.Popen(["open", str(app)])
    return True

def layout(title, subtitle, content, message=""):
    message_html = f'<div class="message">{html.escape(message)}</div>' if message else ""
    theme_styles = '''<style>
body[data-theme="midnight"]{background:radial-gradient(circle at 14% -12%,#273d64 0,#101521 40%,#080a10 100%)}body[data-theme="midnight"] .card,body[data-theme="midnight"] .panel,body[data-theme="midnight"] .media-card{background:linear-gradient(135deg,#1b2638,#101721);border-color:#425875}body[data-theme="midnight"] button{background:linear-gradient(135deg,#3d8bff,#5a5fe8)}body[data-theme="midnight"] button.secondary,body[data-theme="midnight"] .folder,body[data-theme="midnight"] .file-entry{background:#1b2b40;border-color:#415f80}body[data-theme="midnight"] nav a{background:#21334a;border-color:#486887}body[data-theme="midnight"] .bar{filter:hue-rotate(20deg)}
body[data-theme="ember"]{background:radial-gradient(circle at 16% -14%,#823128 0,#261013 38%,#0d0708 100%)}body[data-theme="ember"] .card,body[data-theme="ember"] .panel,body[data-theme="ember"] .media-card{background:linear-gradient(135deg,#4a201f,#1d0e10);border-color:#bc5744}body[data-theme="ember"] button{background:linear-gradient(135deg,#ff6c45,#f1a52d)}body[data-theme="ember"] button.secondary,body[data-theme="ember"] .folder,body[data-theme="ember"] .file-entry{background:#5a2822;border-color:#dc7652;color:#fff4ec}body[data-theme="ember"] nav a{background:#59251f;border-color:#e27c53;color:#fff1e8}body[data-theme="ember"] input,body[data-theme="ember"] select{background:#1b0d0f;border-color:#d6684b;color:#fff1eb}body[data-theme="ember"] .bar{filter:hue-rotate(310deg)}body[data-theme="ember"] .type-badge.mp4{background:#b9482f;color:#fff8ee}body[data-theme="ember"] .type-badge.mp3{background:#536b2d;color:#f6ffcf}
body[data-theme="frost"]{background:linear-gradient(145deg,#f7fbff,#d5e9ff 50%,#edf7ff);color:#0d2339}body[data-theme="frost"] header{border-color:#78afd9}body[data-theme="frost"] .card,body[data-theme="frost"] .panel,body[data-theme="frost"] .media-card{background:linear-gradient(135deg,#ffffff,#e5f3ff);border-color:#71abd8;box-shadow:0 14px 32px #326d9a45}body[data-theme="frost"] .label{color:#1b5a88}body[data-theme="frost"] .sub,body[data-theme="frost"] .note,body[data-theme="frost"] small,body[data-theme="frost"] .hint{color:#345a79}body[data-theme="frost"] button{background:linear-gradient(135deg,#075db7,#1689e0)}body[data-theme="frost"] button.secondary,body[data-theme="frost"] .folder,body[data-theme="frost"] .file-entry{background:#cfe9ff;border-color:#5c9ed1;color:#0b426d}body[data-theme="frost"] nav a{background:#cbe8ff;border-color:#5b9fd2;color:#073f69}body[data-theme="frost"] input,body[data-theme="frost"] select{background:#fff;border:2px solid #5f9fce;color:#092e4a}body[data-theme="frost"] .bar-track{background:#b9d9f0}body[data-theme="frost"] .code-preview{background:#fff;color:#102f49;border-color:#77aed6}body[data-theme="frost"] .type-badge.mp4{background:#075db7;color:white}
body[data-theme="pearl"]{background:linear-gradient(145deg,#fffdfc,#f7dce7 50%,#fff7fa);color:#351321}body[data-theme="pearl"] header{border-color:#d98ba8}body[data-theme="pearl"] .card,body[data-theme="pearl"] .panel,body[data-theme="pearl"] .media-card{background:linear-gradient(135deg,#fffefe,#ffe7ef);border-color:#d986a4;box-shadow:0 14px 32px #a4476a45}body[data-theme="pearl"] .label{color:#8a204b}body[data-theme="pearl"] .sub,body[data-theme="pearl"] .note,body[data-theme="pearl"] small,body[data-theme="pearl"] .hint{color:#754258}body[data-theme="pearl"] button{background:linear-gradient(135deg,#a91354,#dd4c56)}body[data-theme="pearl"] button.secondary,body[data-theme="pearl"] .folder,body[data-theme="pearl"] .file-entry{background:#ffd7e4;border-color:#d57498;color:#751439}body[data-theme="pearl"] nav a{background:#ffd7e4;border-color:#d57498;color:#711034}body[data-theme="pearl"] input,body[data-theme="pearl"] select{background:#fff;border:2px solid #d16f92;color:#451427}body[data-theme="pearl"] .bar-track{background:#efbdd0}body[data-theme="pearl"] .code-preview{background:#fff;color:#492033;border-color:#da93ad}body[data-theme="pearl"] .type-badge.mp3{background:#a91354;color:#fff}
</style><script>(()=>{let picker=document.getElementById('theme-picker');if(!picker)return;picker.innerHTML='<option value="ocean">Ozean — dunkel</option><option value="midnight">Mitternacht — dunkel</option><option value="ember">Glut — dunkel</option><option value="frost">Frost — hell</option><option value="pearl">Perle — hell</option>';let saved=localStorage.getItem('utube-mac-theme')||'ocean';if(!['ocean','midnight','ember','frost','pearl'].includes(saved))saved='ocean';document.body.dataset.theme=saved;picker.value=saved;picker.onchange=()=>{document.body.dataset.theme=picker.value;localStorage.setItem('utube-mac-theme',picker.value)}})()</script>'''
    persistent_download_status = '''<style>#persistent-download-status{position:fixed;z-index:9000;right:18px;bottom:18px;width:min(360px,calc(100vw - 36px));display:none;padding:13px;border:1px solid #5281aa;border-radius:14px;background:#10243aeF;color:#edf6ff;box-shadow:0 16px 45px #0009;cursor:pointer}#persistent-download-status.show{display:block}#persistent-download-status .bar-track{margin-top:8px}</style><div id="persistent-download-status" role="status"><b>↓ Download läuft im Hintergrund</b><small id="persistent-download-detail"></small><div class="bar-track"><div id="persistent-download-fill" class="progress-fill"></div></div></div><script>document.addEventListener('DOMContentLoaded',()=>{let box=document.getElementById('persistent-download-status'),detail=document.getElementById('persistent-download-detail'),fill=document.getElementById('persistent-download-fill');box.onclick=()=>location.href='/';async function refresh(){try{let jobs=await fetch('/progress').then(response=>response.json()),active=jobs.find(job=>!job.done&&job.RESULT!=='failed'&&job.RESULT!=='completed');if(!active){box.classList.remove('show');return}box.classList.add('show');detail.textContent=(active.TITLE||'Download')+' · '+(active.PHASE||'wird vorbereitet')+' · '+(active.PERCENT||'0')+'%';fill.style.width=Math.max(3,Math.min(100,parseFloat(active.PERCENT)||0))+'%'}catch(error){}}refresh();setInterval(refresh,1200)})</script>'''
    design_bootstrap = '''<script>(()=>{let d={accent:'#5d8cff',accent2:'#46d8b0',gradient:true,shape:'round',text:'16'},m=localStorage.getItem('utube-design-mode')||'dark';try{d=Object.assign(d,JSON.parse(localStorage.getItem('utube-design-'+m)||'{}'))}catch(e){}let light=m==='light',s=document.head.appendChild(document.createElement('style'));s.textContent='body{font-size:'+d.text+'px!important;background:'+(light?'radial-gradient(circle at 18% -10%,#b8ddf5 0,#f3f8fc 42%,#e5edf4 100%)':'radial-gradient(circle at 18% -10%,#173c5c 0,#0a1018 34%,#080b12 100%)')+'!important;color:'+(light?'#152536':'#edf3f8')+'!important}.app-sidebar a{border-radius:'+(d.shape==='pill'?'999px':d.shape==='square'?'5px':'10px')+'!important}button{border-radius:'+(d.shape==='pill'?'999px':d.shape==='square'?'5px':'11px')+'!important;background:'+(d.gradient?'linear-gradient(135deg,'+d.accent+','+d.accent2+')':d.accent)+'!important}.notification-bell{background:'+(d.gradient?'linear-gradient(135deg,'+d.accent+','+d.accent2+')':d.accent)+'!important;border-color:'+d.accent+'!important}';document.addEventListener('DOMContentLoaded',()=>document.getElementById('theme-picker')?.remove())})()</script>'''
    # Retire the former global colour override. It painted every button and
    # card in the accent colour, which is the opposite of a subtle accent.
    design_bootstrap = ''
    # Version 2 deliberately keeps colour customisation narrow: accents are lines, never whole cards.
    design_v2_bootstrap = '''<script>(()=>{let D={background:'#080b12',background2:'#173c5c',backgroundOn:false,backgroundGradient:false,button:'#4b8fff',button2:'#6974ff',buttonOn:false,buttonGradient:true,accent:'#5dd1ff',accent2:'#55d6a8',accentGradient:true,text:'#edf3f8',shape:'round',size:'16'},K=m=>'utube-design-v2-'+m,R=m=>{try{return Object.assign({},D,JSON.parse(localStorage.getItem(K(m))||'{}'))}catch(e){return {...D}}},paint=(a,b,g)=>g?'linear-gradient(135deg,'+a+','+b+')':a;function apply(){let m=localStorage.getItem('utube-design-v2-mode')||'dark',v=R(m),light=m==='light',s=document.getElementById('utube-design-v2-style')||document.head.appendChild(Object.assign(document.createElement('style'),{id:'utube-design-v2-style'}));let base=light?'#f4f8fc':'#080b12',baseText=light?'#152536':'#edf3f8',bg=v.backgroundOn?paint(v.background,v.background2,v.backgroundGradient):base,btn=v.buttonOn?paint(v.button,v.button2,v.buttonGradient):'linear-gradient(135deg,#4b8fff,#6974ff)';s.textContent='body{background:'+bg+'!important;color:'+v.text+'!important;font-size:'+v.size+'px!important}.app-sidebar a,button{border-radius:'+(v.shape==='pill'?'999px':v.shape==='square'?'5px':'11px')+'!important}button{background:'+btn+'!important}button.secondary{background:'+(v.buttonOn?paint(v.button,v.button2,v.buttonGradient):'#203a53')+'!important}.card:before{background:'+paint(v.accent,v.accent2,v.accentGradient)+'!important}.notification-bell{background:'+paint(v.accent,v.accent2,v.accentGradient)+'!important;border-color:'+v.accent+'!important}';document.body.dataset.utubeMode=m}if(!localStorage.getItem('utube-design-v2-migrated')){['utube-design-dark','utube-design-light','utube-design-mode'].forEach(k=>localStorage.removeItem(k));localStorage.setItem('utube-mac-theme','ocean');localStorage.setItem('utube-design-v2-migrated','1')}window.utubeDesignV2Apply=apply;apply();document.addEventListener('DOMContentLoaded',()=>document.getElementById('theme-picker')?.remove())})()</script>'''
    design_v2_bootstrap = ''
    design_standard_guard = '''<script>document.addEventListener('DOMContentLoaded',()=>setTimeout(()=>{['utube-design-style','utube-design-v2-style','utube-clean-style'].forEach(id=>document.getElementById(id)?.remove());if(!localStorage.getItem('utube-standard-reset-1025')){['utube-design-mode','utube-design-v2-mode','utube-design-clean-mode','utube-design-dark','utube-design-light','utube-design-v2-dark','utube-design-v2-light','utube-design-clean-dark','utube-design-clean-light'].forEach(key=>localStorage.removeItem(key));localStorage.setItem('utube-standard-reset-1025','1')}let s=document.getElementById('utube-single-standard')||document.head.appendChild(Object.assign(document.createElement('style'),{id:'utube-single-standard'}));s.textContent='body{background:radial-gradient(circle at 18% -10%,#173c5c 0,#0a1018 34%,#080b12 100%)!important;color:#edf3f8!important;font-size:16px!important}.panel,.card,.media-card{background:linear-gradient(135deg,#172a3cde,#0d1722e8)!important;border-color:#2d4e69!important}.card:before,.panel:before,button:before{content:"";display:block;position:absolute;inset:0 0 auto;height:3px;background:linear-gradient(90deg,#5dd1ff,#7776ff,#55d6a8)!important}button{position:relative;overflow:hidden;background:linear-gradient(135deg,#4b8fff,#6974ff)!important;color:white!important;border-radius:11px!important}button.secondary{background:#203a53!important}.app-sidebar a{border-radius:10px!important}.app-sidebar a[href="/developer"]{display:none!important}#theme-picker{display:none!important}.notification-bell{background:transparent!important;color:#fff!important;border:0!important;box-shadow:none!important}';},450))</script>'''
    content = theme_styles + design_bootstrap + design_v2_bootstrap + '<style>.wrap{box-sizing:border-box;width:100%;max-width:none!important;margin:0 auto;padding-left:28px;padding-right:28px}.app-shell{max-width:none!important}.library-shell{max-width:none!important}.app-sidebar a[href="/developer"]{display:none!important}</style>' + content + persistent_download_status + design_standard_guard
    global_sidebar = '''<aside class="app-sidebar" aria-label="UTUBE MAC Navigation"><div class="app-mark">UTUBE<br><span>MAC</span></div><a href="/">⌂ <span>Start</span></a><a href="/library">▣ <span>Mediathek</span></a><a href="/library?filter=PLAYLISTS">☰ <span>Playlists</span></a><a href="/download-notifications">↓ <span>Downloads</span></a><a href="/storage">◫ <span>Speicher</span></a><a href="/history">◷ <span>Verlauf</span></a><a href="/developer">⌘ <span>Entwicklung</span></a><a id="app-settings-open" href="/?settings=1">⚙ <span>Einstellungen</span></a></aside>'''
    shell_class = "wrap app-shell" if global_sidebar else "wrap"
    main_open = '<div class="app-main">' if global_sidebar else ''
    main_close = '</div>' if global_sidebar else ''
    return f'''<!doctype html><html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{html.escape(title)}</title><style>
body{{margin:0;background:radial-gradient(circle at 18% -10%,#173c5c 0,#0a1018 34%,#080b12 100%);color:#edf3f8;font:16px -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;min-height:100vh}}.wrap{{max-width:1060px;margin:auto;padding:30px 20px 70px}}header{{display:flex;align-items:center;justify-content:space-between;gap:18px;border-bottom:1px solid #29445b;padding-bottom:21px}}h1{{margin:0;font-size:30px;letter-spacing:-.04em}}h2{{font-size:19px;margin:0 0 12px}}.sub,.note{{color:#a8b8c9}}nav{{display:flex;gap:9px;flex-wrap:wrap}}nav a{{padding:9px 13px;background:#193148b8;border:1px solid #355778;border-radius:999px;color:#cae6ff;text-decoration:none;font-weight:700}}.grid,.media-grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:14px;margin:18px 0}}.card,.panel,.media-card{{background:linear-gradient(135deg,#172a3cde,#0d1722e8);border:1px solid #2d4e69;border-radius:18px;padding:18px;box-shadow:0 18px 45px #0006}}.card{{position:relative;overflow:hidden}}.card:before{{content:"";position:absolute;inset:0 0 auto;height:3px;background:linear-gradient(90deg,#5dd1ff,#7776ff,#55d6a8)}}.label{{color:#a5bdd0;font-size:11px;text-transform:uppercase;letter-spacing:.11em}}.value{{font-size:23px;font-weight:780;margin:8px 0}}.panel{{margin-top:16px}}.actions,.folders{{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px}}.compact{{grid-template-columns:1fr 1fr}}button{{width:100%;border:0;border-radius:11px;padding:13px;background:linear-gradient(135deg,#4b8fff,#6974ff);color:white;font-weight:800;cursor:pointer}}button.secondary{{background:#203a53}}button.danger{{background:#572737;color:#ffd9df;padding:10px}}input,select{{box-sizing:border-box;width:100%;padding:12px;border-radius:11px;border:1px solid #365b77;background:#09131e;color:white;margin-bottom:10px}}input[type=checkbox]{{width:auto;margin:0 8px 0 0;accent-color:#6d8cff}}table{{width:100%;border-collapse:collapse}}td{{padding:10px;border-bottom:1px solid #2a455d}}.ok{{color:#6ee7a1}}.bad{{color:#ff8b8b}}a{{color:#8ed5ff;text-decoration:none}}.folder{{display:block;padding:12px;border:1px solid #365876;border-radius:11px;background:#15283a;color:#d7ecff;font-weight:700}}li{{margin:9px 0}}.message{{margin:18px 0;padding:13px;border:1px solid #2f8962;border-radius:12px;background:#123524;color:#b6ffd2}}.hint,small{{font-size:13px;color:#a7bacd}}.bar-item{{margin:13px 0}}.bar-label{{display:flex;justify-content:space-between;color:#c9d8e8;font-size:14px;margin-bottom:6px}}.bar-track{{height:10px;border-radius:999px;background:#07111b;overflow:hidden}}.bar{{height:100%;border-radius:999px}}.media-card{{display:grid;gap:10px;position:relative}}.media-mp3{{border-color:#357c63}}.media-mp4{{border-color:#3c6cb3}}.media-mkv{{border-color:#704ca4}}video,audio,.audio-art{{width:100%;max-height:180px;border-radius:10px;background:#070b10}}.audio-art{{height:150px;object-fit:cover}}.type-badge{{position:absolute;top:27px;right:27px;padding:5px 8px;border-radius:999px;font-size:11px;font-weight:850}}.type-badge.mp3{{background:#174d3b;color:#a6ffd9}}.type-badge.mp4{{background:#183f75;color:#b9d9ff}}.type-badge.mkv{{background:#4a286e;color:#e3ccff}}.filters{{display:flex;gap:8px;flex-wrap:wrap;margin:14px 0}}button.filter{{width:auto;background:#193148;padding:9px 12px}}button.filter.active{{outline:2px solid #7bb8ff}}button.filter.mp3{{color:#a6ffd9}}button.filter.mp4{{color:#b9d9ff}}button.filter.mkv{{color:#e3ccff}}.file-list,.duplicate-group{{display:grid;gap:9px}}.duplicate-group{{border-top:1px solid #294861;margin-top:18px;padding-top:16px}}.file-row{{display:flex;gap:14px;align-items:center;justify-content:space-between;padding:12px;border:1px solid #28445d;border-radius:12px;background:#0b1824}}.file-row small{{display:block;margin-top:4px;overflow-wrap:anywhere}}.row-actions{{display:flex;align-items:center;gap:10px;flex-shrink:0}}.row-actions form{{margin:0}}.row-actions a{{padding:8px 10px;background:#1b354c;border-radius:9px;font-weight:700}}.progress-box{{display:none;margin-top:14px;padding:14px;border:1px solid #426c97;border-radius:13px;background:#0a1928}}.progress-box.show{{display:block}}.progress-fill{{height:100%;min-width:3%;border-radius:999px;background:linear-gradient(90deg,#55d6a8,#5c8fff)}}.progress-meta{{display:flex;justify-content:space-between;gap:12px;color:#b5c8db;font-size:13px;margin-top:8px}}@media(max-width:600px){{.file-row{{align-items:flex-start;flex-direction:column}}.row-actions{{width:100%}}.row-actions>*{{flex:1}}}}
 .theme-picker{{width:auto;margin:0;padding:8px 10px;border-radius:999px;font-size:12px;font-weight:750}}.app-shell{{max-width:1540px;display:grid;grid-template-columns:190px minmax(0,1fr);gap:26px}}.app-main{{min-width:0}}.app-sidebar{{position:sticky;top:30px;align-self:start;display:grid;gap:6px;padding:12px;border-right:1px solid #294b65}}.app-mark{{padding:8px 10px 19px;color:#f3f8ff;font-weight:900;font-size:20px;line-height:.82;letter-spacing:-.08em}}.app-mark span{{color:#79c8ff}}.app-sidebar a{{display:flex;gap:10px;padding:10px;border-radius:10px;color:#a9c1d3;font-weight:700}}.app-sidebar a:hover{{background:#193a56;color:#f1f8ff}}.app-shell header nav a{{display:none}}.app-shell .grid{{grid-template-columns:repeat(auto-fit,minmax(240px,1fr))}}.app-shell .panel{{padding:16px;border-radius:16px;box-shadow:none}}@media(max-width:900px){{.app-shell{{grid-template-columns:1fr;padding:16px}}.app-sidebar{{position:static;grid-template-columns:repeat(7,minmax(0,1fr));border-right:0;border-bottom:1px solid #294b65;padding:0 0 12px}}.app-mark{{display:none}}.app-sidebar a{{justify-content:center}}.app-sidebar span{{display:none}}}}body[data-theme="violet"]{{background:radial-gradient(circle at 15% -10%,#4e277a 0,#171029 36%,#090a14 100%)}}body[data-theme="violet"] .card,body[data-theme="violet"] .panel,body[data-theme="violet"] .media-card{{background:linear-gradient(135deg,#30204bde,#171124ed);border-color:#68418b}}body[data-theme="violet"] button{{background:linear-gradient(135deg,#9a62ee,#df59ad)}}body[data-theme="violet"] button.secondary,body[data-theme="violet"] .folder{{background:#372457;border-color:#76509e}}body[data-theme="violet"] nav a{{background:#362452;border-color:#70499a}}body[data-theme="forest"]{{background:radial-gradient(circle at 18% -10%,#155c48 0,#092019 35%,#07120f 100%)}}body[data-theme="forest"] .card,body[data-theme="forest"] .panel,body[data-theme="forest"] .media-card{{background:linear-gradient(135deg,#123f35df,#0a211d);border-color:#347767}}body[data-theme="forest"] button{{background:linear-gradient(135deg,#22a878,#2f9bc4)}}body[data-theme="forest"] button.secondary,body[data-theme="forest"] .folder{{background:#153e35;border-color:#367766}}body[data-theme="forest"] nav a{{background:#153c34;border-color:#347565}}</style></head><body><main class="{shell_class}">{global_sidebar}{main_open}<header><div><h1>{html.escape(title)}</h1><p class="sub">{html.escape(subtitle)}</p></div><nav><a href="/">UTUBE MAC</a><a href="/developer">Entwicklung</a><a href="/report-problem">⚠️ Problem melden</a><select id="theme-picker" class="theme-picker" aria-label="Design auswählen"><option value="ocean">Ozean</option><option value="violet">Violett</option><option value="forest">Wald</option></select></nav></header>{message_html}{content}{main_close}<script>(()=>{{let p=document.getElementById('theme-picker'),saved=localStorage.getItem('utube-mac-theme')||'ocean';document.body.dataset.theme=saved;p.value=saved;p.onchange=()=>{{document.body.dataset.theme=p.value;localStorage.setItem('utube-mac-theme',p.value)}}}})()</script></main></body></html>'''

def app_page(message=""):
    counts, free_space = library_stats()
    version = local_version(); available = remote_update()
    shortcut = shortcut_version(); remote_shortcut = remote_shortcut_release()
    shortcut_available = remote_shortcut if remote_shortcut and newer_version(remote_shortcut, shortcut) else ""
    ui_state = f"Update {available} bereit" if available else "✓ Aktuell"
    shortcut_state = f"Update {shortcut_available} bereit" if shortcut_available else "✓ Aktuell"
    version_card = f'<button type="button" class="card version-card" onclick="window.openUpdateSettings?.(\'ui\')"><div class="label">UTUBE MAC · UI</div><div class="value">{html.escape(version)}</div><div class="note">{html.escape(ui_state)} · Klick zum Prüfen</div></button>'
    shortcut_card = f'<button type="button" class="card version-card" onclick="window.openUpdateSettings?.(\'shortcut\')"><div class="label">KURZBEFEHL</div><div class="value">{html.escape(shortcut)}</div><div class="note">{html.escape(shortcut_state)} · Klick zum Prüfen</div></button>'
    update_card = f'<section class="message"><b>UI-Update verfügbar: {html.escape(available)}</b><br>Die App-Oberfläche wird direkt aus dem GitHub-UI-Paket aktualisiert. <form method="post" action="/action" style="display:inline"><input type="hidden" name="action" value="update"><button style="width:auto;margin:8px 0 0">UI-Update installieren</button></form></section>' if available else ""
    library_options = "".join(f'<option value="{html.escape(path, quote=True)}" {"selected" if path == str(DOWNLOADS) else ""}>{html.escape(path)}</option>' for path in library_locations())
    extension_state, extension_note = safari_extension_status()
    extension_card = f'<a class="card" href="/safari-extension">{card("Safari-Erweiterung", extension_state, extension_note)}</a>'
    dock_state, dock_note = dock_app_status()
    app_action = "open-dock-app" if dock_state == "Installiert" else "dock-app"
    app_button = "App öffnen" if dock_state == "Installiert" else "Auf dem Mac hinzufügen"
    dock_button = '<form method="post" action="/action" style="margin-top:10px"><input type="hidden" name="action" value="add-dock"><button class="secondary">Zum Dock hinzufügen</button></form>' if dock_state == "Installiert" else ""
    dock_card = f'<button type="button" onclick="document.getElementById(\'app-dialog\').showModal()" style="text-align:left;background:linear-gradient(135deg,#172a3cde,#0d1722e8);border:1px solid #2d4e69;border-radius:18px;padding:18px;color:#edf3f8;box-shadow:0 18px 45px #0006"><div class="label">UTUBE MAC App</div><div class="value">{html.escape(dock_state)}</div><div class="note">{html.escape(dock_note)}</div></button>'
    dock_dialog = f'''<dialog id="app-dialog" style="max-width:420px;border:1px solid #3b6686;border-radius:18px;padding:24px;background:#112132;color:#edf3f8;box-shadow:0 22px 70px #000"><h2>UTUBE MAC App</h2><p class="sub">Version {html.escape(local_version())} · lokale App für schnellen Zugriff ohne Safari-Adressleiste.</p><p class="note">{"Die App ist bereit. Du kannst sie jetzt öffnen oder zum Dock hinzufügen." if dock_state == "Installiert" else "Die App wird erstellt und anschließend im Dock abgelegt."}</p><form method="post" action="/action"><input type="hidden" name="action" value="{app_action}"><button>{app_button}</button></form>{dock_button}<button type="button" class="secondary" style="margin-top:10px" onclick="document.getElementById('app-dialog').close()">Schließen</button></dialog>'''
    home_style = '''<style>.home-status{grid-template-columns:repeat(3,minmax(0,1fr));margin:14px 0}.home-chart{margin:14px 0}.home-optional{margin:14px 0;border:1px solid #294b65;border-radius:14px;background:#0b1724}.home-optional summary{padding:12px 14px;cursor:pointer;color:#cfe4f5;font-weight:800}.home-optional>div{padding:0 14px 14px}.home-optional .panel{margin:0;border:0;background:transparent;box-shadow:none;padding:0}.home-download{max-width:none;min-height:410px}.home-download #recommendations{max-height:230px;overflow:auto}.home-library{padding:13px 16px!important;opacity:.88}.home-library h2{font-size:16px}.home-library .bar-item{margin:8px 0}.app-settings-dialog{border:1px solid #4e7ea6;border-radius:18px;background:#0b1724;color:#edf6ff;box-shadow:0 28px 80px #000c;padding:0;width:min(760px,94vw)}.app-settings-dialog::backdrop{background:#02070bb8}.app-settings-dialog>div{padding:22px}.app-settings-dialog h2{margin:0 0 14px}.app-settings-dialog button{width:auto}@media(max-width:760px){.home-status{grid-template-columns:1fr 1fr}.home-download{min-height:0}}</style><script>document.addEventListener('DOMContentLoaded',()=>{let main=document.querySelector('.app-main'),download=main?.querySelector('.home-download'),settingsPanel;main?.querySelectorAll(':scope>.panel').forEach(panel=>{let heading=panel.querySelector(':scope>h2'),name=heading?.textContent.trim();if(name==='Deine Mediathek'){panel.classList.add('home-library');if(download)download.before(panel)}if(name==='UTUBE MAC')settingsPanel=panel;if(name==='Warteschlange'){let details=document.createElement('details'),summary=document.createElement('summary'),body=document.createElement('div');details.className='home-optional';summary.textContent='Warteschlange';[...panel.children].forEach(node=>{if(node!==heading)body.appendChild(node)});details.append(summary,body);panel.replaceWith(details)}});if(settingsPanel){let dialog=document.createElement('dialog'),content=document.createElement('div'),heading=settingsPanel.querySelector(':scope>h2');dialog.className='app-settings-dialog';content.innerHTML='<h2>⚙ Einstellungen</h2><p class="sub">Speicherort, Einrichtung und Wartung von UTUBE MAC.</p>';[...settingsPanel.children].forEach(node=>{if(node!==heading)content.appendChild(node)});let close=document.createElement('button');close.type='button';close.className='secondary';close.textContent='Fertig';close.onclick=()=>dialog.close();content.append(close);dialog.append(content);document.body.append(dialog);settingsPanel.remove();let opener=document.getElementById('app-settings-open');opener?.addEventListener('click',event=>{event.preventDefault();dialog.showModal()});if(new URLSearchParams(location.search).get('settings')==='1')dialog.showModal()}})</script>'''
    home_cleaner = '''<style>
    .app-shell{width:100%!important;max-width:none!important;margin:0!important;padding:28px 42px 72px!important;box-sizing:border-box}.app-main{width:100%;min-width:0}
    .home-status{grid-template-columns:repeat(3,minmax(220px,1fr));gap:14px}.home-status .card{min-height:98px}.home-download{padding:24px!important;min-height:0}.home-download h2{font-size:22px;margin-bottom:4px}
    .home-download .actions{display:grid;grid-template-columns:minmax(240px,1fr) minmax(240px,1fr);gap:12px;margin:14px 0 18px}.home-download .actions button{min-height:46px;font-size:15px}.home-download .actions button:first-child{background:#5d7cff;border-color:#7893ff;color:white}
    .home-download-options{margin:14px 0;border-top:1px solid #294b65;padding-top:12px}.home-download-options summary{cursor:pointer;font-weight:750;color:#cfe4f5}.home-download-options>div{margin-top:14px}.home-download-options .grid{gap:14px}.home-download #recommendations{max-height:175px}.home-queue{margin-top:16px!important}.home-queue h2{font-size:18px}.home-queue .actions{margin-bottom:0}@media(max-width:760px){.app-shell{padding:16px!important}.home-status,.home-download .actions{grid-template-columns:1fr}}
    </style><script>document.addEventListener('DOMContentLoaded',()=>setTimeout(()=>{const main=document.querySelector('.app-main'),form=document.getElementById('download-form'),url=document.getElementById('url');if(!main||!form||!url)return;const actions=form.querySelector('.actions');if(actions){actions.querySelector('button:first-child').textContent='Jetzt herunterladen';actions.querySelector('button:last-child').textContent='Zur Warteschlange';url.insertAdjacentElement('afterend',actions)}const controls=[form.querySelector('.grid'),document.getElementById('last-choice'),document.getElementById('cow-mode')?.closest('label')].filter(Boolean);if(controls.length){const options=document.createElement('details'),body=document.createElement('div'),isYoutube=value=>/^(https?:\\/\\/)?(www\\.)?(youtube\\.com|youtu\\.be)\\//i.test(value.trim()),reveal=()=>{if(isYoutube(url.value))options.open=true};options.className='home-download-options';options.innerHTML='<summary>Weitere Optionen: Format, Qualität &amp; Terminal</summary>';controls.forEach(node=>body.appendChild(node));options.appendChild(body);form.querySelector('#recommendations')?.after(options);url.addEventListener('input',reveal);url.addEventListener('change',reveal);reveal()}const extras=[...main.querySelectorAll('.home-download button')].filter(button=>button.textContent.includes('Detaillierter Download')||button.textContent.includes('Videos suchen:'));if(extras.length){const tools=document.createElement('details'),body=document.createElement('div');tools.className='home-download-options';tools.innerHTML='<summary>Playlist &amp; detaillierte Auswahl</summary>';extras.forEach(button=>body.appendChild(button));tools.appendChild(body);form.querySelector('.home-download-options')?.after(tools)}const queue=[...main.querySelectorAll(':scope>.panel')].find(panel=>panel.querySelector(':scope>h2')?.textContent.trim()==='Warteschlange');queue?.classList.add('home-queue')},0))</script>'''
    home_queue_visible = '''<script>document.addEventListener('DOMContentLoaded',()=>{let queue=[...document.querySelectorAll('.app-main details.home-optional')].find(item=>item.querySelector('summary')?.textContent.trim()==='Warteschlange');if(queue)queue.open=true})</script>'''
    smart_profiles = '''<style>.smart-profile{display:flex;flex-wrap:wrap;gap:7px;margin:9px 0}.smart-profile button{width:auto;padding:7px 10px;font-size:12px}.smart-profile button.active{outline:2px solid #8fbeff}.smart-reason{display:block;margin-top:4px;color:#c3d9e9}</style><script>document.addEventListener('DOMContentLoaded',()=>{let url=document.getElementById('url'),box=document.getElementById('smart-download-suggestion'),title=document.getElementById('smart-download-title'),note=document.getElementById('smart-download-note'),apply=document.getElementById('smart-download-apply'),mode=document.getElementById('mode'),quality=document.getElementById('quality'),recommendations=document.getElementById('recommendations'),profile=localStorage.getItem('utube-smart-profile')||'balanced',suggestion;let profiles={balanced:'⚖️ Ausgewogen',storage:'💾 Speicher sparen',best:'🏆 Beste Qualität'};let chooser=document.createElement('div');chooser.className='smart-profile';Object.entries(profiles).forEach(([key,label])=>{let button=document.createElement('button');button.type='button';button.className='secondary';button.textContent=label;button.onclick=()=>{profile=key;localStorage.setItem('utube-smart-profile',key);choose()};chooser.appendChild(button)});box.prepend(chooser);function choose(){let text=(url.value+' '+recommendations.textContent).toLowerCase(),q=profile==='storage'?'720':profile==='best'?'best':'1080';if(/karaoke|instrumental|pista|official audio|lyrics|lyric video|audio only|podcast|hörbuch|interview/.test(text))suggestion={mode:'single-mp3-advanced',title:'🎵 Audio-Inhalt erkannt',note:' MP3 mit Metadaten spart Platz und speichert Titel, Interpret und Cover.'};else if(/picture test|bildtest|4k|hdr|nature|natur|travel|reise|cinematic|music video|musikvideo/.test(text))suggestion={mode:'single-mp4',quality:profile==='storage'?'1080':'best',title:'🖼️ Bildqualität wichtig',note:' Beste verfügbare Videoqualität wird empfohlen.'};else if(/tutorial|how to|kurs|screen|bildschirm|coding|code|tableau|excel|lernen/.test(text))suggestion={mode:'single-mp4',quality:profile==='storage'?'720':'1080',title:'🧑‍💻 Tutorial erkannt',note:' 1080p hält Text, Menüs und Bildschirmdetails lesbar.'};else if(/comedy|funny|sketch|talkshow|vlog|reaction|podcast/.test(text))suggestion={mode:'single-mp4',quality:profile==='best'?'1080':'720',title:'😂 Unterhaltung erkannt',note:' 720p ist meist scharf genug und spart Speicher.'};else suggestion={mode:'single-mp4',quality:q,title:'✨ Smart-Vorschlag',note:' Ausgewogenes MP4-Profil – du kannst es jederzeit ändern.'};chooser.querySelectorAll('button').forEach(button=>button.classList.toggle('active',button.textContent===profiles[profile]));title.textContent=suggestion.title;note.textContent=suggestion.note;box.hidden=!url.value.trim()}url.addEventListener('input',choose);new MutationObserver(choose).observe(recommendations,{childList:true,subtree:true,characterData:true});apply.addEventListener('click',()=>{if(!suggestion)return;mode.value=suggestion.mode;if(suggestion.quality)quality.value=suggestion.quality;updateControls();rememberDownloadChoices();box.hidden=true});choose()})</script>'''
    smart_profiles += '''<script>document.addEventListener('DOMContentLoaded',()=>{let url=document.getElementById('url'),box=document.getElementById('smart-download-suggestion'),title=document.getElementById('smart-download-title'),note=document.getElementById('smart-download-note'),mode=document.getElementById('mode'),quality=document.getElementById('quality'),recommendations=document.getElementById('recommendations');function set(modeValue,qualityValue){mode.value=modeValue;quality.value=qualityValue;updateControls();rememberDownloadChoices();box.hidden=true}function choose(){let text=(url.value+' '+recommendations.textContent).toLowerCase(),music=/karaoke|instrumental|pista|official audio|lyrics|lyric video|audio only|music|musik/.test(text),musicVideo=/official music video|music video|musikvideo/.test(text);if(!music)return;box.hidden=!url.value.trim();title.textContent=musicVideo?'🎬 Musikvideo erkannt':'🎵 Musik / Karaoke erkannt';note.innerHTML=musicVideo?' Wähle deine Version: <button type="button" class="secondary" id="music-mp3">MP3 · höchste Audioqualität</button> <button type="button" class="secondary" id="music-mp4">MP4 · bis 1080p</button>':' Standard: MP3 mit Metadaten in höchster verfügbarer Audioqualität.';if(musicVideo){note.querySelector('#music-mp3').onclick=()=>set('single-mp3-advanced','best');note.querySelector('#music-mp4').onclick=()=>set('single-mp4','1080')}else setTimeout(()=>{mode.value='single-mp3-advanced';quality.value='best';updateControls()},0)}url.addEventListener('input',choose);new MutationObserver(choose).observe(recommendations,{childList:true,subtree:true,characterData:true});choose()})</script>'''
    # This final handler deliberately evaluates only the URL currently in the
    # field.  Suggestion cards are allowed to be visible, but must never make a
    # different video look like music merely because its title contains Karaoke.
    smart_link_only = '''<script>document.addEventListener('DOMContentLoaded',()=>{const url=document.getElementById('url'),box=document.getElementById('smart-download-suggestion'),title=document.getElementById('smart-download-title'),note=document.getElementById('smart-download-note'),mode=document.getElementById('mode'),quality=document.getElementById('quality');let request=0;const musicWords=/karaoke|instrumental|pista|official audio|lyrics|lyric video|audio only|music|musik/i,videoWords=/official music video|music video|musikvideo/i;async function update(){const link=url.value.trim(),id=++request;if(!/^https?:\/\//i.test(link)){box.hidden=true;return}let label=link;try{const preview=await fetch('/youtube-preview?url='+encodeURIComponent(link)).then(response=>response.ok?response.json():{});if(id!==request||url.value.trim()!==link)return;label=String(preview.title||link)}catch(error){if(id!==request)return}if(id!==request)return;const isMusic=musicWords.test(label),isMusicVideo=videoWords.test(label);box.hidden=false;if(isMusicVideo){title.textContent='🎬 Musikvideo erkannt';note.innerHTML=' Genau dieser Link ist ein Musikvideo: <button type="button" class="secondary" id="exact-music-mp3">MP3 · höchste Audioqualität</button> <button type="button" class="secondary" id="exact-music-mp4">MP4 · bis 1080p</button>';note.querySelector('#exact-music-mp3').onclick=()=>{mode.value='single-mp3-advanced';quality.value='best';updateControls();rememberDownloadChoices()};note.querySelector('#exact-music-mp4').onclick=()=>{mode.value='single-mp4';quality.value='1080';updateControls();rememberDownloadChoices()};return}if(isMusic){title.textContent='🎵 Musik / Karaoke erkannt';note.textContent=' Genau dieser Link enthält Musik oder Karaoke. Standard: MP3 mit Metadaten in höchster verfügbarer Audioqualität.';mode.value='single-mp3-advanced';quality.value='best';updateControls();rememberDownloadChoices();return}title.textContent='✨ Smart-Vorschlag';note.textContent=' Genau dieser Link wird als Video behandelt. Vorschlag: MP4 bis 1080p.';mode.value='single-mp4';quality.value='1080';updateControls();rememberDownloadChoices()}url.addEventListener('input',()=>setTimeout(update,0));url.addEventListener('change',update);update()})</script>'''
    top_card_design_sync = '''<script>document.addEventListener('DOMContentLoaded',()=>{const paint=()=>{const sample=[...document.querySelectorAll('button')].find(button=>!button.classList.contains('card')&&!button.classList.contains('secondary'));if(!sample)return;const style=getComputedStyle(sample);document.querySelectorAll('.home-status>.card').forEach(card=>{card.style.setProperty('background',style.background,'important');card.style.setProperty('color',style.color,'important')})};let queued=false,refresh=()=>{if(queued)return;queued=true;setTimeout(()=>{queued=false;paint()},20)};paint();new MutationObserver(refresh).observe(document.head,{childList:true,subtree:true,characterData:true});document.addEventListener('input',refresh,true);document.addEventListener('change',refresh,true)})</script>'''
    settings_concept = '''<style>.settings-shell{display:grid;grid-template-columns:165px 1fr;gap:18px;min-height:350px}.settings-nav{display:grid;align-content:start;gap:5px;padding-right:12px;border-right:1px solid #294b65}.settings-nav button{text-align:left;background:transparent;color:#b9d0df;padding:9px}.settings-nav button.active{background:#1c405d;color:#fff}.settings-view{display:none;gap:12px}.settings-view.active{display:grid}.settings-view h3{margin:0}.settings-update-row{display:flex;justify-content:space-between;align-items:center;padding:12px;border:1px solid #315878;border-radius:12px;background:#102236}.settings-update-row button{width:auto}@media(max-width:600px){.settings-shell{grid-template-columns:1fr}.settings-nav{grid-template-columns:repeat(3,1fr);border-right:0;border-bottom:1px solid #294b65;padding:0 0 10px}.settings-nav button{font-size:12px}}</style><script>document.addEventListener('DOMContentLoaded',()=>setTimeout(()=>{let dialog=document.querySelector('.app-settings-dialog');if(!dialog)return;let select=dialog.querySelector('#library-location'),controls=[...dialog.querySelectorAll('button')].filter(button=>button.textContent!=='Fertig'),finish=dialog.querySelector('button:last-child'),versions=[...document.querySelectorAll('.version-card .value')].map(node=>node.textContent);dialog.innerHTML='<div><h2>⚙ Einstellungen</h2><p class="sub">Downloads, Mediathek, Wiedergabe und Updates an einem Ort.</p><div class="settings-shell"><nav class="settings-nav"></nav><main class="settings-main"></main></div></div>';let nav=dialog.querySelector('.settings-nav'),main=dialog.querySelector('.settings-main'),sections={Downloads:'<h3>Downloads</h3><p class="hint">Smart Download macht nur einen Vorschlag. Du entscheidest weiterhin selbst.</p><label>Smart-Profil<select id="settings-smart-profile"><option value="balanced">⚖️ Ausgewogen</option><option value="storage">💾 Speicher sparen</option><option value="best">🏆 Beste Qualität</option></select></label>',Mediathek:'<h3>Mediathek</h3><p class="hint">Ordner verwalten, ohne Dateien zu verschieben oder zu löschen.</p>',Wiedergabe:'<h3>Wiedergabe</h3><label class="hint"><input id="settings-autoplay" type="checkbox"> Wiedergabe automatisch starten</label><p class="hint">Die Wiedergabeposition wird automatisch gespeichert.</p>',Updates:'<h3>Updates</h3><div class="settings-update-row"><span><b>UI-App '+(versions[0]||'—')+'</b><br><small>GitHub-UI-Pakete werden getrennt geprüft.</small></span><form method="post" action="/action"><input type="hidden" name="action" value="update"><button>UI prüfen</button></form></div><div class="settings-update-row"><span><b>Shortcut '+(versions[1]||'—')+'</b><br><small>Shortcut-Version wird getrennt angezeigt.</small></span><button type="button" id="shortcut-check">Shortcut prüfen</button></div><label class="hint"><input id="settings-auto-updates" type="checkbox"> Beim Start auf Updates prüfen</label>',Erweiterungen:'<h3>Erweiterungen</h3><p class="hint">Safari-Erweiterung verbindet offene YouTube-Videos mit UTUBE MAC.</p><a class="folder" href="/safari-extension">Safari-Erweiterung öffnen</a>',Erweitert:'<h3>Erweitert</h3><p class="hint">Einrichtung und Diagnose. Diese Bereiche verändern keine Medien.</p>'};Object.entries(sections).forEach(([name,markup],index)=>{let button=document.createElement('button'),view=document.createElement('section');button.type='button';button.textContent=name;view.className='settings-view';view.innerHTML=markup;button.onclick=()=>{nav.querySelectorAll('button').forEach(item=>item.classList.toggle('active',item===button));main.querySelectorAll('.settings-view').forEach(item=>item.classList.toggle('active',item===view))};nav.append(button);main.append(view);if(index===0)button.click()});let library=main.querySelectorAll('.settings-view')[1];if(select)library.append(select);controls.slice(0,3).forEach(button=>library.append(button));let advanced=main.querySelectorAll('.settings-view')[5];controls.slice(3).forEach(button=>advanced.append(button));advanced.append(finish);let profile=main.querySelector('#settings-smart-profile');profile.value=localStorage.getItem('utube-smart-profile')||'balanced';profile.onchange=()=>localStorage.setItem('utube-smart-profile',profile.value);for(let key of ['autoplay','auto-updates']){let input=main.querySelector('#settings-'+key);input.checked=localStorage.getItem('utube-'+key)==='1';input.onchange=()=>localStorage.setItem('utube-'+key,input.checked?'1':'0')}main.querySelector('#shortcut-check').onclick=()=>alert('Shortcut '+(versions[1]||'—')+' ist lokal installiert. Eine getrennte GitHub-Prüfung folgt.');window.openUpdateSettings=()=>{dialog.showModal();[...nav.querySelectorAll('button')].find(item=>item.textContent==='Updates')?.click()};document.getElementById('app-settings-open')?.addEventListener('click',event=>{event.preventDefault();dialog.showModal()})},40))</script>'''
    update_workflow = '''<style>.update-check{display:grid;gap:11px}.update-spinner{display:inline-block;width:15px;height:15px;border:2px solid #8bb8df;border-top-color:transparent;border-radius:50%;vertical-align:-2px;animation:update-spin .7s linear infinite}@keyframes update-spin{to{transform:rotate(360deg)}}.app-settings-dialog{position:relative}.developer-corner{position:absolute;left:20px;bottom:18px;z-index:10;width:36px;height:36px;display:grid;place-items:center;border-radius:11px;background:#162f46;border:1px solid #4b7597;color:#d9ecff;font-size:17px;box-shadow:0 9px 25px #0008}.settings-close{position:absolute;right:16px;top:14px;width:auto!important;padding:6px 10px!important}</style><script>document.addEventListener('DOMContentLoaded',()=>setTimeout(()=>{let settings=document.querySelector('.app-settings-dialog'),update=[...document.querySelectorAll('.settings-view')].find(section=>section.querySelector('h3')?.textContent==='Updates'),advanced=[...document.querySelectorAll('.settings-view')].find(section=>section.querySelector('h3')?.textContent==='Erweitert');if(!settings||!update)return;let close=document.createElement('button');close.type='button';close.className='secondary settings-close';close.textContent='Schließen ✕';close.onclick=()=>settings.close();settings.append(close);let developer=document.createElement('a');developer.className='developer-corner';developer.href='/developer';developer.title='Entwickler-Einstellungen';developer.textContent='⌘';settings.append(developer);if(advanced){advanced.innerHTML='<h3>Erweitert</h3><p class="hint">Entwickler- und Wartungsfunktionen sind über das ⌘-Symbol unten links erreichbar. So bleiben die normalen Einstellungen übersichtlich.</p>'}let auto=update.querySelector('#settings-auto-updates');update.innerHTML='<h3>Updates</h3><p class="hint">UI und Shortcut werden gemeinsam geprüft. Getrennte Aktionen gibt es nur in ⌘ Entwicklung.</p><div class="update-check"><button type="button" id="check-all-updates">Alle Updates prüfen</button><p id="update-check-result" class="hint">Noch nicht geprüft.</p></div>';if(auto)update.append(auto.parentElement);let button=update.querySelector('#check-all-updates'),result=update.querySelector('#update-check-result');button.onclick=async()=>{button.disabled=true;button.innerHTML='<span class="update-spinner"></span> Suche auf GitHub …';result.textContent='UI- und Shortcut-Versionen werden geprüft.';try{let state=await fetch('/update-status',{cache:'no-store'}).then(response=>response.json()),ui=state.ui,shortcut=state.shortcut,updates=[];if(ui.update)updates.push('UI '+ui.available);if(shortcut.update)updates.push('Shortcut '+shortcut.available);if(!updates.length){result.textContent='✓ Alles aktuell · UI '+ui.installed+' · Shortcut '+shortcut.installed;alert('Alles aktuell.\n\nUI: '+ui.installed+'\nShortcut: '+shortcut.installed);return}result.textContent='Update verfügbar: '+updates.join(' · ');let dialog=document.createElement('dialog');dialog.className='media-info-dialog';dialog.innerHTML='<div><h2>Update verfügbar</h2><p class="sub">'+updates.join('<br>')+'</p><p class="hint">Die Versionsnotizen werden vor der Installation angezeigt.</p><div class="actions"><button id="all-update">Alles aktualisieren</button><button class="secondary" id="ui-update">Nur UI aktualisieren</button><button class="secondary" id="close-update">Später</button></div></div>';document.body.append(dialog);dialog.showModal();dialog.querySelector('#close-update').onclick=()=>dialog.close();let submit=mode=>{let form=document.createElement('form');form.method='post';form.action='/action';form.innerHTML='<input name="action" value="update"><input name="mode" value="'+mode+'">';document.body.append(form);form.submit()};dialog.querySelector('#all-update').onclick=()=>submit('all');dialog.querySelector('#ui-update').onclick=()=>submit('ui')}catch(error){result.textContent='⚠️ GitHub konnte gerade nicht erreicht werden.'}finally{button.disabled=false;button.textContent='Alle Updates prüfen'}}},100))</script>'''
    bell_count = int(bool(available)) + int(bool(shortcut_available))
    notification_bell = f'''<style>.notification-bell{{position:fixed;top:19px;right:25px;z-index:9500;display:grid;place-items:center;width:30px;height:30px;background:transparent;color:#fff;border:0;font:20px/1 -apple-system,BlinkMacSystemFont,"Segoe UI Symbol",sans-serif;text-decoration:none;box-shadow:none}}.notification-count{{position:absolute;top:-5px;right:-5px;display:grid;place-items:center;min-width:18px;height:18px;padding:0 3px;border-radius:999px;background:#ff4f66;color:#fff;font:800 11px -apple-system,sans-serif}}</style><a class="notification-bell" href="/download-notifications" title="Download-Mitteilungen" aria-label="Download-Mitteilungen">&#128276;&#65038;{('<span class="notification-count">'+str(bell_count)+'</span>') if bell_count else ''}</a>'''
    update_badge = int(bool(available)) + int(bool(shortcut_available))
    content = f'''{home_style}{home_cleaner}{home_queue_visible}<section class="grid home-status">{version_card}{shortcut_card}<a class="card" href="/library">{card("Mediathek", str(sum(counts.values())) + " Dateien", "Videos und Audio")}</a><a class="card" href="/storage">{card("Freier Speicher", str(free_space) + " GB", "Speicher verwalten")}</a></section><details class="home-optional"><summary>App-Status &amp; Erweiterungen</summary><div class="grid">{extension_card}{dock_card}</div></details>{dock_dialog}{update_card}
<section class="panel home-download"><h2>Neuer Download</h2><p class="sub">Link einfügen, Format wählen und starten. Weitere Optionen bleiben verfügbar, ohne den Start zu überladen.</p>
<form id="download-form" method="post" action="/action"><input type="hidden" name="action" value="download"><input id="url" name="url" placeholder="YouTube-Link einfügen" required autofocus onfocus="showSuggestions()"><div id="recommendations" class="folders" style="display:none;margin:-2px 0 12px"></div><div id="smart-download-suggestion" class="message" hidden><b id="smart-download-title"></b><span id="smart-download-note"></span><button type="button" class="secondary" id="smart-download-apply">Vorschlag übernehmen</button></div><div class="grid"><div><label class="label">Was möchtest du laden?</label><select id="mode" name="mode" onchange="updateControls()"><option value="single-mp4">Einzelnes Video – MP4</option><option value="playlist-mp4">Playlist – MP4</option><option value="single-mkv">Einzelnes Video – MKV</option><option value="playlist-mkv">Playlist – MKV</option><option value="single-mp3">Einzelnes Audio – MP3</option><option value="playlist-mp3">Playlist – MP3</option><option value="single-mp3-advanced">Einzelnes Audio – MP3 mit Metadaten</option><option value="playlist-mp3-advanced">Playlist – MP3 mit Metadaten</option></select></div><div id="quality-container"><label class="label">Videoqualität</label><select id="quality" name="quality"><option value="best">Beste verfügbare Qualität</option><option value="2160">Bis 4K</option><option value="1080">Bis 1080p</option><option value="720">Bis 720p</option><option value="480">Bis 480p</option></select></div><div><label class="label">Untertitel</label><input id="subtitles" name="subtitles" value="none" readonly><p class="hint">Für zuverlässige Downloads momentan ausgeschaltet.</p></div></div><p id="last-choice" class="hint"></p><label class="hint"><input id="cow-mode" type="checkbox"> Kuh-Fortschrittsfenster im Terminal verwenden</label><div class="actions"><button type="button" onclick="startDownload()">Download starten</button><button type="button" class="secondary" onclick="addToQueue()">Zur Warteschlange hinzufügen</button></div></form><div id="web-progress" class="progress-box"><b id="progress-title">Download wird vorbereitet …</b><p id="progress-phase" class="sub">Bitte einen Moment.</p><div class="bar-track"><div id="progress-fill" class="progress-fill" style="width:3%"></div></div><div class="progress-meta"><span id="progress-percent">0%</span><span id="progress-speed">—</span><span id="progress-eta">—</span></div><button id="cancel-download" type="button" class="danger" hidden>Download abbrechen</button></div><p class="hint">Klicke in das Linkfeld: offene YouTube-Videos erscheinen direkt als Vorschläge.</p></section>
<section class="panel"><h2>Warteschlange</h2><p class="sub">Sammle Downloads und starte sie anschließend nacheinander in einem Terminal-Fenster.</p><div id="queue" class="folders"></div><div class="actions"><button type="button" onclick="startQueue()">Warteschlange starten</button><button type="button" class="secondary" onclick="clearQueue()">Leeren</button></div></section>
	<section class="panel"><h2>UTUBE MAC</h2><label class="label">Mediathek-Speicherort für die Einrichtung</label><select id="library-location">{library_options}</select><div class="actions"><button type="button" class="secondary" onclick="chooseLibrary()">Anderen Ordner auswählen</button><button type="button" class="secondary" onclick="removeLibrary()">Aus Liste entfernen</button><form method="post" action="/action"><input type="hidden" name="action" value="folder"><button class="secondary">Download-Ordner öffnen</button></form><form method="post" action="/action" onsubmit="return confirm('Update-Prüfung starten?');"><input type="hidden" name="action" value="update"><button class="secondary">Update prüfen</button></form><button type="button" class="secondary" onclick="startSetup()">Einrichtung starten</button></div><p class="hint">Der ausgewählte Ordner wird gespeichert. Ein Shortcut mit bereits übergebenem Ordner fragt nicht erneut nach. „Aus Liste entfernen“ löscht keine Dateien.</p><div id="setup-progress" class="progress-box"><b id="setup-stage">Einrichtung wird gestartet …</b><p class="sub">Das Terminal bleibt für macOS- und Homebrew-Bestätigungen offen. Hier siehst du die verständliche Zusammenfassung.</p><div id="setup-lines" class="file-list"></div></div></section>'''
    chooser = '''<script>let queue=JSON.parse(localStorage.getItem('utube-mac-queue')||'[]'),progressTimer;function updateControls(){let audio=document.getElementById('mode').value.includes('mp3');document.getElementById('quality-container').style.display=audio?'none':''}function showProgress(job){let box=document.getElementById('web-progress');box.classList.add('show');clearInterval(progressTimer);progressTimer=setInterval(async()=>{try{let data=await fetch('/progress?job='+encodeURIComponent(job)).then(r=>r.json()),item=data[0];if(!item)return;let percent=parseFloat(item.PERCENT)||0;document.getElementById('progress-title').textContent=item.TITLE||'UTUBE MAC Download';document.getElementById('progress-phase').textContent=item.PHASE||'Download läuft';document.getElementById('progress-fill').style.width=Math.max(3,Math.min(100,percent))+'%';document.getElementById('progress-percent').textContent=Math.round(percent)+'%';document.getElementById('progress-speed').textContent=item.SPEED||'—';document.getElementById('progress-eta').textContent=item.ETA||'—';if(item.done){clearInterval(progressTimer);document.getElementById('progress-phase').textContent=item.RESULT==='completed'?'Fertig – deine Datei ist in der Mediathek.':(item.RESULT||'Download beendet.')}}catch(e){}},900)}async function startDownload(){let url=document.getElementById('url').value.trim();if(!url.startsWith('http')){alert('Bitte zuerst einen YouTube-Link auswählen oder einfügen.');return}if(document.getElementById('cow-mode').checked){if(confirm('Kuh-Fortschrittsfenster im Terminal starten?'))document.getElementById('download-form').submit();return}let body={url,mode:document.getElementById('mode').value,quality:document.getElementById('quality').value,subtitles:document.getElementById('subtitles').value};let response=await fetch('/download-background',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});if(!response.ok){alert('Download konnte nicht gestartet werden.');return}let result=await response.json();showProgress(result.job)}function renderQueue(){let box=document.getElementById('queue');box.innerHTML=queue.length?'':'<p class="sub">Noch keine Downloads vorgemerkt.</p>';queue.forEach((item,index)=>{let b=document.createElement('button');b.type='button';b.className='secondary';b.textContent=(item.mode.includes('playlist')?'Playlist':'Single')+' · '+item.mode.replace(/.*-/,'').toUpperCase()+'  ×';b.onclick=()=>{queue.splice(index,1);saveQueue()};box.appendChild(b)})}function saveQueue(){localStorage.setItem('utube-mac-queue',JSON.stringify(queue));renderQueue()}function addToQueue(){let url=document.getElementById('url').value.trim();if(!url.startsWith('http')){alert('Bitte zuerst einen YouTube-Link auswählen oder einfügen.');return}queue.push({url:url,mode:document.getElementById('mode').value,quality:document.getElementById('quality').value,subtitles:document.getElementById('subtitles').value});document.getElementById('url').value='';saveQueue()}function clearQueue(){queue=[];saveQueue()}async function startQueue(){if(!queue.length){alert('Die Warteschlange ist leer.');return}if(!confirm(queue.length+' Download(s) nacheinander im Terminal starten?'))return;let r=await fetch('/queue',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(queue)});if(r.ok){clearQueue();alert('Die Warteschlange wurde im Terminal gestartet.')}else alert('Die Warteschlange konnte nicht gestartet werden.')}function thumbnail(url){let m=url.match(/[?&]v=([^&]+)/)||url.match(/youtu\\.be\\/([^?&/]+)/)||url.match(/shorts\\/([^?&/]+)/);return m?'https://i.ytimg.com/vi/'+m[1]+'/hqdefault.jpg':''}function kind(url){let m=url.match(/[?&]list=([^&]+)/);return m&&!m[1].startsWith('RD')?'Playlist':'Einzelnes Video'}async function showSuggestions(){let box=document.getElementById('recommendations');box.style.display='grid';box.innerHTML='<p class="sub">Offene YouTube-Videos werden geladen …</p>';try{let items=await fetch('/safari-tabs').then(r=>r.json());box.innerHTML='';if(!items.length)box.innerHTML='<p class="sub">Keine offenen YouTube-Videos gefunden.</p>';items.forEach(item=>{let b=document.createElement('button'),img=thumbnail(item.url);b.type='button';b.className='secondary';b.style.textAlign='left';b.style.padding='10px';b.innerHTML=(img?'<img src="'+img+'" style="width:96px;height:54px;object-fit:cover;border-radius:7px;vertical-align:middle;margin-right:9px">':'')+'<span><strong>'+kind(item.url)+'</strong><br>'+item.title.replace(/</g,'&lt;')+'</span>';b.onclick=()=>{document.getElementById('url').value=item.url;box.style.display='none'};box.appendChild(b)})}catch(e){box.innerHTML='<p class="sub">Safari konnte nicht abgefragt werden.</p>'}}updateControls();renderQueue()</script>'''
    setup_script = '''<script>let setupTimer;function startSetup(){if(!confirm('Einrichtung im Terminal starten? Die verständliche Übersicht bleibt hier sichtbar.'))return;fetch('/setup-web',{method:'POST'}).then(r=>{if(!r.ok)throw Error();document.getElementById('setup-progress').classList.add('show');clearInterval(setupTimer);setupTimer=setInterval(refreshSetup,1100);refreshSetup()}).catch(()=>alert('Einrichtung konnte nicht gestartet werden.'))}async function refreshSetup(){try{let data=await fetch('/setup-progress').then(r=>r.json()),lines=document.getElementById('setup-lines');document.getElementById('setup-stage').textContent=data.stage||'Einrichtung läuft';lines.innerHTML=(data.lines||[]).map(line=>'<div class="hint">'+line.replace(/</g,'&lt;')+'</div>').join('')||'<div class="hint">Warte auf die erste Rückmeldung aus der Einrichtung …</div>';if(data.done||data.failed){clearInterval(setupTimer);document.getElementById('setup-stage').textContent=data.done?'Einrichtung abgeschlossen.':'Einrichtung braucht Aufmerksamkeit im Terminal.'}}catch(e){}}document.addEventListener('DOMContentLoaded',()=>{let mode=document.getElementById('mode'),last=localStorage.getItem('utube-mac-last-mode');if(last&&[...mode.options].some(option=>option.value===last))mode.value=last;mode.addEventListener('change',()=>localStorage.setItem('utube-mac-last-mode',mode.value));updateControls();if(new URLSearchParams(location.search).get('setup')==='1'){document.getElementById('setup-progress').classList.add('show');clearInterval(setupTimer);setupTimer=setInterval(refreshSetup,1100);refreshSetup()}})</script>'''
    library_script = '''<script>async function chooseLibrary(){try{let r=await fetch('/choose-library',{method:'POST'});if(!r.ok)return;let d=await r.json();if(!d.path)return;let select=document.getElementById('library-location'),option=document.createElement('option');option.value=d.path;option.textContent=d.path;option.selected=true;select.appendChild(option)}catch(e){}}async function removeLibrary(){let select=document.getElementById('library-location'),path=select.value;if(!confirm('Diesen Ordner nur aus der gespeicherten Liste entfernen? Dateien bleiben erhalten.'))return;let r=await fetch('/remove-library',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({path:path})});if(r.ok){select.options[select.selectedIndex].remove()}}let originalStartSetup=startSetup;startSetup=function(){let path=document.getElementById('library-location').value;if(!confirm('Einrichtung mit diesem Speicherort starten?\n'+path))return;fetch('/setup-web',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({path:path})}).then(r=>{if(!r.ok)throw Error();document.getElementById('setup-progress').classList.add('show');clearInterval(setupTimer);setupTimer=setInterval(refreshSetup,1100);refreshSetup()}).catch(()=>alert('Einrichtung konnte nicht gestartet werden.'))}</script>'''
    choice_script = '''<script>function rememberDownloadChoices(){let mode=document.getElementById('mode'),quality=document.getElementById('quality'),label=document.getElementById('last-choice');localStorage.setItem('utube-mac-last-mode',mode.value);localStorage.setItem('utube-mac-last-quality',quality.value);label.textContent='Gespeichert für den nächsten Download: '+mode.options[mode.selectedIndex].text+' · '+quality.options[quality.selectedIndex].text}document.addEventListener('DOMContentLoaded',()=>{let quality=document.getElementById('quality'),lastQuality=localStorage.getItem('utube-mac-last-quality');if(lastQuality&&[...quality.options].some(option=>option.value===lastQuality))quality.value=lastQuality;document.getElementById('mode').addEventListener('change',rememberDownloadChoices);quality.addEventListener('change',rememberDownloadChoices);rememberDownloadChoices()})</script>'''
    smart_download_script = '''<script>document.addEventListener('DOMContentLoaded',()=>{let url=document.getElementById('url'),box=document.getElementById('smart-download-suggestion'),title=document.getElementById('smart-download-title'),note=document.getElementById('smart-download-note'),apply=document.getElementById('smart-download-apply'),mode=document.getElementById('mode'),quality=document.getElementById('quality'),recommendations=document.getElementById('recommendations'),suggestion=null;function updateSuggestion(){let text=(url.value+' '+recommendations.textContent).toLowerCase();suggestion=null;if(/karaoke|instrumental|pista|official audio|lyrics|lyric video|audio only/.test(text))suggestion={mode:'single-mp3-advanced',title:'🎵 Audio erkannt',note:' Für Karaoke, Instrumental und Audio-Videos ist MP3 mit Metadaten meist die beste Wahl.'};else if(/official music video|music video|musikvideo/.test(text))suggestion={mode:'single-mp4',quality:'best',title:'🎬 Musikvideo erkannt',note:' Vorschlag: Video in der besten verfügbaren Qualität.'};box.hidden=!suggestion;if(suggestion){title.textContent=suggestion.title;note.textContent=suggestion.note}}url.addEventListener('input',updateSuggestion);new MutationObserver(updateSuggestion).observe(recommendations,{childList:true,subtree:true,characterData:true});apply.addEventListener('click',()=>{if(!suggestion)return;mode.value=suggestion.mode;if(suggestion.quality)quality.value=suggestion.quality;updateControls();rememberDownloadChoices();box.hidden=true})})</script>'''
    dashboard_download_script = '''<script>document.addEventListener('DOMContentLoaded',()=>{let usualStartDownload=startDownload;startDownload=async function(){if(!document.getElementById('cow-mode').checked)return usualStartDownload();let url=document.getElementById('url').value.trim();if(!url.startsWith('http')){alert('Bitte zuerst einen YouTube-Link auswählen oder einfügen.');return}let progress=document.getElementById('web-progress'),title=document.getElementById('progress-title'),phase=document.getElementById('progress-phase');title.textContent='Dashboard-Terminal wird geöffnet …';phase.textContent='Der Download läuft anschließend im farbigen Terminal-Fortschrittsfenster.';progress.classList.add('show');try{let response=await fetch('/download-dashboard',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({url,mode:document.getElementById('mode').value,quality:document.getElementById('quality').value,subtitles:document.getElementById('subtitles').value})});if(!response.ok)throw Error();title.textContent='✓ Dashboard-Terminal gestartet';phase.textContent='Das Terminal-Fenster zeigt jetzt Fortschritt, Geschwindigkeit und Restzeit.'}catch(error){title.textContent='⚠️ Dashboard-Terminal konnte nicht geöffnet werden';phase.textContent='Bitte prüfe, ob Terminal auf deinem Mac geöffnet werden darf.'}}})</script>'''
    playlist_ui_script = r'''<style>.playlist-fallback-thumb{display:inline-grid;place-items:center;width:96px;height:54px;margin-right:9px;border-radius:7px;vertical-align:middle;background:linear-gradient(135deg,#7d4cff,#1a6fc6);font-size:26px}</style><script>document.addEventListener('DOMContentLoaded',()=>{let url=document.getElementById('url'),mode=document.getElementById('mode'),recommendations=document.getElementById('recommendations');let choices={mp4:'MP4',mkv:'MKV',mp3:'MP3',advanced:'MP3 mit Metadaten'};function option(value,label){return '<option value="'+value+'">'+label+'</option>'}function rebuild(){let playlist=/(?:[?&]list=|\/playlist\?)/.test(url.value),chosen=mode.value,main=playlist?[['playlist-mp4','Playlist – '+choices.mp4],['playlist-mkv','Playlist – '+choices.mkv],['playlist-mp3','Playlist – '+choices.mp3],['playlist-mp3-advanced','Playlist – '+choices.advanced]]:[['single-mp4','Einzelnes Video – '+choices.mp4],['single-mkv','Einzelnes Video – '+choices.mkv],['single-mp3','Einzelnes Audio – '+choices.mp3],['single-mp3-advanced','Einzelnes Audio – '+choices.advanced]],more=playlist?[['single-mp4','Einzelnes Video – '+choices.mp4],['single-mkv','Einzelnes Video – '+choices.mkv],['single-mp3','Einzelnes Audio – '+choices.mp3],['single-mp3-advanced','Einzelnes Audio – '+choices.advanced]]:[['playlist-mp4','Playlist – '+choices.mp4],['playlist-mkv','Playlist – '+choices.mkv],['playlist-mp3','Playlist – '+choices.mp3],['playlist-mp3-advanced','Playlist – '+choices.advanced]];mode.innerHTML='<optgroup label="'+(playlist?'Playlist herunterladen':'Einzelnes Video herunterladen')+'">'+main.map(item=>option(item[0],item[1])).join('')+'</optgroup><optgroup label="Mehr Optionen">'+more.map(item=>option(item[0],item[1])).join('')+'</optgroup>';mode.value=(playlist&&chosen.startsWith('playlist-')||!playlist&&chosen.startsWith('single-'))?chosen:main[0][0];updateControls();mode.dispatchEvent(new Event('change'))}function addPlaylistArtwork(){recommendations.querySelectorAll('button').forEach(button=>{if(!button.querySelector('img,.playlist-fallback-thumb')&&/playlist/i.test(button.textContent)){let art=document.createElement('span');art.className='playlist-fallback-thumb';art.textContent='📚';button.prepend(art)}})}url.addEventListener('input',rebuild);new MutationObserver(()=>{rebuild();addPlaylistArtwork()}).observe(recommendations,{childList:true,subtree:true});rebuild();addPlaylistArtwork()})</script>'''
    protected_json = json.dumps(sorted(PROTECTED_LIBRARIES))
    protection_script = f'''<script>const protectedLibraries=new Set({protected_json});function updateLibraryRemoveState(){{let select=document.getElementById('library-location'),button=document.querySelector('button[onclick="removeLibrary()"]');if(!select||!button)return;let protectedFolder=protectedLibraries.has(select.value);button.disabled=protectedFolder;button.title=protectedFolder?'Standard- und Apple-Music-Ordner bleiben immer verfügbar.':'Diesen gespeicherten Ordner aus der Liste entfernen';button.textContent=protectedFolder?'Geschützter Standardordner':'Aus Liste entfernen'}}document.addEventListener('DOMContentLoaded',()=>{{let select=document.getElementById('library-location');select.addEventListener('change',updateLibraryRemoveState);updateLibraryRemoveState()}})</script>'''
    cancel_download_script = '''<script>document.addEventListener('DOMContentLoaded',()=>{let activeJob='',originalShowProgress=showProgress,cancel=document.getElementById('cancel-download');showProgress=function(job){activeJob=job;cancel.hidden=false;cancel.disabled=false;cancel.textContent='Download abbrechen';return originalShowProgress(job)};cancel.onclick=async()=>{if(!activeJob||!confirm('Diesen laufenden Download wirklich abbrechen? Bereits fertige Dateien bleiben erhalten.'))return;cancel.disabled=true;cancel.textContent='Download wird abgebrochen …';try{let response=await fetch('/cancel-download',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({job:activeJob})});if(!response.ok)throw Error();document.getElementById('progress-phase').textContent='Download wird beendet …';setTimeout(()=>{cancel.hidden=true;document.getElementById('progress-phase').textContent='Vom Nutzer abgebrochen. Bereits fertige Dateien bleiben erhalten.'},900)}catch(error){cancel.disabled=false;cancel.textContent='Download abbrechen';alert('Der Download konnte nicht abgebrochen werden. Möglicherweise ist er bereits fertig.')}}})</script>'''
    preview_script = '''<script>document.addEventListener('DOMContentLoaded',()=>{let url=document.getElementById('url'),timer,token=0;let card=document.createElement('div');card.id='youtube-preview';card.className='folder';card.style.display='none';url.insertAdjacentElement('afterend',card);async function loadPreview(){let value=url.value.trim(),current=++token;if(!value.startsWith('http')){card.style.display='none';return}card.style.display='block';card.textContent='YouTube-Vorschau wird geladen …';try{let data=await fetch('/youtube-preview?url='+encodeURIComponent(value)).then(r=>r.json());if(current!==token)return;let title=(data.title||'YouTube').replace(/</g,'&lt;'),image=data.thumbnail?'<img src="'+data.thumbnail+'" style="width:120px;height:68px;object-fit:cover;border-radius:8px;vertical-align:middle;margin-right:10px">':'<span class="playlist-fallback-thumb">📚</span>';card.innerHTML=image+'<strong>'+(data.playlist?'Playlist':'Video')+'</strong><br><span>'+title+'</span>'}catch(error){if(current===token)card.style.display='none'}}url.addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(loadPreview,500)});if(url.value)loadPreview()})</script>'''
    duplicate_preview_script = '''<style>#library-duplicate{margin-top:8px;background:#18351f;border-color:#4a9560;color:#e0ffe7}</style><script>document.addEventListener('DOMContentLoaded',()=>{let input=document.getElementById('url'),timer,notice=document.createElement('div');notice.id='library-duplicate';notice.className='folder';notice.hidden=true;input.insertAdjacentElement('afterend',notice);async function check(){let url=input.value.trim();if(!url.startsWith('http')){notice.hidden=true;return}try{let data=await fetch('/library-match?url='+encodeURIComponent(url)).then(r=>r.json()),match=data.match;if(!match){notice.hidden=true;return}notice.hidden=false;notice.innerHTML='✓ Schon in deiner Mediathek: <strong>'+String(match.title||'Video').replace(/</g,'&lt;')+'</strong> <a href="/library">Mediathek öffnen</a>'}catch(error){notice.hidden=true}}input.addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(check,650)});if(input.value)check()})</script>'''
    preview_details_script = '''<style>#youtube-preview-details{display:flex;flex-wrap:wrap;gap:7px;margin:8px 0;color:#bdd8ef}#youtube-preview-details span{padding:5px 8px;border-radius:999px;background:#132c42;border:1px solid #315b7c;font-size:12px}</style><script>document.addEventListener('DOMContentLoaded',()=>{let input=document.getElementById('url'),timer,details=document.createElement('div');details.id='youtube-preview-details';input.insertAdjacentElement('afterend',details);let clock=seconds=>{seconds=Math.floor(seconds||0);return Math.floor(seconds/3600)+(seconds>=3600?'h ':'m ')+String(Math.floor(seconds%60)).padStart(2,'0')+'s'};async function load(){let url=input.value.trim();if(!url.startsWith('http')){details.replaceChildren();return}try{let data=await fetch('/youtube-preview?url='+encodeURIComponent(url)).then(r=>r.json()),parts=[];if(data.channel)parts.push('👤 '+data.channel);if(data.count)parts.push('☰ '+data.count+' Videos');else if(data.duration)parts.push('◷ '+clock(data.duration));details.innerHTML=parts.map(item=>'<span>'+item.replace(/</g,'&lt;')+'</span>').join('')}catch(error){details.replaceChildren()}}input.addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(load,550)});if(input.value)load()})</script>'''
    suggestion_refresh_script = '''<script>document.addEventListener('DOMContentLoaded',()=>{let box=document.getElementById('recommendations'),url=document.getElementById('url');box.addEventListener('click',()=>setTimeout(()=>url.dispatchEvent(new Event('input')),0))})</script>'''
    queue_script = '''<script>document.addEventListener('DOMContentLoaded',()=>{let box=document.getElementById('queue'),panel=box.closest('.panel'),status=document.createElement('p');status.className='hint';status.id='queue-status';panel.querySelector('.actions').before(status);panel.querySelector('.sub').textContent='Sammle Downloads und starte sie anschließend nacheinander im Hintergrund.';let read=()=>{try{return JSON.parse(localStorage.getItem('utube-mac-queue')||'[]')}catch(e){return[]}},write=items=>localStorage.setItem('utube-mac-queue',JSON.stringify(items));async function describe(item,index){try{let data=await fetch('/youtube-preview?url='+encodeURIComponent(item.url)).then(r=>r.json()),items=read();if(!items[index])return;items[index].title=data.title||items[index].title||'YouTube-Download';items[index].thumbnail=data.thumbnail||items[index].thumbnail||'';items[index].playlist=Boolean(data.playlist);write(items);render()}catch(e){}}function render(){let items=read();box.replaceChildren();if(!items.length){box.innerHTML='<p class="sub">Noch keine Downloads vorgemerkt.</p>';return}items.forEach((item,index)=>{let row=document.createElement('button');row.type='button';row.className='secondary';row.style.textAlign='left';let image=item.thumbnail?'<img src="'+item.thumbnail+'" style="width:80px;height:45px;object-fit:cover;border-radius:6px;vertical-align:middle;margin-right:9px">':'<span style="font-size:22px;margin-right:9px">'+(item.playlist?'📚':'🎬')+'</span>';row.innerHTML=image+'<strong>'+(item.title||'YouTube-Vorschau wird geladen …').replace(/</g,'&lt;')+'</strong><br><small>'+(item.playlist||item.mode.includes('playlist')?'Playlist':'Einzelnes Video')+' · '+item.mode.replace(/.*-/,'').toUpperCase()+' · Entfernen ×</small>';row.onclick=()=>{let next=read();next.splice(index,1);write(next);render()};box.appendChild(row);if(!item.title)describe(item,index)})}async function start(){let items=read();if(!items.length){status.textContent='Die Warteschlange ist leer.';return}status.textContent='Warteschlange wird gestartet …';let response=await fetch('/queue',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(items)});if(response.ok){write([]);render();status.textContent='✓ '+items.length+' Download(s) wurden nacheinander gestartet.'}else status.textContent='⚠️ Warteschlange konnte nicht gestartet werden.'}document.addEventListener('click',event=>{let button=event.target.closest('button');if(!button)return;let text=button.textContent.trim();if(text==='Warteschlange starten'){event.preventDefault();event.stopImmediatePropagation();start()}if(text==='Leeren'){event.preventDefault();event.stopImmediatePropagation();write([]);render();status.textContent='Warteschlange geleert.'}if(text==='Zur Warteschlange hinzufügen'){event.preventDefault();event.stopImmediatePropagation();let url=document.getElementById('url').value.trim();if(!url.startsWith('http')){status.textContent='Bitte zuerst einen YouTube-Link einfügen.';return}let items=read();items.push({url:url,mode:document.getElementById('mode').value,quality:document.getElementById('quality').value,subtitles:document.getElementById('subtitles').value,playlist:document.getElementById('mode').value.includes('playlist')});write(items);render();status.textContent='✓ Zur Warteschlange hinzugefügt.'}} ,true);render()})</script>'''
    queue_live_script = '''<script>document.addEventListener('DOMContentLoaded',()=>{let nativeFetch=window.fetch;function showQueueProgress(id){let queue=document.getElementById('queue'),box=document.createElement('div');box.className='progress-box show';box.innerHTML='<b>Warteschlange läuft</b><div id="queue-live-items" class="file-list"></div>';queue.after(box);let timer=setInterval(async()=>{try{let jobs=await nativeFetch('/queue-progress?id='+encodeURIComponent(id)).then(r=>r.json()),items=box.querySelector('#queue-live-items');items.innerHTML=jobs.length?jobs.map(job=>'<div class="folder"><b>'+String(job.TITLE||'Download').replace(/</g,'&lt;')+'</b><br><small>'+String(job.PHASE||'Wartet').replace(/</g,'&lt;')+' · '+(job.PERCENT||'0')+'%</small><div class="bar-track"><div class="progress-fill" style="width:'+Math.max(3,Math.min(100,parseFloat(job.PERCENT)||0))+'%"></div></div></div>').join(''):'<p class="hint">Der erste Download wird vorbereitet …</p>';if(jobs.length&&jobs.every(job=>job.done))clearInterval(timer)}catch(e){}},900)}window.fetch=async function(...args){let response=await nativeFetch(...args),address=String(args[0]||'');if(address==='/queue'&&response.ok)response.clone().json().then(data=>{if(data.queue)showQueueProgress(data.queue)});return response};let preview=document.getElementById('youtube-preview'),button=document.createElement('button');button.type='button';button.className='secondary';button.textContent='Detaillierter Download';button.style.marginTop='8px';preview.after(button);let details=document.createElement('div');details.className='file-list';details.style.marginTop='10px';button.onclick=async()=>{let url=document.getElementById('url').value.trim();if(!url.includes('list=')){details.innerHTML='<p class="hint">Bitte zuerst eine Playlist auswählen.</p>';button.after(details);return}button.disabled=true;button.textContent='Playlist-Titel werden geladen …';try{let entries=await nativeFetch('/playlist-items?url='+encodeURIComponent(url)).then(r=>r.json());details.innerHTML=entries.length?entries.map((entry,index)=>'<div class="folder"><b>'+String(index+1)+'. '+entry.title.replace(/</g,'&lt;')+'</b><br><button type="button" class="secondary" data-id="'+entry.id+'">Dieses Video einzeln zur Warteschlange</button></div>').join(''):'<p class="hint">Playlist-Titel konnten nicht geladen werden.</p>';details.querySelectorAll('button[data-id]').forEach(choice=>choice.onclick=()=>{let entry=entries.find(item=>item.id===choice.dataset.id),items=JSON.parse(localStorage.getItem('utube-mac-queue')||'[]');items.push({url:'https://www.youtube.com/watch?v='+entry.id,mode:document.getElementById('mode').value.replace('playlist-','single-'),quality:document.getElementById('quality').value,subtitles:'none',title:entry.title,thumbnail:entry.thumbnail,playlist:false});localStorage.setItem('utube-mac-queue',JSON.stringify(items));choice.textContent='✓ Zur Warteschlange hinzugefügt'});button.after(details)}catch(e){details.innerHTML='<p class="hint">Playlist-Titel konnten nicht geladen werden.</p>';button.after(details)}finally{button.disabled=false;button.textContent='Detaillierter Download'}}})</script>'''
    clipboard_script = '''<script>document.addEventListener('DOMContentLoaded',()=>{let url=document.getElementById('url'),box=document.getElementById('recommendations');url.addEventListener('paste',()=>setTimeout(()=>url.dispatchEvent(new Event('input')),0));async function offerClipboard(){try{let clip=await fetch('/clipboard-youtube').then(r=>r.json()),link=clip.url||'';if(!link||[...box.querySelectorAll('button')].some(button=>button.dataset.url===link))return;box.style.display='grid';let button=document.createElement('button');button.type='button';button.className='secondary';button.dataset.url=link;button.style.textAlign='left';button.innerHTML='<span style="display:inline-block;width:120px;height:68px;border-radius:8px;background:#172b40;vertical-align:middle;margin-right:10px;text-align:center;padding-top:22px">⏳</span><strong>YouTube-Vorschau wird geladen …</strong>';box.prepend(button);let preview=await fetch('/youtube-preview?url='+encodeURIComponent(link)).then(r=>r.json()),playlist=Boolean(preview.playlist||/[?&]list=/.test(link)),title=String(preview.title||'YouTube').replace(/</g,'&lt;'),image=preview.thumbnail?'<img src="'+preview.thumbnail+'" style="width:120px;height:68px;object-fit:cover;border-radius:8px;vertical-align:middle;margin-right:10px">':'<span style="display:inline-block;width:120px;height:68px;border-radius:8px;background:#172b40;vertical-align:middle;margin-right:10px;text-align:center;padding-top:22px">'+(playlist?'📚':'🎬')+'</span>';button.innerHTML=image+'<strong>'+title+'</strong><br><small>'+ (playlist?'📚 Playlist aus Zwischenablage':'🎬 Video aus Zwischenablage')+' · Zum Übernehmen anklicken</small>';button.onclick=()=>{url.value=link;url.dispatchEvent(new Event('input'));box.style.display='none'}}catch(e){} }url.addEventListener('focus',()=>setTimeout(offerClipboard,250));document.addEventListener('visibilitychange',()=>{if(!document.hidden)offerClipboard()});offerClipboard()})</script>'''
    suggestion_thumbnails = '''<script>document.addEventListener('DOMContentLoaded',()=>{let box=document.getElementById('recommendations'),seen=new WeakSet();async function enrich(button,link){if(seen.has(button)||!link||button.querySelector('img'))return;seen.add(button);try{let data=await fetch('/youtube-preview?url='+encodeURIComponent(link)).then(r=>r.json());if(!data.thumbnail)return;let image=document.createElement('img');image.src=data.thumbnail;image.alt='';image.style.cssText='width:96px;height:54px;object-fit:cover;border-radius:7px;vertical-align:middle;margin-right:9px';button.prepend(image)}catch(e){}}async function refresh(){let tabs=[];try{tabs=await fetch('/safari-tabs').then(r=>r.json())}catch(e){}box.querySelectorAll('button').forEach(button=>{let link=button.dataset.url||((tabs.find(tab=>button.textContent.includes(tab.title))||{}).url);enrich(button,link)})}new MutationObserver(refresh).observe(box,{childList:true,subtree:true});refresh()})</script>'''
    page_playlist_picker = '''<style>#page-playlist-dialog{width:min(820px,92vw);max-height:82vh;border:1px solid #4b759d;border-radius:18px;padding:20px;background:#0e1b29;color:#edf3f8;box-shadow:0 25px 80px #000}#page-playlist-dialog::backdrop{background:#000a}.page-playlist-list{display:grid;gap:10px;max-height:55vh;overflow:auto;margin:14px 0}.page-playlist-item{display:grid;grid-template-columns:30px 110px 1fr;gap:12px;align-items:center;padding:10px;border:1px solid #345a78;border-radius:12px;background:#13283b;color:#edf3f8;text-align:left}.page-playlist-item img,.page-playlist-art{width:110px;height:62px;object-fit:cover;border-radius:8px;background:#203c55}.page-playlist-art{display:grid;place-items:center;font-size:25px}.page-playlist-check{width:18px;height:18px;accent-color:#5a96ff}</style><script>document.addEventListener('DOMContentLoaded',()=>{let url=document.getElementById('url'),mode=document.getElementById('mode'),anchor=document.getElementById('recommendations'),open=document.createElement('button'),dialog=document.createElement('dialog'),list=document.createElement('div'),close=document.createElement('button'),selected=new Map(),queueButton=document.createElement('button'),note=document.createElement('p');open.type='button';open.className='secondary';open.textContent='☰ Videos suchen: Playlists dieser Seite';open.style.marginTop='8px';anchor.before(open);dialog.id='page-playlist-dialog';dialog.innerHTML='<h2>☰ Playlists auf dieser YouTube-Seite</h2><p class="sub">Ein Klick übernimmt genau diese Playlist für den Download. Mit den Kästchen kannst du mehrere Playlists zur Warteschlange hinzufügen.</p>';list.className='page-playlist-list';queueButton.type='button';queueButton.className='secondary';queueButton.textContent='Ausgewählte Playlists zur Warteschlange';queueButton.disabled=true;note.className='hint';close.type='button';close.className='secondary';close.textContent='Schließen';close.onclick=()=>dialog.close();dialog.append(list,queueButton,note,close);document.body.append(dialog);function playlistMode(){return mode.value.includes('mp3-advanced')?'playlist-mp3-advanced':mode.value.includes('mp3')?'playlist-mp3':mode.value.includes('mkv')?'playlist-mkv':'playlist-mp4'}function updateSelection(){queueButton.disabled=!selected.size;queueButton.textContent=selected.size?'Ausgewählte '+selected.size+' Playlist'+(selected.size===1?'':'s')+' zur Warteschlange':'Ausgewählte Playlists zur Warteschlange';note.textContent=selected.size?'Die Auswahl wird nacheinander heruntergeladen.':''}queueButton.onclick=()=>{let queued;try{queued=JSON.parse(localStorage.getItem('utube-mac-queue')||'[]')}catch(e){queued=[]}selected.forEach(item=>queued.push({url:item.url,mode:playlistMode(),quality:document.getElementById('quality').value,subtitles:'none',playlist:true,title:item.title,thumbnail:item.thumbnail}));localStorage.setItem('utube-mac-queue',JSON.stringify(queued));note.textContent='✓ '+selected.size+' Playlist'+(selected.size===1?'':'s')+' zur Warteschlange hinzugefügt.';selected.clear();list.querySelectorAll('input').forEach(input=>input.checked=false);updateSelection()};open.onclick=async()=>{selected.clear();updateSelection();dialog.showModal();list.innerHTML='<p class="sub">YouTube-Seite wird nach Playlists durchsucht …</p>';try{let items=await fetch('/safari-playlists').then(r=>r.json());if(!items.length){list.innerHTML='<p class="sub">Keine Playlists gefunden. Öffne in Safari eine YouTube-Kanal- oder Playlist-Seite und versuche es erneut.</p>';return}list.replaceChildren();items.forEach(item=>{let button=document.createElement('button'),check=document.createElement('input'),art=item.thumbnail?'<img src="'+item.thumbnail+'" alt="">':'<span class="page-playlist-art">☰</span>',count=Number.isFinite(item.count)?item.count+' Video'+(item.count===1?'':'s'):'Videoanzahl wird von YouTube nicht angegeben';check.type='checkbox';check.className='page-playlist-check';check.setAttribute('aria-label',item.title+' auswählen');check.onclick=event=>{event.stopPropagation();check.checked?selected.set(item.url,item):selected.delete(item.url);updateSelection()};button.type='button';button.className='page-playlist-item';button.append(check);button.insertAdjacentHTML('beforeend',art+'<span><b>'+item.title.replace(/</g,'&lt;')+'</b><br><small>'+count+' · Diese Playlist herunterladen</small></span>');button.onclick=()=>{url.value=item.url;url.dispatchEvent(new Event('input'));mode.value=playlistMode();mode.dispatchEvent(new Event('change'));dialog.close();url.scrollIntoView({behavior:'smooth',block:'center'})};list.append(button)})}catch(error){list.innerHTML='<p class="sub">Die Safari-Seite konnte nicht gelesen werden.</p>'}}})</script>'''
    playlist_picker_controls = '''<script>document.addEventListener('DOMContentLoaded',()=>{let dialog=document.getElementById('page-playlist-dialog');if(!dialog)return;let list=dialog.querySelector('.page-playlist-list'),bar=document.createElement('div'),all=document.createElement('button'),none=document.createElement('button');bar.className='actions';bar.style.margin='8px 0';all.type=none.type='button';all.className=none.className='secondary';all.textContent='✓ Alles auswählen';none.textContent='Alles abwählen';all.onclick=()=>list.querySelectorAll('.page-playlist-check:not(:checked)').forEach(check=>check.click());none.onclick=()=>list.querySelectorAll('.page-playlist-check:checked').forEach(check=>check.click());bar.append(all,none);dialog.insertBefore(bar,list)})</script>'''
    playlist_picker_footer = '''<script>document.addEventListener('DOMContentLoaded',()=>{let dialog=document.getElementById('page-playlist-dialog');if(!dialog)return;let list=dialog.querySelector('.page-playlist-list'),note=[...dialog.querySelectorAll('p')].find(node=>node.className==='hint'),queueButton=[...dialog.querySelectorAll('button')].find(button=>button.textContent.includes('zur Warteschlange')),summary=document.createElement('p'),settings=document.createElement('div'),mode=document.getElementById('mode'),quality=document.getElementById('quality'),mapped=false;summary.className='hint';settings.className='actions';settings.innerHTML='<label class="hint">Format <select id="picker-format"><option value="mp4">MP4 · Video</option><option value="mkv">MKV · Video</option><option value="mp3">MP3 · Audio</option><option value="mp3-advanced">MP3 · Metadaten</option></select></label><label class="hint">Standard-Qualität <select id="picker-quality"><option value="best">Beste verfügbar</option><option value="2160">Bis 4K</option><option value="1080">Bis 1080p</option><option value="720">Bis 720p</option><option value="480">Bis 480p</option></select></label>';dialog.insertBefore(settings,list);dialog.insertBefore(summary,queueButton);let format=settings.querySelector('#picker-format'),pickerQuality=settings.querySelector('#picker-quality');format.value=mode.value.includes('mp3-advanced')?'mp3-advanced':mode.value.includes('mp3')?'mp3':mode.value.includes('mkv')?'mkv':'mp4';pickerQuality.value=quality.value;function syncFormat(){mode.value='playlist-'+format.value;mode.dispatchEvent(new Event('change'))}format.onchange=syncFormat;async function prepareCards(){if(mapped||!list.querySelector('.page-playlist-item'))return;mapped=true;try{let entries=await fetch('/safari-playlists').then(response=>response.json()),byTitle=new Map(entries.map(item=>[item.title,item]));list.querySelectorAll('.page-playlist-item').forEach(card=>{let item=byTitle.get(card.querySelector('b')?.textContent||'');if(item){card.dataset.url=item.url;card.dataset.title=item.title;card.dataset.thumbnail=item.thumbnail||''}})}catch(error){}renderSummary()}function renderSummary(){let cards=[...list.querySelectorAll('.page-playlist-item')],videos=cards.reduce((total,card)=>total+(parseInt(card.querySelector('small')?.textContent||'0',10)||0),0);summary.textContent=cards.length?cards.length+' Playlists · '+videos+' Videos insgesamt':''}new MutationObserver(()=>{mapped=false;prepareCards();renderSummary()}).observe(list,{childList:true,subtree:true});prepareCards();renderSummary()})</script>'''
    playlist_picker_individual_options = '''<script>document.addEventListener('DOMContentLoaded',()=>{let dialog=document.getElementById('page-playlist-dialog');if(!dialog)return;let list=dialog.querySelector('.page-playlist-list');function addQualityMenus(){let fallback=dialog.querySelector('#picker-quality')?.value||'720';list.querySelectorAll('.page-playlist-item').forEach(card=>{if(card.querySelector('.individual-playlist-quality'))return;let select=document.createElement('select');select.className='individual-playlist-quality';select.setAttribute('aria-label','Qualität für diese Playlist');select.innerHTML='<option value="best">Beste</option><option value="2160">4K</option><option value="1080">1080p</option><option value="720">720p</option><option value="480">480p</option>';select.value=fallback;select.onclick=event=>event.stopPropagation();select.onchange=event=>event.stopPropagation();card.querySelector('span:last-child')?.append(document.createElement('br'),select)})}new MutationObserver(addQualityMenus).observe(list,{childList:true,subtree:true});addQualityMenus();document.addEventListener('click',event=>{let button=event.target.closest('button');if(!button||!button.textContent.includes('zur Warteschlange')||!dialog.open)return;let cards=[...list.querySelectorAll('.page-playlist-check:checked')].map(check=>check.closest('.page-playlist-item')).filter(card=>card?.dataset.url);if(!cards.length)return;event.preventDefault();event.stopImmediatePropagation();let format=dialog.querySelector('#picker-format')?.value||'mp4',queued;try{queued=JSON.parse(localStorage.getItem('utube-mac-queue')||'[]')}catch(error){queued=[]}let added=0;cards.forEach(card=>{if(queued.some(item=>item.url===card.dataset.url))return;queued.push({url:card.dataset.url,mode:'playlist-'+format,quality:card.querySelector('.individual-playlist-quality')?.value||'720',subtitles:'none',playlist:true,title:card.dataset.title,thumbnail:card.dataset.thumbnail});added++});localStorage.setItem('utube-mac-queue',JSON.stringify(queued));dialog.close();setTimeout(()=>location.reload(),120)},true)})</script>'''
    playlist_picker_quality_sync = '''<script>document.addEventListener('DOMContentLoaded',()=>{let dialog=document.getElementById('page-playlist-dialog');if(!dialog)return;let standard=dialog.querySelector('#picker-quality');if(!standard)return;standard.addEventListener('change',()=>{dialog.querySelectorAll('.individual-playlist-quality').forEach(choice=>choice.value=standard.value)})})</script>'''
    queue_deduplicate_script = '''<script>document.addEventListener('DOMContentLoaded',()=>{try{let items=JSON.parse(localStorage.getItem('utube-mac-queue')||'[]'),seen=new Set(),unique=items.filter(item=>item&&item.url&&!seen.has(item.url)&&(seen.add(item.url),true));if(unique.length!==items.length){localStorage.setItem('utube-mac-queue',JSON.stringify(unique));location.reload()}}catch(error){}})</script>'''
    download_inbox = '<section class="panel"><h2>↓ Deine Downloads</h2><p class="sub">Laufende Downloads, fertige Dateien und einfache Fehler – ohne technische Details.</p><a class="folder" href="/download-notifications">Download-Mitteilungen öffnen</a></section>'
    settings_repair_script = '''<script>(function(){let tries=0,timer=setInterval(()=>{let dialog=document.querySelector('.app-settings-dialog'),views=[...document.querySelectorAll('.settings-view')],update=views.find(v=>v.querySelector('h3')?.textContent==='Updates'),advanced=views.find(v=>v.querySelector('h3')?.textContent==='Erweitert');if(!dialog||!update){if(++tries>40)clearInterval(timer);return}clearInterval(timer);if(dialog.dataset.utubeSettingsReady)return;dialog.dataset.utubeSettingsReady='1';let close=document.createElement('button');close.type='button';close.className='secondary settings-close';close.textContent='Schließen ✕';close.onclick=()=>dialog.close();dialog.append(close);let developer=document.createElement('a');developer.className='developer-corner';developer.href='/developer';developer.title='Entwickler-Einstellungen';developer.textContent='⌘';dialog.append(developer);if(advanced)advanced.innerHTML='<h3>Erweitert</h3><p class="hint">Wartung und Entwickler-Funktionen findest du über ⌘ unten links.</p>';let auto=update.querySelector('#settings-auto-updates');update.innerHTML='<h3>Updates</h3><p class="hint">UI und Shortcut werden zusammen geprüft.</p><div class="update-check"><button type="button" id="check-all-updates">Alle Updates prüfen</button><p id="update-check-result" class="hint">Noch nicht geprüft.</p></div>';if(auto)update.append(auto.parentElement);let button=update.querySelector('#check-all-updates'),result=update.querySelector('#update-check-result');button.onclick=async()=>{button.disabled=true;button.innerHTML='<span class="update-spinner"></span> Suche auf GitHub …';result.textContent='UI und Shortcut werden geprüft …';try{let state=await fetch('/update-status',{cache:'no-store'}).then(r=>r.json()),items=[];if(state.ui.update)items.push('UI '+state.ui.available);if(state.shortcut.update)items.push('Shortcut '+state.shortcut.available);if(items.length){result.textContent='Update verfügbar: '+items.join(' · ');alert('Update verfügbar:\\n'+items.join('\\n'))}else{result.textContent='✓ Alles aktuell · UI '+state.ui.installed+' · Shortcut '+state.shortcut.installed;alert('Alles aktuell.\\n\\nUI: '+state.ui.installed+'\\nShortcut: '+state.shortcut.installed)}}catch(e){result.textContent='⚠️ GitHub konnte gerade nicht erreicht werden.'}finally{button.disabled=false;button.textContent='Alle Updates prüfen'}}},120)})()</script>'''
    design_settings_script = '''<style>#theme-picker{display:none!important}.design-grid{display:grid;gap:11px}.design-grid label{display:grid;gap:5px;font-weight:750}.design-grid input[type=color]{width:100%;height:38px;padding:3px}.design-grid .checkline{display:flex;align-items:center}.design-grid select{margin:0}</style><script>(function(){let defaults={accent:'#5d8cff',accent2:'#46d8b0',gradient:true,shape:'round',text:'16'},key=m=>'utube-design-'+m,read=m=>{try{return Object.assign({},defaults,JSON.parse(localStorage.getItem(key(m))||'{}'))}catch(e){return {...defaults}}};function apply(){let mode=localStorage.getItem('utube-design-mode')||'dark',v=read(mode),light=mode==='light',style=document.getElementById('utube-design-style')||document.head.appendChild(Object.assign(document.createElement('style'),{id:'utube-design-style'}));style.textContent='body{font-size:'+v.text+'px!important;background:'+(light?'radial-gradient(circle at 18% -10%,#b8ddf5 0,#f3f8fc 42%,#e5edf4 100%)':'radial-gradient(circle at 18% -10%,#173c5c 0,#0a1018 34%,#080b12 100%)')+'!important;color:'+(light?'#152536':'#edf3f8')+'!important}body[data-utube-mode="light"] .panel,body[data-utube-mode="light"] .card,body[data-utube-mode="light"] .media-card{background:#ffffffdd!important;color:#152536!important;border-color:#9ebcd3!important}.app-sidebar a{border-radius:'+(v.shape==='pill'?'999px':v.shape==='square'?'5px':'10px')+'!important}button{border-radius:'+(v.shape==='pill'?'999px':v.shape==='square'?'5px':'11px')+'!important;background:'+(v.gradient?'linear-gradient(135deg,'+v.accent+','+v.accent2+')':v.accent)+'!important}.notification-bell{background:'+(v.gradient?'linear-gradient(135deg,'+v.accent+','+v.accent2+')':v.accent)+'!important;border-color:'+v.accent+'!important}';document.body.dataset.utubeMode=mode}function setup(){apply();document.getElementById('theme-picker')?.remove();let n=0,t=setInterval(()=>{let d=document.querySelector('.app-settings-dialog'),nav=d?.querySelector('.settings-nav'),main=d?.querySelector('.settings-main');if(!d||!nav||!main){if(++n>40)clearInterval(t);return}clearInterval(t);if(main.querySelector('#design-settings'))return;let tab=document.createElement('button'),view=document.createElement('section');tab.type='button';tab.textContent='Design';view.className='settings-view';view.id='design-settings';view.innerHTML='<h3>🎨 Design</h3><p class="hint">Hell und dunkel werden getrennt gespeichert.</p><div class="design-grid"><label>Darstellung<select id="dm"><option value="dark">Dunkler Modus</option><option value="light">Heller Modus</option></select></label><label>Akzentfarbe<input id="da" type="color"></label><label>Zweite Farbe<input id="db" type="color"></label><label class="checkline"><input id="dg" type="checkbox"> Farbverlauf</label><label>Button-Form<select id="ds"><option value="round">Rund</option><option value="pill">Sehr rund</option><option value="square">Eckig</option></select></label><label>Textgröße<select id="dt"><option value="14">Klein</option><option value="16">Standard</option><option value="18">Groß</option><option value="20">Sehr groß</option></select></label><button class="secondary" type="button" id="dr">Standard-Einstellungen zurücksetzen</button></div>';tab.onclick=()=>{nav.querySelectorAll('button').forEach(b=>b.classList.toggle('active',b===tab));main.querySelectorAll('.settings-view').forEach(v=>v.classList.toggle('active',v===view))};nav.append(tab);main.append(view);let f={m:view.querySelector('#dm'),a:view.querySelector('#da'),b:view.querySelector('#db'),g:view.querySelector('#dg'),s:view.querySelector('#ds'),z:view.querySelector('#dt')};function fill(){let m=localStorage.getItem('utube-design-mode')||'dark',v=read(m);f.m.value=m;f.a.value=v.accent;f.b.value=v.accent2;f.g.checked=v.gradient;f.s.value=v.shape;f.z.value=v.text}function save(){let m=f.m.value;localStorage.setItem('utube-design-mode',m);localStorage.setItem(key(m),JSON.stringify({accent:f.a.value,accent2:f.b.value,gradient:f.g.checked,shape:f.s.value,text:f.z.value}));apply()}f.m.onchange=()=>{fill();apply()};[f.a,f.b,f.g,f.s,f.z].forEach(x=>x.oninput=save);view.querySelector('#dr').onclick=()=>{let m=f.m.value;localStorage.removeItem(key(m));localStorage.removeItem('utube-design-mode');fill();apply()};fill()},120)}if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',setup);else setup()})()</script>'''
    design_v2_settings_script = '''<script>(()=>{let D={background:'#080b12',background2:'#173c5c',backgroundOn:false,backgroundGradient:false,button:'#4b8fff',button2:'#6974ff',buttonOn:false,buttonGradient:true,accent:'#5dd1ff',accent2:'#55d6a8',accentGradient:true,text:'#edf3f8',shape:'round',size:'16'},K=m=>'utube-design-v2-'+m,R=m=>{try{return Object.assign({},D,JSON.parse(localStorage.getItem(K(m))||'{}'))}catch(e){return {...D}}};function start(){let tries=0,t=setInterval(()=>{let d=document.querySelector('.app-settings-dialog'),nav=d?.querySelector('.settings-nav'),main=d?.querySelector('.settings-main');if(!d||!nav||!main){if(++tries>50)clearInterval(t);return}clearInterval(t);let tab=[...nav.querySelectorAll('button')].find(b=>b.textContent.trim()==='Design');let view=main.querySelector('#design-settings');if(!tab||!view)return;view.innerHTML='<h3>🎨 Design</h3><p class="hint">Das ruhige Ozean-Design bleibt Standard. Akzent = feine obere Linien und Glocke.</p><div class="design-grid"><label>Darstellung<select id="v2m"><option value="dark">Dunkler Modus</option><option value="light">Heller Modus</option></select></label><b>Hintergrund</b><label class="checkline"><input id="v2bo" type="checkbox"> Eigene Hintergrundfarbe verwenden</label><label>Farbe 1<input id="v2b1" type="color"></label><label>Farbe 2<input id="v2b2" type="color"></label><label class="checkline"><input id="v2bg" type="checkbox"> Farbverlauf</label><b>Knöpfe</b><label class="checkline"><input id="v2po" type="checkbox"> Eigene Knopffarbe verwenden</label><label>Farbe 1<input id="v2p1" type="color"></label><label>Farbe 2<input id="v2p2" type="color"></label><label class="checkline"><input id="v2pg" type="checkbox"> Farbverlauf</label><b>Akzent – feine Linien & Glocke</b><label>Farbe 1<input id="v2a1" type="color"></label><label>Farbe 2<input id="v2a2" type="color"></label><label class="checkline"><input id="v2ag" type="checkbox"> Farbverlauf</label><label>Textfarbe<input id="v2t" type="color"></label><label>Button-Form<select id="v2s"><option value="round">Rund</option><option value="pill">Sehr rund</option><option value="square">Eckig</option></select></label><label>Textgröße<select id="v2z"><option value="14">Klein</option><option value="16">Standard</option><option value="18">Groß</option><option value="20">Sehr groß</option></select></label><button class="secondary" type="button" id="v2r">Standard-Einstellungen zurücksetzen</button></div>';let q=x=>view.querySelector(x),f={m:q('#v2m'),bo:q('#v2bo'),b1:q('#v2b1'),b2:q('#v2b2'),bg:q('#v2bg'),po:q('#v2po'),p1:q('#v2p1'),p2:q('#v2p2'),pg:q('#v2pg'),a1:q('#v2a1'),a2:q('#v2a2'),ag:q('#v2ag'),tx:q('#v2t'),s:q('#v2s'),z:q('#v2z')};function fill(){let m=localStorage.getItem('utube-design-v2-mode')||'dark',v=R(m);f.m.value=m;f.bo.checked=v.backgroundOn;f.b1.value=v.background;f.b2.value=v.background2;f.bg.checked=v.backgroundGradient;f.po.checked=v.buttonOn;f.p1.value=v.button;f.p2.value=v.button2;f.pg.checked=v.buttonGradient;f.a1.value=v.accent;f.a2.value=v.accent2;f.ag.checked=v.accentGradient;f.tx.value=v.text;f.s.value=v.shape;f.z.value=v.size}function save(){let m=f.m.value,v={background:f.b1.value,background2:f.b2.value,backgroundOn:f.bo.checked,backgroundGradient:f.bg.checked,button:f.p1.value,button2:f.p2.value,buttonOn:f.po.checked,buttonGradient:f.pg.checked,accent:f.a1.value,accent2:f.a2.value,accentGradient:f.ag.checked,text:f.tx.value,shape:f.s.value,size:f.z.value};localStorage.setItem('utube-design-v2-mode',m);localStorage.setItem(K(m),JSON.stringify(v));window.utubeDesignV2Apply?.()}f.m.onchange=()=>{localStorage.setItem('utube-design-v2-mode',f.m.value);fill();window.utubeDesignV2Apply?.()};Object.values(f).slice(1).forEach(x=>x.oninput=save);q('#v2r').onclick=()=>{localStorage.removeItem(K(f.m.value));fill();window.utubeDesignV2Apply?.()};fill()},100)}if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start()})()</script>'''
    design_v2_final_apply = '''<script>(()=>{let D={bg:'#080b12',bg2:'#173c5c',bgon:false,bgg:false,btn:'#4b8fff',btn2:'#6974ff',btnon:false,btng:true,acc:'#5dd1ff',acc2:'#55d6a8',accg:true,txt:'#edf3f8'},K=m=>'utube-design-clean-'+m,R=m=>Object.assign({},D,JSON.parse(localStorage.getItem(K(m))||'{}')),P=(a,b,g)=>g?'linear-gradient(135deg,'+a+','+b+')':a;function apply(){let m=localStorage.getItem('utube-design-clean-mode')||'dark',v=R(m),light=m==='light',s=document.getElementById('utube-clean-style')||document.head.appendChild(Object.assign(document.createElement('style'),{id:'utube-clean-style'}));document.getElementById('utube-design-style')?.remove();document.getElementById('utube-design-v2-style')?.remove();s.textContent='body{background:'+(v.bgon?P(v.bg,v.bg2,v.bgg):(light?'linear-gradient(145deg,#f7fbff,#d5e9ff)':'radial-gradient(circle at 18% -10%,#173c5c 0,#0a1018 34%,#080b12 100%)'))+'!important;color:'+v.txt+'!important}button{background:'+(v.btnon?P(v.btn,v.btn2,v.btng):'linear-gradient(135deg,#4b8fff,#6974ff)')+'!important}button.secondary{background:'+(v.btnon?P(v.btn,v.btn2,v.btng):'#203a53')+'!important}.card:before{background:'+P(v.acc,v.acc2,v.accg)+'!important}.notification-bell{background:'+P(v.acc,v.acc2,v.accg)+'!important;border-color:'+v.acc+'!important}'+(light?'.panel,.card,.media-card{background:#fff!important;color:#152536!important}input,select{background:#fff!important;color:#152536!important}':'')}function setup(){apply();let i=0,t=setInterval(()=>{let d=document.querySelector('.app-settings-dialog'),n=d?.querySelector('.settings-nav'),a=d?.querySelector('.settings-main'),tab=[...n?.querySelectorAll('button')||[]].find(x=>x.textContent.trim()==='Design'),view=a?.querySelector('#design-settings');if(!tab||!view){if(++i>50)clearInterval(t);return}clearInterval(t);view.innerHTML='<h3>🎨 Design</h3><p class="hint">Standard: ursprüngliches Ozean-Design. Akzent nur für die feinen Linien und Glocke.</p><div class="design-grid"><label>Darstellung<select id="m"><option value="dark">Dunkler Modus</option><option value="light">Heller Modus</option></select></label><b>Hintergrund</b><label><input id="bo" type="checkbox"> Eigene Farbe verwenden</label><label>Farbe 1<input id="b" type="color"></label><label>Farbe 2<input id="b2" type="color"></label><label><input id="bg" type="checkbox"> Verlauf</label><b>Knöpfe</b><label><input id="po" type="checkbox"> Eigene Farbe verwenden</label><label>Farbe 1<input id="p" type="color"></label><label>Farbe 2<input id="p2" type="color"></label><label><input id="pg" type="checkbox"> Verlauf</label><b>Akzent · Linien & Glocke</b><label>Farbe 1<input id="a" type="color"></label><label>Farbe 2<input id="a2" type="color"></label><label><input id="ag" type="checkbox"> Verlauf</label><label>Textfarbe<input id="x" type="color"></label><button class="secondary" id="reset" type="button">Standard-Einstellungen zurücksetzen</button></div>';let q=x=>view.querySelector(x),f={m:q('#m'),bo:q('#bo'),b:q('#b'),b2:q('#b2'),bg:q('#bg'),po:q('#po'),p:q('#p'),p2:q('#p2'),pg:q('#pg'),a:q('#a'),a2:q('#a2'),ag:q('#ag'),x:q('#x')},fill=()=>{let m=localStorage.getItem('utube-design-clean-mode')||'dark',v=R(m);f.m.value=m;['bo','bg','po','pg','ag'].forEach(k=>f[k].checked=v[{bo:'bgon',bg:'bgg',po:'btnon',pg:'btng',ag:'accg'}[k]]);f.b.value=v.bg;f.b2.value=v.bg2;f.p.value=v.btn;f.p2.value=v.btn2;f.a.value=v.acc;f.a2.value=v.acc2;f.x.value=v.txt},save=()=>{let v={bg:f.b.value,bg2:f.b2.value,bgon:f.bo.checked,bgg:f.bg.checked,btn:f.p.value,btn2:f.p2.value,btnon:f.po.checked,btng:f.pg.checked,acc:f.a.value,acc2:f.a2.value,accg:f.ag.checked,txt:f.x.value};localStorage.setItem('utube-design-clean-mode',f.m.value);localStorage.setItem(K(f.m.value),JSON.stringify(v));apply()};f.m.onchange=()=>{localStorage.setItem('utube-design-clean-mode',f.m.value);fill();apply()};Object.values(f).slice(1).forEach(e=>e.oninput=save);q('#reset').onclick=()=>{localStorage.removeItem(K(f.m.value));fill();apply()};fill()},80)}document.addEventListener('DOMContentLoaded',setup)})()</script>'''
    return layout("UTUBE MAC", "Lokale Download-App. Die Dateien bleiben auf deinem Mac.", notification_bell + content + chooser + setup_script + library_script + choice_script + smart_download_script + smart_profiles + dashboard_download_script + playlist_ui_script + preview_script + duplicate_preview_script + preview_details_script + suggestion_refresh_script + queue_script + queue_live_script + cancel_download_script + clipboard_script + suggestion_thumbnails + page_playlist_picker + playlist_picker_controls + playlist_picker_individual_options + playlist_picker_footer + playlist_picker_quality_sync + queue_deduplicate_script + protection_script + settings_concept + update_workflow + settings_repair_script + design_settings_script + design_v2_settings_script + design_v2_final_apply + smart_link_only + top_card_design_sync, message)

def developer_page(message=""):
    logs = sorted(LOGS.glob("setup-*.log"), reverse=True)[:8] if LOGS.exists() else []
    health_rows = "".join(f"<tr><td>{html.escape(name)}</td><td class={'ok' if status == 'Bereit' else 'bad'}>{html.escape(status)}</td></tr>" for name, status in health())
    processes = utube_processes()
    process_rows = "".join(f"<tr><td><b>● {html.escape(pid)}</b></td><td>{html.escape(command)}</td><td class='ok'>Läuft</td></tr>" for pid, command in processes) or "<tr><td colspan='3' class='hint'>Im Moment läuft kein eigener UTUBE-MAC-Prozess.</td></tr>"
    log_rows = "".join(f'<li><a href="/browse?target=logs&path={urllib.parse.quote(log.name)}">{html.escape(log.name)} ansehen</a></li>' for log in logs) or "<li>Noch keine Setup-Berichte vorhanden.</li>"
    folders = [("UTUBE MAC – Application Support", "support"), ("Skripte", "scripts"), ("Einstellungen", "settings"), ("Gesamte Historie", "history"), ("Setup-Berichte", "logs"), ("Skript-Historie", "script-history"), ("Shortcut-Versionen", "shortcut-history"), ("Safari-Erweiterung", "safari-extension"), ("GitHub-Repository", "repository"), ("Laufzeit und Download-Fortschritt", "runtime"), ("Temporäre Dateien", "temp"), ("Developer Dashboard", "dashboard")]
    folder_buttons = "".join(f'<a class="folder" href="/browse?target={urllib.parse.quote(key)}">{html.escape(label)}</a>' for label, key in folders if open_targets().get(key, Path()).exists())
    shortcut_versions = sorted((p for p in SHORTCUT_HISTORY.iterdir() if p.is_dir()), key=lambda p: p.name) if SHORTCUT_HISTORY.exists() else []
    script_versions = sorted((p for p in SCRIPT_HISTORY.iterdir() if p.is_dir()), key=lambda p: p.stat().st_mtime, reverse=True)[:10] if SCRIPT_HISTORY.exists() else []
    shortcut_version_buttons = "".join(f'<a class="folder" href="/browse?target={urllib.parse.quote("version-" + p.name)}">{html.escape(p.name)}</a>' for p in shortcut_versions) or '<p class="sub">Keine Shortcut-Versionen vorhanden.</p>'
    script_version_buttons = "".join(f'<a class="folder" href="/browse?target={urllib.parse.quote("version-" + p.name)}">{html.escape(p.name)}</a>' for p in script_versions) or '<p class="sub">Noch keine Skript-Sicherungen vorhanden.</p>'
    counts, free_space = library_stats()
    content = f'''<section class="panel"><a class="folder" href="/notifications">🔔 Meldungszentrale · {len(notification_events())} Ereignisse</a></section><section class="grid">{card("Lokale Version", local_version())}{card("yt-dlp", tool_version("yt-dlp", "--version"))}{card("FFmpeg", tool_version("ffmpeg", "-version"))}{card("Beets", tool_version("beet", "--version"))}</section>
<section class="panel"><h2>Download-Übersicht</h2><p class="sub">{sum(counts.values())} Mediendateien · {free_space} GB frei</p><div class="chart">{library_chart()}</div></section>
<section class="panel"><h2>Verlauf & Testzentrum</h2><p class="sub">Lokale Download-Einträge durchsuchen und einzelne Programmteile sicher prüfen.</p><div class="actions"><a class="folder" href="/browse?target=history&path=Download%20History/DOWNLOAD-HISTORY.txt">📜 Download-Verlauf öffnen</a><a class="folder" href="/tester">🧪 Testzentrum öffnen</a></div></section>
<section class="panel"><h2>Wartung & Sicherung</h2><div class="actions"><form method="post" action="/action"><input type="hidden" name="action" value="setup"><button>Einrichtung starten</button></form><form method="post" action="/action"><input type="hidden" name="action" value="update"><button>Update prüfen</button></form><form method="post" action="/action"><input type="hidden" name="action" value="health"><button class="secondary">Skript-Check</button></form><form method="post" action="/action"><input type="hidden" name="action" value="folder"><button class="secondary">Download-Ordner öffnen</button></form><form id="program-backup-form"><button class="secondary" id="program-backup-button">💾 Programm sichern</button></form></div><div id="program-backup-progress" class="backup-progress" hidden><div class="backup-progress-track"><span id="program-backup-fill"></span></div><p id="program-backup-status" class="hint">Sicherung wird vorbereitet …</p></div><p class="hint">Die Sicherung enthält nur die App und UTUBE-MAC-Skripte – keine Downloads oder Medien.</p></section>
<section class="panel"><h2>🟢 Aktive UTUBE-MAC-Prozesse</h2><p class="sub">Nur lokale Prozesse, die zu UTUBE MAC, Downloads oder dem lokalen Server gehören.</p><table><tr><th>PID</th><th>Prozess</th><th>Status</th></tr>{process_rows}</table><p class="hint">Diese Liste wird beim Öffnen oder Aktualisieren der Entwicklerseite neu gelesen.</p></section>
<section class="panel"><h2>Dateizentrale</h2><p class="sub">Öffnet Dateien direkt in UTUBE MAC oder im Finder.</p><div class="folders">{folder_buttons}</div><p><a class="folder" href="/safari-extension">Safari-Erweiterung einrichten</a></p></section>
<section class="panel"><h2>Shortcut-Versionen</h2><p class="sub">Gespeicherte Versionen des Kurzbefehls.</p><div class="folders">{shortcut_version_buttons}</div></section>
<section class="panel"><h2>Skript-Sicherungen</h2><p class="sub">Die letzten zehn Sicherungen der UTUBE-MAC-Skripte und Oberflächen.</p><div class="folders">{script_version_buttons}</div></section>
<section class="panel"><h2>Helferskripte</h2><table><tr><td>Installationsskript</td><td>Einrichtung und Kern-Tools</td></tr><tr><td>Downloader</td><td>Video-, Playlist- und MP3-Downloads</td></tr><tr><td>Updater</td><td>GitHub-Version und Tool-Updates</td></tr>{health_rows}</table></section>
<section class="panel"><h2>Letzte Setup-Berichte</h2><ul>{log_rows}</ul></section>'''
    backup_script = '''<style>.backup-progress{margin-top:14px;max-width:440px}.backup-progress-track{height:10px;background:#102a40;border-radius:999px;overflow:hidden;border:1px solid #245276}.backup-progress-track span{display:block;width:0;height:100%;background:linear-gradient(90deg,#43d5b0,#5a96ff);transition:width .35s ease;border-radius:inherit}</style><script>document.getElementById('program-backup-form')?.addEventListener('submit',async event=>{event.preventDefault();let button=document.getElementById('program-backup-button'),box=document.getElementById('program-backup-progress'),fill=document.getElementById('program-backup-fill'),status=document.getElementById('program-backup-status');button.disabled=true;box.hidden=false;fill.style.width='18%';status.textContent='Programm-Dateien werden gesammelt …';let timer=setTimeout(()=>{fill.style.width='62%';status.textContent='ZIP-Sicherung wird erstellt …'},350);try{let response=await fetch('/program-backup',{method:'POST'}),data=await response.json();if(!response.ok)throw Error(data.error||'Backup fehlgeschlagen');clearTimeout(timer);fill.style.width='100%';status.textContent='✓ '+data.name+' wurde erstellt. Backup-Ordner wird im Finder geöffnet …';setTimeout(()=>{location.href='/open?target=backups'},800)}catch(error){clearTimeout(timer);fill.style.width='0';status.textContent='⚠️ '+(error.message||'Das Programm-Backup konnte nicht erstellt werden.');button.disabled=false}})</script>'''
    inbox_link = '<section class="panel"><a class="folder" href="/download-notifications">↓ Nutzer-Mitteilungen: Downloads einfach ansehen</a><p class="hint">Die technische Meldungszentrale darunter bleibt für Details, Protokolle und Diagnose.</p></section>'
    return layout("UTUBE MAC – Developer Console", "Lokale Test- und Diagnosezentrale. Aktionen starten nur definierte UTUBE-MAC-Skripte.", inbox_link + content + backup_script, message)

class Handler(BaseHTTPRequestHandler):
    # HTTP/1.0 closes every finished response explicitly.  That avoids the
    # embedded macOS web view waiting on ordinary HTML/JSON responses.
    protocol_version = "HTTP/1.0"
    def send_page(self, page):
        self.send_response(200); self.send_header("Content-Type", "text/html; charset=utf-8"); self.end_headers(); self.wfile.write(page.encode())
    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path == "/update-status":
            ui_remote = remote_ui_release(); shortcut_remote = remote_shortcut_release()
            payload = {"ui": {"installed": local_version(), "available": ui_remote, "update": bool(ui_remote and newer_version(ui_remote, local_version()))}, "shortcut": {"installed": shortcut_version(), "available": shortcut_remote, "update": bool(shortcut_remote and newer_version(shortcut_remote, shortcut_version()))}}
            self.send_response(200); self.send_header("Content-Type", "application/json; charset=utf-8"); self.end_headers(); self.wfile.write(json.dumps(payload).encode()); return
        if parsed.path == "/download-notifications":
            self.send_page(download_notifications_page()); return
        if parsed.path == "/history":
            self.send_page(download_activity_timeline()); return
        if parsed.path == "/retry-download":
            job = urllib.parse.parse_qs(parsed.query).get("job", [""])[0]
            restarted = retry_failed_job(job)
            message = "✓ Download wird repariert: fehlende Dateien werden ergänzt." if restarted else "Der gespeicherte Link für diesen Fehler konnte nicht erneut gestartet werden."
            record_event("download" if restarted else "failed", "Reparatur gestartet" if restarted else "Reparatur konnte nicht gestartet werden", job)
            self.send_response(303); self.send_header("Location", "/download-notifications?message=" + urllib.parse.quote(message)); self.end_headers(); return
        if parsed.path == "/tester":
            selected = urllib.parse.parse_qs(parsed.query).get("run", ["all"])[0]
            self.send_page(test_center_page(selected)); return
        if parsed.path == "/safari-extension":
            self.send_page(safari_extension_guide_page()); return
        if parsed.path == "/install-safari-extension":
            app = Path("/Applications/UTUBE MAC Safari Extension 6.2.0.app")
            if app.exists(): subprocess.Popen(["open", str(app)])
            self.send_response(303); self.send_header("Location", "/safari-extension"); self.end_headers(); return
        if parsed.path == "/open-shortcut":
            subprocess.Popen(["open", "shortcuts://open-shortcut?name=UTUBE%20MAC"])
            self.send_response(303); self.send_header("Location", "/"); self.end_headers(); return
        if parsed.path in {"/library", "/storage"}:
            query = urllib.parse.parse_qs(parsed.query)
            chosen = query.get("filter", ["ALL"])[0]
            playlist = query.get("playlist", [""])[0]
            self.send_page(library_page(chosen, playlist) if parsed.path == "/library" else storage_page()); return
        if parsed.path == "/media":
            path = safe_media(urllib.parse.parse_qs(parsed.query).get("path", [""])[0])
            if not path: self.send_error(404); return
            size = path.stat().st_size; start = 0; end = size - 1
            requested = self.headers.get("Range", "")
            if requested.startswith("bytes="):
                try:
                    first, last = requested[6:].split("-", 1); start = int(first) if first else 0; end = int(last) if last else end
                    if start < 0 or start >= size or end < start: raise ValueError
                    end = min(end, size - 1)
                    self.send_response(206); self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
                except ValueError:
                    self.send_error(416); return
            else: self.send_response(200)
            self.send_header("Content-Type", mimetypes.guess_type(str(path))[0] or "application/octet-stream"); self.send_header("Accept-Ranges", "bytes"); self.send_header("Cache-Control", "private, max-age=3600"); self.send_header("Content-Length", str(end - start + 1)); self.end_headers()
            # Let macOS transfer the requested file range directly to the
            # web view.  Copying multi-gigabyte movies through Python made
            # the UI noticeably sluggish, especially while seeking.
            try:
                self.wfile.flush()
                with path.open("rb") as source:
                    self.connection.sendfile(source, offset=start, count=end - start + 1)
            except (BrokenPipeError, ConnectionResetError, OSError):
                # Seeking and closing the player cancel ranges normally.
                pass
            return
        if parsed.path == "/reveal":
            path = safe_media(urllib.parse.parse_qs(parsed.query).get("path", [""])[0])
            if path: subprocess.Popen(["open", "-R", str(path)])
            self.send_response(303); self.send_header("Location", "/library"); self.end_headers(); return
        if parsed.path == "/open-media":
            path = safe_media(urllib.parse.parse_qs(parsed.query).get("path", [""])[0])
            if path: subprocess.Popen(["open", str(path)])
            self.send_response(204); self.end_headers(); return
        if parsed.path == "/open-mpv":
            path = safe_media(urllib.parse.parse_qs(parsed.query).get("path", [""])[0])
            mpv = shutil.which("mpv")
            if path and mpv:
                subprocess.Popen([mpv, "--force-window=yes", "--hwdec=auto-safe", "--keep-open=no", str(path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                self.send_response(204); self.end_headers(); return
            self.send_error(503, "mpv ist nicht verfügbar"); return
        if parsed.path == "/open-external":
            url = urllib.parse.parse_qs(parsed.query).get("url", [""])[0]
            if url.startswith(("https://", "http://")):
                subprocess.Popen(["open", url])
            self.send_response(204); self.end_headers(); return
        if parsed.path == "/open":
            target = urllib.parse.parse_qs(parsed.query).get("target", [""])[0]
            path = open_targets().get(target)
            if path and path.exists(): subprocess.Popen(["open", str(path)])
            self.send_response(303); self.send_header("Location", "/developer"); self.end_headers(); return
        if parsed.path == "/browse":
            query = urllib.parse.parse_qs(parsed.query)
            self.send_page(file_browser_page(query.get("target", [""])[0], query.get("path", [""])[0])); return
        if parsed.path == "/notifications":
            self.send_page(notifications_page()); return
        if parsed.path == "/report-problem":
            query = urllib.parse.parse_qs(parsed.query)
            self.send_page(problem_report_page(query.get("from", [""])[0], query.get("message", [""])[0])); return
        if parsed.path in {"/reveal-file", "/launch-file"}:
            query = urllib.parse.parse_qs(parsed.query); path = safe_target_item(query.get("target", [""])[0], query.get("path", [""])[0])
            if path:
                subprocess.Popen(["open", "-R", str(path)] if parsed.path == "/reveal-file" else ["open", str(path)])
            self.send_response(303); self.send_header("Location", "/developer"); self.end_headers(); return
        if parsed.path == "/progress":
            requested = urllib.parse.parse_qs(parsed.query).get("job", [""])[0]
            payload = [item for item in progress_jobs() if not requested or item["id"] == requested]
            self.send_response(200); self.send_header("Content-Type", "application/json; charset=utf-8"); self.end_headers(); self.wfile.write(json.dumps(payload).encode()); return
        if parsed.path == "/setup-progress":
            self.send_response(200); self.send_header("Content-Type", "application/json; charset=utf-8"); self.end_headers(); self.wfile.write(json.dumps(setup_progress()).encode()); return
        if parsed.path == "/youtube-preview":
            url = urllib.parse.parse_qs(parsed.query).get("url", [""])[0]
            self.send_response(200); self.send_header("Content-Type", "application/json; charset=utf-8"); self.end_headers(); self.wfile.write(json.dumps(youtube_preview(url)).encode()); return
        if parsed.path == "/video-info":
            url = urllib.parse.parse_qs(parsed.query).get("url", [""])[0]
            self.send_response(200); self.send_header("Content-Type", "application/json; charset=utf-8"); self.end_headers(); self.wfile.write(json.dumps(youtube_video_metadata(url)).encode()); return
        if parsed.path == "/library-match":
            url = urllib.parse.parse_qs(parsed.query).get("url", [""])[0]
            self.send_response(200); self.send_header("Content-Type", "application/json; charset=utf-8"); self.end_headers(); self.wfile.write(json.dumps({"match": library_match_for_url(url)}).encode()); return
        if parsed.path == "/playlist-items":
            url = urllib.parse.parse_qs(parsed.query).get("url", [""])[0]
            self.send_response(200); self.send_header("Content-Type", "application/json; charset=utf-8"); self.end_headers(); self.wfile.write(json.dumps(youtube_playlist_items(url)).encode()); return
        if parsed.path == "/queue-progress":
            queue_id = urllib.parse.parse_qs(parsed.query).get("id", [""])[0]
            self.send_response(200); self.send_header("Content-Type", "application/json; charset=utf-8"); self.end_headers(); self.wfile.write(json.dumps(queue_progress(queue_id)).encode()); return
        if self.path.startswith("/safari-tabs"):
            payload = json.dumps(safari_youtube_tabs()).encode()
            self.send_response(200); self.send_header("Content-Type", "application/json; charset=utf-8"); self.end_headers(); self.wfile.write(payload); return
        if parsed.path == "/safari-playlists":
            self.send_response(200); self.send_header("Content-Type", "application/json; charset=utf-8"); self.end_headers(); self.wfile.write(json.dumps(safari_page_playlists()).encode()); return
        if parsed.path == "/playlist-count":
            url = urllib.parse.parse_qs(parsed.query).get("url", [""])[0]
            self.send_response(200); self.send_header("Content-Type", "application/json; charset=utf-8"); self.end_headers(); self.wfile.write(json.dumps({"count": youtube_playlist_count(url)}).encode()); return
        if parsed.path == "/clipboard-youtube":
            self.send_response(200); self.send_header("Content-Type", "application/json; charset=utf-8"); self.end_headers(); self.wfile.write(json.dumps({"url": clipboard_youtube_link()}).encode()); return
        message = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).get("message", [""])[0]
        self.send_page(developer_page(message) if self.path.startswith("/developer") else app_page(message))
    def do_POST(self):
        length = int(self.headers.get("Content-Length", "0")); raw = self.rfile.read(length).decode()
        if self.path == "/report-problem":
            data = urllib.parse.parse_qs(raw)
            description = data.get("description", [""])[0].strip()
            category = data.get("category", ["Allgemein"])[0].strip()
            source = data.get("source", [""])[0].strip()
            if description:
                report = save_problem_report(category, description, source)
                self.send_response(303); self.send_header("Location", "/report-problem?message=" + urllib.parse.quote(f"✓ Problem gespeichert: {report.name}")); self.end_headers()
            else:
                self.send_response(303); self.send_header("Location", "/report-problem?message=" + urllib.parse.quote("Bitte beschreibe das Problem kurz.")); self.end_headers()
            return
        if self.path == "/program-backup":
            archive = make_program_backup()
            self.send_response(200 if archive else 500); self.send_header("Content-Type", "application/json; charset=utf-8"); self.end_headers()
            self.wfile.write(json.dumps({"name": archive.name} if archive else {"error": "Das Programm-Backup konnte nicht erstellt werden."}).encode()); return
        if self.path == "/extension-heartbeat":
            heartbeat = RUNTIME / "Safari Extension Heartbeat.json"; heartbeat.parent.mkdir(parents=True, exist_ok=True)
            heartbeat.write_text(json.dumps({"seen": int(time.time())}))
            self.send_response(200); self.send_header("Content-Type", "application/json"); self.end_headers(); self.wfile.write(b'{"active":true}'); return
        if self.path == "/setup-web":
            try: requested = json.loads(raw).get("path", "") if raw else ""
            except Exception: requested = ""
            selected = Path(requested).expanduser() if requested else DOWNLOADS
            if INSTALLER.exists():
                selected.mkdir(parents=True, exist_ok=True)
                remember_library(selected)
                run_in_terminal([INSTALLER, "", "", "", str(selected)])
                self.send_response(200); self.send_header("Content-Type", "application/json"); self.end_headers(); self.wfile.write(b'{"started":true}')
            else: self.send_error(404)
            return
        if self.path == "/choose-library":
            selected = choose_library_folder()
            if selected: remember_library(selected)
            self.send_response(200); self.send_header("Content-Type", "application/json"); self.end_headers(); self.wfile.write(json.dumps({"path": selected}).encode()); return
        if self.path == "/remove-library":
            try: selected = json.loads(raw).get("path", "")
            except Exception: selected = ""
            if selected and selected != str(DOWNLOADS): forget_library(selected)
            self.send_response(200); self.send_header("Content-Type", "application/json"); self.end_headers(); self.wfile.write(b'{}'); return
        if self.path == "/media-metadata":
            try: item = json.loads(raw)
            except Exception: item = {}
            saved = save_custom_metadata(str(item.get("path", "")), item)
            self.send_response(200 if saved else 400); self.send_header("Content-Type", "application/json"); self.end_headers()
            self.wfile.write(json.dumps({"saved": True} if saved else {"error": "Ungültige Medieninformationen"}).encode()); return
        if self.path == "/optimize-media":
            try: item = json.loads(raw)
            except Exception: item = {}
            started = optimize_media_for_seeking(str(item.get("path", "")))
            self.send_response(202 if started else 400); self.send_header("Content-Type", "application/json"); self.end_headers()
            self.wfile.write(json.dumps({"started": started}).encode()); return
        if self.path == "/move-media":
            try: item = json.loads(raw)
            except Exception: item = {}
            moved = move_media_to_library(str(item.get("path", "")), str(item.get("target", "")))
            if moved:
                self.send_response(200); self.send_header("Content-Type", "application/json"); self.end_headers(); self.wfile.write(json.dumps({"path": str(moved)}).encode())
            else:
                self.send_response(400); self.send_header("Content-Type", "application/json"); self.end_headers(); self.wfile.write(b'{"error":"Die Datei konnte nicht verschoben werden. Der Zielordner muss ein anderer gespeicherter Downloadpfad sein."}')
            return
        if self.path == "/download-dashboard":
            try: item = json.loads(raw)
            except Exception: item = {}
            allowed = {"auto-mp4", "auto-mkv", "auto-mp3", "auto-mp3-advanced", "single-mp4", "playlist-mp4", "single-mkv", "playlist-mkv", "single-mp3", "playlist-mp3", "single-mp3-advanced", "playlist-mp3-advanced"}
            valid = isinstance(item, dict) and item.get("mode") in allowed and item.get("quality") in {"best", "fast", "2160", "1080", "720", "480"} and item.get("subtitles") in {"none", "de", "en", "all"} and str(item.get("url", "")).startswith(("https://www.youtube.com/", "https://youtube.com/", "https://youtu.be/"))
            started = bool(valid and DOWNLOADER.exists() and run_dashboard_in_background(item["mode"], item["url"], item["quality"], item["subtitles"]))
            self.send_response(200 if started else 400); self.send_header("Content-Type", "application/json"); self.end_headers(); self.wfile.write(json.dumps({"started": started}).encode()); return
        if self.path == "/download-background":
            try: item = json.loads(raw)
            except Exception: item = {}
            allowed = {"auto-mp4", "auto-mkv", "auto-mp3", "auto-mp3-advanced", "single-mp4", "playlist-mp4", "single-mkv", "playlist-mkv", "single-mp3", "playlist-mp3", "single-mp3-advanced", "playlist-mp3-advanced"}
            valid = isinstance(item, dict) and item.get("mode") in allowed and item.get("quality") in {"best", "fast", "2160", "1080", "720", "480"} and item.get("subtitles") in {"none", "de", "en", "all"} and str(item.get("url", "")).startswith(("https://www.youtube.com/", "https://youtube.com/", "https://youtu.be/"))
            if valid and DOWNLOADER.exists():
                job = run_download_in_background(item["mode"], item["url"], item["quality"], item["subtitles"])
                record_event("download", f"Download gestartet: {item['mode']}")
                self.send_response(200); self.send_header("Content-Type", "application/json"); self.end_headers(); self.wfile.write(json.dumps({"job": job}).encode())
            else: self.send_error(400)
            return
        if self.path == "/cancel-download":
            try: item = json.loads(raw)
            except Exception: item = {}
            cancelled = cancel_background_download(str(item.get("job", ""))) if isinstance(item, dict) else False
            if cancelled: record_event("cancelled", "Download vom Nutzer abgebrochen")
            self.send_response(200 if cancelled else 409); self.send_header("Content-Type", "application/json"); self.end_headers(); self.wfile.write(json.dumps({"cancelled": cancelled}).encode()); return
        if self.path == "/extension-queue":
            try: item = json.loads(raw)
            except Exception: item = {}
            url = str(item.get("url", ""))
            if url.startswith(("https://www.youtube.com/", "https://youtube.com/", "https://youtu.be/")):
                queue_file = RUNTIME / "Safari Extension Queue.json"; queue_file.parent.mkdir(parents=True, exist_ok=True)
                try: items = json.loads(queue_file.read_text())
                except Exception: items = []
                items.append({"url": url, "title": str(item.get("title", "YouTube")), "added": int(time.time())})
                queue_file.write_text(json.dumps(items[-50:], ensure_ascii=False, indent=2))
                self.send_response(200); self.send_header("Content-Type", "application/json"); self.end_headers(); self.wfile.write(b'{"queued":true}'); return
            self.send_error(400); return
        if self.path == "/queue":
            try:
                items = json.loads(raw)
            except Exception:
                items = []
            if isinstance(items, list):
                unique, seen_urls = [], set()
                for item in items:
                    url = str(item.get("url", "")) if isinstance(item, dict) else ""
                    if not url or url in seen_urls:
                        continue
                    seen_urls.add(url)
                    unique.append(item)
                items = unique
            allowed = {"auto-mp4", "auto-mkv", "auto-mp3", "auto-mp3-advanced", "single-mp4", "playlist-mp4", "single-mkv", "playlist-mkv", "single-mp3", "playlist-mp3", "single-mp3-advanced", "playlist-mp3-advanced"}
            valid = isinstance(items, list) and 0 < len(items) <= 100 and all(isinstance(item, dict) and item.get("mode") in allowed and item.get("quality") in {"best", "fast", "2160", "1080", "720", "480"} and item.get("subtitles") in {"none", "de", "en", "all"} and str(item.get("url", "")).startswith(("https://www.youtube.com/", "https://youtube.com/", "https://youtu.be/")) for item in items)
            busy = queue_is_running()
            queue_id = run_queue_in_background(items) if valid and not busy and DOWNLOADER.exists() else ""
            if queue_id:
                record_event("download", f"Warteschlange gestartet: {len(items)} Playlist(s)/Download(s)", f"Warteschlangen-ID: {queue_id}")
            else:
                reason = "Eine Warteschlange läuft bereits. Warte auf ihren Abschluss, damit keine Playlist-Dateien parallel überschrieben werden." if busy else "Die Warteschlange war leer, enthielt ungültige Einträge oder der Downloader ist nicht verfügbar."
                record_event("failed", "Warteschlange konnte nicht gestartet werden", reason)
            status = 200 if queue_id else 400
            self.send_response(status); self.send_header("Content-Type", "application/json"); self.end_headers(); self.wfile.write(json.dumps({"queue": queue_id}).encode()); return
        data = urllib.parse.parse_qs(raw)
        action = data.get("action", [""])[0]; message = "Aktion nicht erkannt."
        destination = "/developer" if self.headers.get("Referer", "").split("?")[0].endswith("/developer") else "/"
        if action == "setup" and INSTALLER.exists(): run_in_terminal([INSTALLER]); message = "Die Einrichtung wurde im Terminal gestartet."
        elif action == "update" and UPDATER.exists(): run_silently(UPDATER); message = "Die Update-Prüfung läuft im Hintergrund. Das Ergebnis erscheint als UTUBE-MAC-Mitteilung."
        elif action == "dock-app": message = "UTUBE MAC wurde eingerichtet und im Dock bereitgestellt." if install_dock_app() else "Die UTUBE-MAC-App konnte nicht erstellt werden. Bitte starte zuerst die Einrichtung."
        elif action == "open-dock-app": message = "UTUBE MAC wurde geöffnet." if open_dock_app() else "Die UTUBE-MAC-App ist nicht verfügbar. Bitte richte sie zuerst ein."
        elif action == "add-dock": message = "UTUBE MAC wurde zum Dock hinzugefügt." if add_dock_entry(dock_app_bundle()) else "Die UTUBE-MAC-App ist nicht verfügbar. Bitte richte sie zuerst ein."
        elif action == "folder": subprocess.Popen(["open", str(DOWNLOADS)]); message = "Der Download-Ordner wurde geöffnet."
        elif action == "health": message = "Der Skript-Check wurde aktualisiert."
        elif action == "program-backup":
            archive = make_program_backup()
            message = f"Programm-Backup erstellt: {archive.name}" if archive else "Das Programm-Backup konnte nicht erstellt werden."
        elif action == "trash":
            path = safe_media(data.get("path", [""])[0])
            if path:
                applescript = 'on run argv\ntell application "Finder" to delete (POSIX file (item 1 of argv))\nend run'
                result = subprocess.run(["osascript", "-e", applescript, str(path)], capture_output=True, text=True, timeout=12)
                message = "Die Datei wurde in den Papierkorb gelegt." if result.returncode == 0 else "Die Datei konnte nicht in den Papierkorb gelegt werden."
            else: message = "Diese Datei ist nicht mehr im UTUBE-MAC-Download-Ordner vorhanden."
            destination = "/storage" if self.headers.get("Referer", "").split("?")[0].endswith("/storage") else "/library"
        elif action == "download":
            url = data.get("url", [""])[0].strip(); mode = data.get("mode", ["auto-mp4"])[0]; quality = data.get("quality", ["best"])[0]; subtitles = data.get("subtitles", ["none"])[0]
            allowed = {"auto-mp4", "auto-mkv", "auto-mp3", "auto-mp3-advanced", "single-mp4", "playlist-mp4", "single-mkv", "playlist-mkv", "single-mp3", "playlist-mp3", "single-mp3-advanced", "playlist-mp3-advanced"}; qualities = {"best", "fast", "2160", "1080", "720", "480"}; subtitle_modes = {"none", "de", "en", "all"}
            if url.startswith(("https://www.youtube.com/", "https://youtube.com/", "https://youtu.be/")) and DOWNLOADER.exists() and mode in allowed and quality in qualities and subtitles in subtitle_modes:
                run_in_terminal([DOWNLOADER, mode, url, quality, subtitles]); message = "Der Download wurde im Terminal gestartet."
            else: message = "Bitte einen gültigen YouTube-Link einfügen."
        self.send_response(303); self.send_header("Location", destination + "?message=" + urllib.parse.quote(message)); self.end_headers()
    def log_message(self, *args): pass

if __name__ == "__main__": ThreadingHTTPServer(("127.0.0.1", 8765), Handler).serve_forever()
