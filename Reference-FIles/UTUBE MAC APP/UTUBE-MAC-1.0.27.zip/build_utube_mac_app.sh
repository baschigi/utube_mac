#!/bin/bash
# UTUBE MAC app builder
# Last updated: 11. September 2026 · 19:37 CEST
set -euo pipefail
support_directory="$HOME/Library/Application Support/UTUBE-MAC"
scripts_directory="$support_directory/scripts"
assets_directory="$support_directory/Assets"
version="$(tr -d '[:space:]' < "$support_directory/Settings/General/utube-mac-version.txt" 2>/dev/null || printf '6.2.0')"
# Keep the app name stable. The version belongs in its information panel,
# not in the name shown in Finder or the Dock.
app_bundle="$HOME/Applications/UTUBE MAC.app"
resources="$app_bundle/Contents/Resources"; macos="$app_bundle/Contents/MacOS"
mkdir -p "$resources" "$macos" "$assets_directory"
icon="$assets_directory/UTUBE-MAC-Icon.icns"
icon_png="$assets_directory/UTUBE-MAC-Icon.png"
iconset="$assets_directory/UTUBE-MAC-Icon.iconset"
rm -f "$icon" "$icon_png" "$resources/UTUBE-MAC-Icon.icns"
rm -rf "$iconset"
icon_updated="$(date +%s)"
curl -fsSL --max-time 20 "https://raw.githubusercontent.com/baschigi/utube_mac/main/Reference-FIles/UTUBE%20ICONS/UTUBE%20MAC.icns?updated=$icon_updated" -o "$icon" 2>/dev/null || true
if [[ ! -s "$icon" ]]; then
  curl -fsSL --max-time 20 "https://raw.githubusercontent.com/baschigi/utube_mac/main/Reference-FIles/UTUBE%20ICONS/UTUBE%20MAC.png?updated=$icon_updated" -o "$icon_png" 2>/dev/null || true
  if [[ -s "$icon_png" ]]; then
    mkdir -p "$iconset"
    sips -z 16 16 "$icon_png" --out "$iconset/icon_16x16.png" >/dev/null
    sips -z 32 32 "$icon_png" --out "$iconset/icon_16x16@2x.png" >/dev/null
    sips -z 32 32 "$icon_png" --out "$iconset/icon_32x32.png" >/dev/null
    sips -z 64 64 "$icon_png" --out "$iconset/icon_32x32@2x.png" >/dev/null
    sips -z 128 128 "$icon_png" --out "$iconset/icon_128x128.png" >/dev/null
    sips -z 256 256 "$icon_png" --out "$iconset/icon_128x128@2x.png" >/dev/null
    sips -z 256 256 "$icon_png" --out "$iconset/icon_256x256.png" >/dev/null
    sips -z 512 512 "$icon_png" --out "$iconset/icon_256x256@2x.png" >/dev/null
    sips -z 512 512 "$icon_png" --out "$iconset/icon_512x512.png" >/dev/null
    sips -z 1024 1024 "$icon_png" --out "$iconset/icon_512x512@2x.png" >/dev/null
    iconutil -c icns "$iconset" -o "$icon" 2>/dev/null || true
  fi
fi
[[ -s "$icon" ]] && cp "$icon" "$resources/UTUBE-MAC-Icon.icns"
cat > "$app_bundle/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd"><plist version="1.0"><dict><key>CFBundleDisplayName</key><string>UTUBE MAC</string><key>CFBundleExecutable</key><string>UTUBE MAC</string><key>CFBundleIdentifier</key><string>com.utube-mac.webapp</string><key>CFBundleIconFile</key><string>UTUBE-MAC-Icon</string><key>CFBundlePackageType</key><string>APPL</string><key>CFBundleShortVersionString</key><string>${version}</string><key>CFBundleVersion</key><string>${version}</string></dict></plist>
PLIST
# Keep the native wrapper source once it has been customized.  Older builds
# recreated this small file every time and would otherwise remove AVPlayer.
if [[ ! -f "$scripts_directory/UTUBE-MAC-App.swift" ]]; then
cat > "$scripts_directory/UTUBE-MAC-App.swift" <<'SWIFT_EOF'
import Cocoa
import WebKit
final class AppDelegate: NSObject, NSApplicationDelegate {
  var window: NSWindow!
  func applicationDidFinishLaunching(_ notification: Notification) {
    let launcher = (NSHomeDirectory() as NSString).appendingPathComponent("Library/Application Support/UTUBE-MAC/scripts/open_utube_dashboard.sh")
    let process = Process(); process.executableURL = URL(fileURLWithPath: "/bin/bash"); process.arguments = [launcher, "--serve"]; try? process.run()
    let web = WKWebView(frame: .zero)
    window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 1180, height: 820), styleMask: [.titled,.closable,.miniaturizable,.resizable], backing: .buffered, defer: false)
    window.title = "UTUBE MAC"; window.titleVisibility = .hidden; window.titlebarAppearsTransparent = true; window.center(); window.contentView = web; window.makeKeyAndOrderFront(nil); NSApp.activate(ignoringOtherApps: true)
    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { web.load(URLRequest(url: URL(string: "http://127.0.0.1:8765/")!)) }
  }
  func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { true }
}
let app = NSApplication.shared; let delegate = AppDelegate(); app.delegate = delegate; app.setActivationPolicy(.regular); app.run()
SWIFT_EOF
fi
clang -fobjc-arc -framework Cocoa -framework WebKit -I/opt/homebrew/opt/mpv/include -L/opt/homebrew/opt/mpv/lib -lmpv "$scripts_directory/UTUBE-MAC-App.m" -o "$macos/UTUBE MAC"
chmod 755 "$macos/UTUBE MAC"
printf '%s\n' "$app_bundle"
