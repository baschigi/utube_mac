#!/bin/zsh
set -euo pipefail

TITLE="UTUBE-MAC Installation"
INSTALLER_DIR="$(cd "$(dirname "$0")" && pwd)"
SUPPORT_TARGET="$HOME/Library/Application Support/UTUBE-MAC"
APP_TARGET_DIR="$HOME/Applications"
APP_TARGET="$APP_TARGET_DIR/UTUBE MAC.app"
SUPPORT_SOURCE="$INSTALLER_DIR/UTUBE-MAC/Application Support/UTUBE-MAC"
APP_SOURCE="$INSTALLER_DIR/App/UTUBE MAC.app"

show_message() {
  /usr/bin/osascript -e "display dialog \"$1\" buttons {\"OK\"} default button \"OK\" with title \"$TITLE\"" >/dev/null 2>&1 || true
}

notify_message() {
  /usr/bin/osascript -e "display notification \"$1\" with title \"$TITLE\"" >/dev/null 2>&1 || true
}

fail() {
  show_message "Error: $1"
  printf '\n❌ Error: %s\n' "$1"
  exit 1
}

[[ -d "$SUPPORT_SOURCE" ]] || fail "Installation data is missing:\n$SUPPORT_SOURCE"
[[ -d "$APP_SOURCE" ]] || fail "UTUBE MAC.app is missing:\n$APP_SOURCE"

choice="$(/usr/bin/osascript -e 'display dialog "Install UTUBE MAC for this Mac?" buttons {"Cancel", "Install Only", "Install + Add to Dock"} default button "Install + Add to Dock" cancel button "Cancel" with title "UTUBE-MAC Installation"' -e 'button returned of result' 2>/dev/null || true)"
[[ -n "$choice" ]] || exit 0

printf '📁 Installing support files to Application Support ...\n'
/bin/mkdir -p "$SUPPORT_TARGET"
/usr/bin/ditto "$SUPPORT_SOURCE" "$SUPPORT_TARGET"

printf '🧩 Installing UTUBE MAC.app to ~/Applications ...\n'
/bin/mkdir -p "$APP_TARGET_DIR"
/bin/rm -rf "$APP_TARGET"
/usr/bin/ditto "$APP_SOURCE" "$APP_TARGET"

printf '🔐 Setting executable permissions ...\n'
/usr/bin/find "$SUPPORT_TARGET/scripts" -type f \( -name '*.sh' -o -name '*.command' -o -name '*.py' \) -exec /bin/chmod 755 {} \; 2>/dev/null || true
/bin/chmod -R u+rwX "$APP_TARGET" 2>/dev/null || true

printf '🚀 Opening UTUBE MAC ...\n'
/usr/bin/open -n "$APP_TARGET" >/dev/null 2>&1 || true

if [[ "$choice" == "Install + Add to Dock" ]]; then
  dockutil_path=""
  if command -v dockutil >/dev/null 2>&1; then
    dockutil_path="$(command -v dockutil)"
  elif [[ -x "/opt/homebrew/bin/dockutil" ]]; then
    dockutil_path="/opt/homebrew/bin/dockutil"
  elif [[ -x "/usr/local/bin/dockutil" ]]; then
    dockutil_path="/usr/local/bin/dockutil"
  fi

  if [[ -n "$dockutil_path" ]]; then
    "$dockutil_path" --remove "UTUBE MAC" --no-restart >/dev/null 2>&1 || true
    "$dockutil_path" --add "$APP_TARGET" --label "UTUBE MAC" >/dev/null 2>&1 || true
  else
    /usr/bin/osascript -e 'display notification "UTUBE MAC was installed. To keep it in the Dock, right-click its Dock icon and choose Options → Keep in Dock." with title "UTUBE-MAC Installation"' >/dev/null 2>&1 || true
  fi
fi

notify_message "UTUBE MAC was installed successfully."
